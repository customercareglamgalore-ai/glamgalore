// Resolves a checkout discount code against the order subtotal. Percentage
// codes are a % of subtotal; fixed codes are capped at subtotal so a
// discount can never make the pre-shipping total negative. Called from both
// the quote preview and order creation so the two stay consistent — usage
// is only ever incremented from checkout/verify, after payment succeeds.
import { prisma } from '@/lib/db';

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export type DiscountResolution = { code: string; amount: number } | { error: string };

export async function resolveDiscount(
  rawCode: string | null | undefined,
  subtotal: number,
): Promise<DiscountResolution | null> {
  const code = (rawCode || '').trim().toUpperCase();
  if (!code) return null;

  const discount = await prisma.discountCode.findUnique({ where: { code } });
  if (!discount || !discount.active) {
    return { error: 'That discount code is invalid or has expired.' };
  }
  if (discount.usageLimit !== null && discount.usageCount >= discount.usageLimit) {
    return { error: 'That discount code has already been used up.' };
  }

  // Capped at subtotal - ₹1, not the full subtotal — a discount that wipes
  // out the whole order leaves Razorpay a ₹0 charge to process, which it
  // rejects outright ("Order amount less than minimum amount allowed"),
  // crashing checkout for anyone hitting it. Leaving at least ₹1 payable
  // means every discount code, fixed or percentage, always actually works,
  // including a 100%-off or oversized-fixed-amount code — the customer just
  // pays a token ₹1 instead of the checkout failing outright.
  const maxDiscount = Math.max(0, round2(subtotal - 1));
  const amount =
    discount.valueType === 'percentage'
      ? Math.min(round2(subtotal * (Number(discount.value) / 100)), maxDiscount)
      : Math.min(round2(Number(discount.value)), maxDiscount);

  return { code: discount.code, amount: Math.max(0, amount) };
}

export async function recordDiscountUsage(code: string | null | undefined) {
  if (!code) return;
  await prisma.discountCode.updateMany({ where: { code }, data: { usageCount: { increment: 1 } } });
}
