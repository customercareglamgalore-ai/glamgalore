// Shared by /api/checkout/quote (preview) and /api/checkout/create-order (real,
// persisted) so the number a customer sees before paying is guaranteed to match
// what actually gets charged and stored.
import { prisma } from '@/lib/db';
import { getStoreSettings } from '@/lib/settings';
import { computeOrderTax, resolveLineRate, type TaxLineInput } from '@/lib/tax';
import { computeShippingCost } from '@/lib/shipping';
import { isIndiaCountry, applyInternationalMarkup } from '@/lib/international-pricing';
import { currencyForCountry, resolveConfiguredCurrency } from '@/lib/currency';
import { resolveDiscount } from '@/lib/discounts';

const FALLBACK_HSN = '6109'; // generic apparel HSN used only when nothing more specific is configured

export type CartItemInput = { productId: string; variantId?: string | null; quantity: number };
export type ShippingAddressInput = { state: string; country: string };

export class OrderTaxError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export async function buildOrderTax(
  cartItems: CartItemInput[],
  shippingAddress: ShippingAddressInput,
  discountCodeInput?: string | null,
) {
  const settings = await getStoreSettings();

  const productIds = [...new Set(cartItems.map((i) => i.productId))];
  const products = await prisma.product.findMany({ where: { id: { in: productIds } } });
  const productById = new Map(products.map((p) => [p.id, p]));

  const categories = [...new Set(products.map((p) => p.type).filter((t): t is string => Boolean(t)))];
  const rules = categories.length
    ? await prisma.taxRule.findMany({ where: { category: { in: categories } } })
    : [];
  const ruleByCategory = new Map(rules.map((r) => [r.category, { gstRate: Number(r.gstRate), hsnCode: r.hsnCode }]));

  const isIndia = isIndiaCountry(shippingAddress.country);

  const taxLines: TaxLineInput[] = [];
  const lineMeta: { productId: string; variantId: string | null; quantity: number; unitPrice: number }[] = [];

  for (const item of cartItems) {
    const product = productById.get(item.productId);
    if (!product || !product.price) {
      throw new OrderTaxError(`Product unavailable: ${item.productId}`);
    }
    if (product.isOutOfStock) {
      throw new OrderTaxError(`"${product.title}" is sold out`);
    }
    const unitPrice = isIndia ? Number(product.price) : applyInternationalMarkup(Number(product.price));
    const { gstRate, hsnCode } = resolveLineRate({
      unitPrice,
      productGstRateOverride: product.gstRateOverride ? Number(product.gstRateOverride) : null,
      productHsnCode: product.hsnCode,
      categoryRule: product.type ? ruleByCategory.get(product.type) ?? null : null,
      useApparelPriceSlabs: settings.useApparelPriceSlabs,
      apparelSlabThreshold: Number(settings.apparelSlabThreshold),
      apparelSlabRateBelow: Number(settings.apparelSlabRateBelow),
      apparelSlabRateAbove: Number(settings.apparelSlabRateAbove),
      defaultGstRate: Number(settings.defaultGstRate),
      fallbackHsnCode: FALLBACK_HSN,
    });

    taxLines.push({ productId: item.productId, quantity: item.quantity, unitPrice, hsnCode, gstRate });
    lineMeta.push({ productId: item.productId, variantId: item.variantId ?? null, quantity: item.quantity, unitPrice });
  }

  const subtotal = taxLines.reduce((sum, l) => sum + l.unitPrice * l.quantity, 0);
  const shippingCost = computeShippingCost(subtotal, shippingAddress.country);

  const discountResolution = await resolveDiscount(discountCodeInput, subtotal);
  const discountError = discountResolution && 'error' in discountResolution ? discountResolution.error : null;
  const discountAmount = discountResolution && 'amount' in discountResolution ? discountResolution.amount : 0;
  const discountCode = discountResolution && 'code' in discountResolution ? discountResolution.code : null;

  const computation = computeOrderTax(taxLines, shippingCost, {
    customerState: shippingAddress.state,
    customerCountry: shippingAddress.country,
    businessState: settings.businessState,
    pricesIncludeTax: settings.pricesIncludeTax,
    chargeTaxOnInternational: settings.chargeTaxOnInternational,
    discountAmount,
  });

  // Resolved once, here, so the live checkout preview (/api/checkout/quote)
  // and the actual charge (/api/checkout/create-order) always agree on what
  // currency an order is in — falls back to USD if the customer's local
  // currency doesn't have an admin-configured exchange rate yet, rather than
  // either inventing one or blocking checkout outright.
  let currency = 'INR';
  let fxRateApplied = 1;
  if (!isIndia) {
    const rates = (settings.currencyRates as Record<string, number>) || {};
    const resolved = resolveConfiguredCurrency(currencyForCountry(shippingAddress.country), rates);
    currency = resolved.currency;
    fxRateApplied = resolved.rate;
  }

  return { computation, lineMeta, settings, discountAmount, discountCode, discountError, currency, fxRateApplied };
}
