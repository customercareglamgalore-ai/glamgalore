// Master country list for the checkout country dropdown, CJ Dropshipping
// submissions, Meta CAPI, and geolocation currency detection — one place so
// every consumer stays in sync (previously only ~13 countries were listed
// anywhere, which meant CJ shipping silently fell back to India, Meta CAPI
// silently dropped the country field, and Taiwan/most of the world couldn't
// even be selected at checkout).
//
// `currency` here is each country's REAL local currency (ISO 4217) — not
// every one of these has an admin-configured exchange rate yet, though.
// resolveConfiguredCurrency() is the single place that falls back to USD
// when a specific local rate isn't configured, and both the browsing-time
// price display (request-currency.ts) and the actual checkout charge
// (order-tax.ts) call through it, so they can never disagree with each
// other about what currency a given order is actually in.
const COUNTRIES: { name: string; iso: string; currency: string }[] = [
  { name: 'India', iso: 'IN', currency: 'INR' },
  { name: 'United States', iso: 'US', currency: 'USD' },
  { name: 'United Kingdom', iso: 'GB', currency: 'GBP' },
  { name: 'Canada', iso: 'CA', currency: 'CAD' },
  { name: 'Australia', iso: 'AU', currency: 'AUD' },
  { name: 'Singapore', iso: 'SG', currency: 'SGD' },
  { name: 'United Arab Emirates', iso: 'AE', currency: 'AED' },

  // Eurozone -> EUR
  { name: 'Germany', iso: 'DE', currency: 'EUR' },
  { name: 'France', iso: 'FR', currency: 'EUR' },
  { name: 'Ireland', iso: 'IE', currency: 'EUR' },
  { name: 'Netherlands', iso: 'NL', currency: 'EUR' },
  { name: 'Spain', iso: 'ES', currency: 'EUR' },
  { name: 'Italy', iso: 'IT', currency: 'EUR' },
  { name: 'Austria', iso: 'AT', currency: 'EUR' },
  { name: 'Belgium', iso: 'BE', currency: 'EUR' },
  { name: 'Portugal', iso: 'PT', currency: 'EUR' },
  { name: 'Greece', iso: 'GR', currency: 'EUR' },
  { name: 'Finland', iso: 'FI', currency: 'EUR' },
  { name: 'Luxembourg', iso: 'LU', currency: 'EUR' },
  { name: 'Slovakia', iso: 'SK', currency: 'EUR' },
  { name: 'Slovenia', iso: 'SI', currency: 'EUR' },
  { name: 'Estonia', iso: 'EE', currency: 'EUR' },
  { name: 'Latvia', iso: 'LV', currency: 'EUR' },
  { name: 'Lithuania', iso: 'LT', currency: 'EUR' },
  { name: 'Cyprus', iso: 'CY', currency: 'EUR' },
  { name: 'Malta', iso: 'MT', currency: 'EUR' },
  { name: 'Croatia', iso: 'HR', currency: 'EUR' },
  { name: 'Andorra', iso: 'AD', currency: 'EUR' },
  { name: 'Monaco', iso: 'MC', currency: 'EUR' },
  { name: 'San Marino', iso: 'SM', currency: 'EUR' },
  { name: 'Vatican City', iso: 'VA', currency: 'EUR' },
  { name: 'Kosovo', iso: 'XK', currency: 'EUR' },
  { name: 'Montenegro', iso: 'ME', currency: 'EUR' },

  // Everyone else, with their own real local currency
  { name: 'Afghanistan', iso: 'AF', currency: 'AFN' },
  { name: 'Albania', iso: 'AL', currency: 'ALL' },
  { name: 'Algeria', iso: 'DZ', currency: 'DZD' },
  { name: 'Angola', iso: 'AO', currency: 'AOA' },
  { name: 'Argentina', iso: 'AR', currency: 'ARS' },
  { name: 'Armenia', iso: 'AM', currency: 'AMD' },
  { name: 'Azerbaijan', iso: 'AZ', currency: 'AZN' },
  { name: 'Bahamas', iso: 'BS', currency: 'BSD' },
  { name: 'Bahrain', iso: 'BH', currency: 'BHD' },
  { name: 'Bangladesh', iso: 'BD', currency: 'BDT' },
  { name: 'Barbados', iso: 'BB', currency: 'BBD' },
  { name: 'Belarus', iso: 'BY', currency: 'BYN' },
  { name: 'Belize', iso: 'BZ', currency: 'BZD' },
  { name: 'Benin', iso: 'BJ', currency: 'XOF' },
  { name: 'Bhutan', iso: 'BT', currency: 'BTN' },
  { name: 'Bolivia', iso: 'BO', currency: 'BOB' },
  { name: 'Bosnia and Herzegovina', iso: 'BA', currency: 'BAM' },
  { name: 'Botswana', iso: 'BW', currency: 'BWP' },
  { name: 'Brazil', iso: 'BR', currency: 'BRL' },
  { name: 'Brunei', iso: 'BN', currency: 'BND' },
  { name: 'Bulgaria', iso: 'BG', currency: 'BGN' },
  { name: 'Burkina Faso', iso: 'BF', currency: 'XOF' },
  { name: 'Burundi', iso: 'BI', currency: 'BIF' },
  { name: 'Cabo Verde', iso: 'CV', currency: 'CVE' },
  { name: 'Cambodia', iso: 'KH', currency: 'KHR' },
  { name: 'Cameroon', iso: 'CM', currency: 'XAF' },
  { name: 'Central African Republic', iso: 'CF', currency: 'XAF' },
  { name: 'Chad', iso: 'TD', currency: 'XAF' },
  { name: 'Chile', iso: 'CL', currency: 'CLP' },
  { name: 'China', iso: 'CN', currency: 'CNY' },
  { name: 'Colombia', iso: 'CO', currency: 'COP' },
  { name: 'Comoros', iso: 'KM', currency: 'KMF' },
  { name: 'Congo', iso: 'CG', currency: 'XAF' },
  { name: 'Congo (DRC)', iso: 'CD', currency: 'CDF' },
  { name: 'Costa Rica', iso: 'CR', currency: 'CRC' },
  { name: 'Cuba', iso: 'CU', currency: 'CUP' },
  { name: 'Czech Republic', iso: 'CZ', currency: 'CZK' },
  { name: 'Denmark', iso: 'DK', currency: 'DKK' },
  { name: 'Djibouti', iso: 'DJ', currency: 'DJF' },
  { name: 'Dominica', iso: 'DM', currency: 'XCD' },
  { name: 'Dominican Republic', iso: 'DO', currency: 'DOP' },
  { name: 'Ecuador', iso: 'EC', currency: 'USD' },
  { name: 'Egypt', iso: 'EG', currency: 'EGP' },
  { name: 'El Salvador', iso: 'SV', currency: 'USD' },
  { name: 'Equatorial Guinea', iso: 'GQ', currency: 'XAF' },
  { name: 'Eritrea', iso: 'ER', currency: 'ERN' },
  { name: 'Eswatini', iso: 'SZ', currency: 'SZL' },
  { name: 'Ethiopia', iso: 'ET', currency: 'ETB' },
  { name: 'Fiji', iso: 'FJ', currency: 'FJD' },
  { name: 'Gabon', iso: 'GA', currency: 'XAF' },
  { name: 'Gambia', iso: 'GM', currency: 'GMD' },
  { name: 'Georgia', iso: 'GE', currency: 'GEL' },
  { name: 'Ghana', iso: 'GH', currency: 'GHS' },
  { name: 'Grenada', iso: 'GD', currency: 'XCD' },
  { name: 'Guatemala', iso: 'GT', currency: 'GTQ' },
  { name: 'Guinea', iso: 'GN', currency: 'GNF' },
  { name: 'Guinea-Bissau', iso: 'GW', currency: 'XOF' },
  { name: 'Guyana', iso: 'GY', currency: 'GYD' },
  { name: 'Haiti', iso: 'HT', currency: 'HTG' },
  { name: 'Honduras', iso: 'HN', currency: 'HNL' },
  { name: 'Hong Kong', iso: 'HK', currency: 'HKD' },
  { name: 'Hungary', iso: 'HU', currency: 'HUF' },
  { name: 'Iceland', iso: 'IS', currency: 'ISK' },
  { name: 'Indonesia', iso: 'ID', currency: 'IDR' },
  { name: 'Iran', iso: 'IR', currency: 'IRR' },
  { name: 'Iraq', iso: 'IQ', currency: 'IQD' },
  { name: 'Israel', iso: 'IL', currency: 'ILS' },
  { name: 'Ivory Coast', iso: 'CI', currency: 'XOF' },
  { name: 'Jamaica', iso: 'JM', currency: 'JMD' },
  { name: 'Japan', iso: 'JP', currency: 'JPY' },
  { name: 'Jordan', iso: 'JO', currency: 'JOD' },
  { name: 'Kazakhstan', iso: 'KZ', currency: 'KZT' },
  { name: 'Kenya', iso: 'KE', currency: 'KES' },
  { name: 'Kiribati', iso: 'KI', currency: 'AUD' },
  { name: 'Kuwait', iso: 'KW', currency: 'KWD' },
  { name: 'Kyrgyzstan', iso: 'KG', currency: 'KGS' },
  { name: 'Laos', iso: 'LA', currency: 'LAK' },
  { name: 'Lebanon', iso: 'LB', currency: 'LBP' },
  { name: 'Lesotho', iso: 'LS', currency: 'LSL' },
  { name: 'Liberia', iso: 'LR', currency: 'LRD' },
  { name: 'Libya', iso: 'LY', currency: 'LYD' },
  { name: 'Liechtenstein', iso: 'LI', currency: 'CHF' },
  { name: 'Macau', iso: 'MO', currency: 'MOP' },
  { name: 'Madagascar', iso: 'MG', currency: 'MGA' },
  { name: 'Malawi', iso: 'MW', currency: 'MWK' },
  { name: 'Malaysia', iso: 'MY', currency: 'MYR' },
  { name: 'Maldives', iso: 'MV', currency: 'MVR' },
  { name: 'Mali', iso: 'ML', currency: 'XOF' },
  { name: 'Marshall Islands', iso: 'MH', currency: 'USD' },
  { name: 'Mauritania', iso: 'MR', currency: 'MRU' },
  { name: 'Mauritius', iso: 'MU', currency: 'MUR' },
  { name: 'Mexico', iso: 'MX', currency: 'MXN' },
  { name: 'Micronesia', iso: 'FM', currency: 'USD' },
  { name: 'Moldova', iso: 'MD', currency: 'MDL' },
  { name: 'Mongolia', iso: 'MN', currency: 'MNT' },
  { name: 'Morocco', iso: 'MA', currency: 'MAD' },
  { name: 'Mozambique', iso: 'MZ', currency: 'MZN' },
  { name: 'Myanmar', iso: 'MM', currency: 'MMK' },
  { name: 'Namibia', iso: 'NA', currency: 'NAD' },
  { name: 'Nauru', iso: 'NR', currency: 'AUD' },
  { name: 'Nepal', iso: 'NP', currency: 'NPR' },
  { name: 'New Zealand', iso: 'NZ', currency: 'NZD' },
  { name: 'Nicaragua', iso: 'NI', currency: 'NIO' },
  { name: 'Niger', iso: 'NE', currency: 'XOF' },
  { name: 'Nigeria', iso: 'NG', currency: 'NGN' },
  { name: 'North Korea', iso: 'KP', currency: 'KPW' },
  { name: 'North Macedonia', iso: 'MK', currency: 'MKD' },
  { name: 'Norway', iso: 'NO', currency: 'NOK' },
  { name: 'Oman', iso: 'OM', currency: 'OMR' },
  { name: 'Pakistan', iso: 'PK', currency: 'PKR' },
  { name: 'Palau', iso: 'PW', currency: 'USD' },
  { name: 'Palestine', iso: 'PS', currency: 'ILS' },
  { name: 'Panama', iso: 'PA', currency: 'PAB' },
  { name: 'Papua New Guinea', iso: 'PG', currency: 'PGK' },
  { name: 'Paraguay', iso: 'PY', currency: 'PYG' },
  { name: 'Peru', iso: 'PE', currency: 'PEN' },
  { name: 'Philippines', iso: 'PH', currency: 'PHP' },
  { name: 'Poland', iso: 'PL', currency: 'PLN' },
  { name: 'Qatar', iso: 'QA', currency: 'QAR' },
  { name: 'Romania', iso: 'RO', currency: 'RON' },
  { name: 'Russia', iso: 'RU', currency: 'RUB' },
  { name: 'Rwanda', iso: 'RW', currency: 'RWF' },
  { name: 'Saint Kitts and Nevis', iso: 'KN', currency: 'XCD' },
  { name: 'Saint Lucia', iso: 'LC', currency: 'XCD' },
  { name: 'Saint Vincent and the Grenadines', iso: 'VC', currency: 'XCD' },
  { name: 'Samoa', iso: 'WS', currency: 'WST' },
  { name: 'Sao Tome and Principe', iso: 'ST', currency: 'STN' },
  { name: 'Saudi Arabia', iso: 'SA', currency: 'SAR' },
  { name: 'Senegal', iso: 'SN', currency: 'XOF' },
  { name: 'Serbia', iso: 'RS', currency: 'RSD' },
  { name: 'Seychelles', iso: 'SC', currency: 'SCR' },
  { name: 'Sierra Leone', iso: 'SL', currency: 'SLE' },
  { name: 'Solomon Islands', iso: 'SB', currency: 'SBD' },
  { name: 'Somalia', iso: 'SO', currency: 'SOS' },
  { name: 'South Africa', iso: 'ZA', currency: 'ZAR' },
  { name: 'South Korea', iso: 'KR', currency: 'KRW' },
  { name: 'South Sudan', iso: 'SS', currency: 'SSP' },
  { name: 'Sri Lanka', iso: 'LK', currency: 'LKR' },
  { name: 'Sudan', iso: 'SD', currency: 'SDG' },
  { name: 'Suriname', iso: 'SR', currency: 'SRD' },
  { name: 'Sweden', iso: 'SE', currency: 'SEK' },
  { name: 'Switzerland', iso: 'CH', currency: 'CHF' },
  { name: 'Syria', iso: 'SY', currency: 'SYP' },
  { name: 'Taiwan', iso: 'TW', currency: 'TWD' },
  { name: 'Tajikistan', iso: 'TJ', currency: 'TJS' },
  { name: 'Tanzania', iso: 'TZ', currency: 'TZS' },
  { name: 'Thailand', iso: 'TH', currency: 'THB' },
  { name: 'Timor-Leste', iso: 'TL', currency: 'USD' },
  { name: 'Togo', iso: 'TG', currency: 'XOF' },
  { name: 'Tonga', iso: 'TO', currency: 'TOP' },
  { name: 'Trinidad and Tobago', iso: 'TT', currency: 'TTD' },
  { name: 'Tunisia', iso: 'TN', currency: 'TND' },
  { name: 'Turkey', iso: 'TR', currency: 'TRY' },
  { name: 'Turkmenistan', iso: 'TM', currency: 'TMT' },
  { name: 'Tuvalu', iso: 'TV', currency: 'AUD' },
  { name: 'Uganda', iso: 'UG', currency: 'UGX' },
  { name: 'Ukraine', iso: 'UA', currency: 'UAH' },
  { name: 'Uruguay', iso: 'UY', currency: 'UYU' },
  { name: 'Uzbekistan', iso: 'UZ', currency: 'UZS' },
  { name: 'Vanuatu', iso: 'VU', currency: 'VUV' },
  { name: 'Venezuela', iso: 'VE', currency: 'VES' },
  { name: 'Vietnam', iso: 'VN', currency: 'VND' },
  { name: 'Yemen', iso: 'YE', currency: 'YER' },
  { name: 'Zambia', iso: 'ZM', currency: 'ZMW' },
  { name: 'Zimbabwe', iso: 'ZW', currency: 'ZWL' },
];

export const COUNTRY_TO_CURRENCY: Record<string, string> = Object.fromEntries(
  COUNTRIES.map((c) => [c.name, c.currency]),
);

// India first (it's the checkout form's default selection), everything else
// alphabetical — a 198-option dropdown is unusable in declaration order.
export const CHECKOUT_COUNTRIES = [
  'India',
  ...COUNTRIES.filter((c) => c.name !== 'India').map((c) => c.name).sort(),
];

// ISO 3166-1 alpha-2 codes, used for CJ Dropshipping order submission and
// Meta CAPI's country field.
export const COUNTRY_TO_ISO_CODE: Record<string, string> = Object.fromEntries(
  COUNTRIES.map((c) => [c.name, c.iso]),
);

// Reverse of COUNTRY_TO_ISO_CODE — Razorpay's Magic Checkout returns the
// customer's address with an ISO country code, but the rest of this codebase
// (tax engine, admin UI) works in full country names.
export const ISO_CODE_TO_COUNTRY: Record<string, string> = Object.fromEntries(
  COUNTRIES.map((c) => [c.iso, c.name]),
);

export function currencyForCountry(country: string): string {
  return COUNTRY_TO_CURRENCY[country] ?? 'USD';
}

// Only a handful of currencies actually have an admin-configured exchange
// rate at any given time (/admin/settings) — everything else falls back to
// USD (itself always expected to be configured, being the default
// international currency) rather than either inventing a rate or blocking
// checkout outright. Both the browsing-time price display
// (request-currency.ts) and the real checkout charge (order-tax.ts) call
// this same function, so a visitor never sees one currency while browsing
// and gets charged in a different one.
export function resolveConfiguredCurrency(
  preferredCurrency: string,
  rates: Record<string, number | string>,
): { currency: string; rate: number } {
  const preferredRate = Number(rates[preferredCurrency]);
  if (preferredRate > 0) return { currency: preferredCurrency, rate: preferredRate };

  const usdRate = Number(rates.USD);
  if (usdRate > 0) return { currency: 'USD', rate: usdRate };

  return { currency: 'USD', rate: 0.012 }; // last-resort guess if even USD isn't configured yet
}
