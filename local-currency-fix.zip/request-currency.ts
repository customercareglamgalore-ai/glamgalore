// Server-only: reads the `geo_currency` cookie set by middleware
// (IP-geolocation, cached 24h) and, for non-India visitors, looks up the
// configured INR->currency rate once. Call this once per page render (not
// once per product) and thread the result down via <CurrencyProvider> —
// avoids a StoreSettings query per product price on pages that list many
// products. The pure formatting function this feeds (localizePrice) lives in
// ./localize-price.ts instead, so client components can import just that
// without pulling in next/headers + prisma.
import { cookies } from 'next/headers';
import { prisma } from '@/lib/db';
import { isIndiaCountry } from './international-pricing';
import { resolveConfiguredCurrency } from './currency';
import { INDIA_CURRENCY, type RequestCurrency } from './localize-price';

export type { RequestCurrency };

export async function getRequestCurrency(): Promise<RequestCurrency> {
  const cookieStore = await cookies();
  const cached = cookieStore.get('geo_currency')?.value;
  const [rawCountry, rawCurrency] = cached ? cached.split(':') : ['India', 'INR'];
  const country = rawCountry || 'India';

  if (isIndiaCountry(country)) return INDIA_CURRENCY;

  const settings = await prisma.storeSettings.findUnique({ where: { id: 'singleton' }, select: { currencyRates: true } });
  const rates = (settings?.currencyRates as Record<string, number>) || {};
  const { currency, rate } = resolveConfiguredCurrency(rawCurrency || 'USD', rates);
  return { country, currency, rate };
}
