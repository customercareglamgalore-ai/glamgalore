'use client';

import { useEffect, useState } from 'react';
import { currencySymbol } from '@/lib/localize-price';

type CartItem = { productId: string; variantId?: string | null; quantity: number };

export type Quote = {
  taxType: 'intra_state' | 'inter_state' | 'export_zero_rated' | 'export_taxed';
  subtotal: number;
  shippingCost: number;
  grandTotal: number;
  currency: string;
  discountAmount: number;
  discountCode: string | null;
  discountError: string | null;
};

export default function CheckoutSummary({
  cartItems,
  country,
  state,
  discountCode,
  onDiscountCodeChange,
  onQuoteChange,
}: {
  cartItems: CartItem[];
  country: string;
  state: string;
  discountCode: string;
  onDiscountCodeChange: (code: string) => void;
  // Reports the resolved quote back up so the parent's "Pay" button can show
  // the exact same currency/amount this summary does — without this, the
  // button and the summary could show two different numbers for the same
  // order (button computed from raw India prices, summary from the real
  // country-resolved currency).
  onQuoteChange?: (quote: Quote | null) => void;
}) {
  const [quote, setQuote] = useState<Quote | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [codeInput, setCodeInput] = useState(discountCode);

  useEffect(() => {
    if (cartItems.length === 0) return;
    const timer = setTimeout(() => {
      fetch('/api/checkout/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cartItems, country, state, discountCode }),
      })
        .then((r) => r.json())
        .then((data) => {
          if (data.error) {
            setError(data.error);
            setQuote(null);
            onQuoteChange?.(null);
          } else {
            setError(null);
            setQuote(data);
            onQuoteChange?.(data);
          }
        })
        .catch(() => setError('Could not calculate tax right now.'));
    }, 250);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(cartItems), country, state, discountCode]);

  if (error) return <p style={{ color: '#e22120', fontSize: 13 }}>{error}</p>;
  if (!quote) return <p style={{ fontSize: 13, color: '#999' }}>Calculating total...</p>;

  const rowStyle: React.CSSProperties = { display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: 14 };
  const isZeroTax = quote.taxType === 'export_zero_rated';
  const symbol = currencySymbol(quote.currency);
  // /api/checkout/quote already converts+rounds every amount into the
  // resolved currency (matching what create-order will actually charge) —
  // INR keeps its usual 2 decimals, everything else is already a whole
  // number from that rounding, so no decimals needed on top of it.
  const fmt = (n: number) => (quote.currency === 'INR' ? n.toFixed(2) : String(n));

  return (
    <div style={{ border: '1px solid #eee', padding: 16, margin: '16px 0' }}>
      <div style={rowStyle}>
        <span>Product Subtotal</span>
        <span>{symbol}{fmt(quote.subtotal)}</span>
      </div>
      {quote.discountAmount > 0 && (
        <div style={{ ...rowStyle, color: '#e22120' }}>
          <span>Discount ({quote.discountCode})</span>
          <span>-{symbol}{fmt(quote.discountAmount)}</span>
        </div>
      )}
      <div style={rowStyle}>
        <span>Shipping</span>
        <span>{quote.shippingCost === 0 ? 'Free' : `${symbol}${fmt(quote.shippingCost)}`}</span>
      </div>
      <div style={{ ...rowStyle, borderTop: '1px solid #eee', marginTop: 8, paddingTop: 12, fontWeight: 600 }}>
        <span>Grand Total</span>
        <span>{symbol}{fmt(quote.grandTotal)}</span>
      </div>
      <p style={{ fontSize: 12, color: '#999', margin: '6px 0 0', textAlign: 'right' }}>
        {isZeroTax ? 'No taxes charged on international orders' : 'Inclusive of all taxes'}
      </p>

      <div style={{ display: 'flex', gap: 8, marginTop: 12, paddingTop: 12, borderTop: '1px solid #eee' }}>
        <input
          placeholder="Discount code"
          value={codeInput}
          onChange={(e) => setCodeInput(e.target.value)}
          style={{ flex: 1, padding: 8, border: '1px solid #ccc', fontSize: 13 }}
        />
        <button
          type="button"
          onClick={() => onDiscountCodeChange(codeInput)}
          style={{ padding: '8px 14px', background: '#000', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 13 }}
        >
          Apply
        </button>
      </div>
      {quote.discountError && <p style={{ color: '#e22120', fontSize: 12, marginTop: 6 }}>{quote.discountError}</p>}
    </div>
  );
}
