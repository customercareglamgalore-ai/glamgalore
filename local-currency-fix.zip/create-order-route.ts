// Creates a Razorpay order server-side, before showing the payment sheet.
// This is the secure pattern: never trust an amount sent from the browser —
// always recompute it (and the GST breakdown) from the cart/address stored
// in your database and submitted shipping address.

import { NextRequest, NextResponse } from 'next/server';
import Razorpay from 'razorpay';
import { prisma } from '@/lib/db';
import { getCustomerIdFromSession, hashPassword, setSessionCookie } from '@/lib/auth';
import { buildOrderTax, OrderTaxError } from '@/lib/order-tax';
import crypto from 'crypto';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

const CURRENCY_MINOR_UNIT_FACTOR = 100; // all currently supported currencies use 2 decimal places

export async function POST(req: NextRequest) {
  const { cartItems, shippingAddress, discountCode } = await req.json();
  if (!Array.isArray(cartItems) || cartItems.length === 0) {
    return NextResponse.json({ error: 'Cart is empty' }, { status: 400 });
  }

  // Enforced server-side, not just via the form's `required` attributes —
  // the whole point of building our own checkout is to guarantee every order
  // has a real name, email, and complete address, unlike Magic Checkout's
  // address form which regularly skipped these.
  const REQUIRED_ADDRESS_FIELDS: Record<string, string> = {
    name: 'Name',
    email: 'Email',
    phone: 'Phone number',
    line1: 'Address line 1',
    city: 'City',
    state: 'State',
    pincode: 'Pincode',
    country: 'Country',
  };
  const missing = Object.entries(REQUIRED_ADDRESS_FIELDS)
    .filter(([key]) => !String(shippingAddress?.[key] || '').trim())
    .map(([, label]) => label);
  if (missing.length > 0) {
    return NextResponse.json({ error: `${missing.join(', ')} ${missing.length > 1 ? 'are' : 'is'} required` }, { status: 400 });
  }

  // Checkout no longer requires a separate "create account" step. If the
  // shopper isn't logged in, transparently find-or-create their customer
  // record from the email they just entered, so there's still an account
  // behind the scenes (for the order-confirmed page, track-order, etc.)
  // without them having to consciously sign up first.
  let customerId = await getCustomerIdFromSession();
  if (!customerId) {
    const email = String(shippingAddress?.email || '').trim().toLowerCase();
    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }
    const existing = await prisma.customer.findUnique({ where: { email } });
    const customer =
      existing ||
      (await prisma.customer.create({
        data: {
          email,
          name: shippingAddress.name || null,
          phone: shippingAddress.phone || null,
          passwordHash: await hashPassword(crypto.randomBytes(32).toString('hex')),
        },
      }));
    customerId = customer.id;
    await setSessionCookie(customerId);
  }

  let computation;
  let lineMeta;
  let discountAmount;
  let appliedDiscountCode;
  let currency;
  let fxRateApplied;
  try {
    let discountError;
    ({ computation, lineMeta, discountAmount, discountCode: appliedDiscountCode, discountError, currency, fxRateApplied } = await buildOrderTax(
      cartItems,
      { state: shippingAddress.state, country: shippingAddress.country },
      discountCode,
    ));
    if (discountError) {
      return NextResponse.json({ error: discountError }, { status: 400 });
    }
  } catch (err) {
    if (err instanceof OrderTaxError) {
      return NextResponse.json({ error: err.message }, { status: err.status });
    }
    throw err;
  }

  // currency/fxRateApplied come from buildOrderTax — the single place that
  // resolves a customer's local currency against admin-configured exchange
  // rates (falling back to USD if their specific currency isn't configured
  // yet), shared with /api/checkout/quote so the live preview a customer
  // sees always matches what they're actually charged here.
  const chargeAmount = currency === 'INR' ? computation.grandTotal : Math.ceil(computation.grandTotal * fxRateApplied);

  const order = await prisma.order.create({
    data: {
      customerId,
      status: 'pending',
      subtotal: computation.subtotal,
      shippingCost: computation.shippingCost,
      total: computation.grandTotal,
      shippingAddress,

      currency,
      fxRateApplied,
      discountCode: appliedDiscountCode,
      discountAmount,
      taxableValue: computation.taxableValue,
      cgstAmount: computation.cgstTotal,
      sgstAmount: computation.sgstTotal,
      igstAmount: computation.igstTotal,
      totalTax: computation.totalTax,
      taxType: computation.taxType,
      gstRatesUsed: computation.lines,
      customerState: shippingAddress.state,
      customerCountry: shippingAddress.country,
      customerGSTIN: shippingAddress.gstin || null,

      items: {
        create: lineMeta.map((meta, i) => {
          const line = computation.lines[i];
          return {
            productId: meta.productId,
            variantId: meta.variantId,
            quantity: meta.quantity,
            unitPrice: meta.unitPrice,
            hsnCode: line.hsnCode,
            gstRate: line.gstRate,
            taxableValue: line.taxableValue,
            cgstAmount: line.cgstAmount,
            sgstAmount: line.sgstAmount,
            igstAmount: line.igstAmount,
          };
        }),
      },
    },
  });

  const razorpayOrder = await razorpay.orders.create({
    amount: Math.round(chargeAmount * CURRENCY_MINOR_UNIT_FACTOR),
    currency,
    receipt: order.id,
  });

  await prisma.order.update({
    where: { id: order.id },
    data: { razorpayOrderId: razorpayOrder.id },
  });

  return NextResponse.json({
    orderId: order.id,
    razorpayOrderId: razorpayOrder.id,
    amount: razorpayOrder.amount,
    currency: razorpayOrder.currency,
    keyId: process.env.RAZORPAY_KEY_ID,
  });
}
