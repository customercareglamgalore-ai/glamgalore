import { prisma } from '@/lib/db';

// StoreSettings is a singleton row (id always "singleton") holding GST/business/
// invoice/currency config, editable from /admin/settings without code changes.
export async function getStoreSettings() {
  return prisma.storeSettings.upsert({
    where: { id: 'singleton' },
    update: {},
    create: { id: 'singleton' },
  });
}

export type StoreSettingsUpdateInput = Partial<{
  businessLegalName: string;
  businessGSTIN: string | null;
  businessAddressLine1: string | null;
  businessAddressLine2: string | null;
  businessCity: string | null;
  businessState: string;
  businessPincode: string | null;
  defaultGstRate: number;
  pricesIncludeTax: boolean;
  chargeTaxOnInternational: boolean;
  useApparelPriceSlabs: boolean;
  apparelSlabThreshold: number;
  apparelSlabRateBelow: number;
  apparelSlabRateAbove: number;
  invoicePrefix: string;
  invoiceNumberPadding: number;
  currencyRates: Record<string, number>;
}>;

export async function updateStoreSettings(data: StoreSettingsUpdateInput) {
  await getStoreSettings(); // ensure the singleton row exists first
  return prisma.storeSettings.update({ where: { id: 'singleton' }, data });
}
