// Creates a Razorpay order server-side, before showing the payment sheet.
// This is the secure pattern: never trust an amount sent from the browser —
// always recompute it (and the GST breakdown) from the cart/address stored
// in your database and submitted shipping address.

import { NextRequest, NextResponse } from 'next/server';
import Razorpay from 'razorpay';
import { prisma } from '@/lib/db';
import { getCustomerIdFromSession } from '@/lib/auth';
import { buildOrderTax, OrderTaxError } from '@/lib/order-tax';
import { currencyForCountry } from '@/lib/currency';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

const CURRENCY_MINOR_UNIT_FACTOR = 100; // all currently supported currencies use 2 decimal places

export async function POST(req: NextRequest) {
  const customerId = await getCustomerIdFromSession();
  if (!customerId) {
    return NextResponse.json({ error: 'You must be logged in to check out' }, { status: 401 });
  }

  const { cartItems, shippingAddress } = await req.json();
  if (!Array.isArray(cartItems) || cartItems.length === 0) {
    return NextResponse.json({ error: 'Cart is empty' }, { status: 400 });
  }
  if (!shippingAddress?.country || !shippingAddress?.state) {
    return NextResponse.json({ error: 'Shipping country and state are required' }, { status: 400 });
  }

  let computation;
  let lineMeta;
  let settings;
  try {
    ({ computation, lineMeta, settings } = await buildOrderTax(cartItems, {
      state: shippingAddress.state,
      country: shippingAddress.country,
    }));
  } catch (err) {
    if (err instanceof OrderTaxError) {
      return NextResponse.json({ error: err.message }, { status: err.status });
    }
    throw err;
  }

  // Currency and the FX rate applied are always re-derived server-side from the
  // submitted country — never trust a client-sent currency string. Domestic
  // (India) orders always stay in INR at a 1:1 rate.
  const isIndia = shippingAddress.country.trim().toLowerCase() === 'india';
  const currency = isIndia ? 'INR' : currencyForCountry(shippingAddress.country);
  let fxRateApplied = 1;
  let chargeAmount = computation.grandTotal;

  if (!isIndia && currency !== 'INR') {
    const rates = (settings.currencyRates as Record<string, number | string>) || {};
    const rate = Number(rates[currency]);
    if (!rate || rate <= 0) {
      return NextResponse.json(
        { error: `No exchange rate configured for ${currency}. Please set one in admin settings.` },
        { status: 400 },
      );
    }
    fxRateApplied = rate;
    chargeAmount = computation.grandTotal * rate;
  }

  const order = await prisma.order.create({
    data: {
      customerId,
      status: 'pending',
      subtotal: computation.subtotal,
      shippingCost: computation.shippingCost,
      total: computation.grandTotal,
      shippingAddress,

      currency,
      fxRateApplied,
      discountAmount: 0,
      taxableValue: computation.taxableValue,
      cgstAmount: computation.cgstTotal,
      sgstAmount: computation.sgstTotal,
      igstAmount: computation.igstTotal,
      totalTax: computation.totalTax,
      taxType: computation.taxType,
      gstRatesUsed: computation.lines,
      customerState: shippingAddress.state,
      customerCountry: shippingAddress.country,
      customerGSTIN: shippingAddress.gstin || null,

      items: {
        create: lineMeta.map((meta, i) => {
          const line = computation.lines[i];
          return {
            productId: meta.productId,
            variantId: meta.variantId,
            quantity: meta.quantity,
            unitPrice: meta.unitPrice,
            hsnCode: line.hsnCode,
            gstRate: line.gstRate,
            taxableValue: line.taxableValue,
            cgstAmount: line.cgstAmount,
            sgstAmount: line.sgstAmount,
            igstAmount: line.igstAmount,
          };
        }),
      },
    },
  });

  const razorpayOrder = await razorpay.orders.create({
    amount: Math.round(chargeAmount * CURRENCY_MINOR_UNIT_FACTOR),
    currency,
    receipt: order.id,
  });

  await prisma.order.update({
    where: { id: order.id },
    data: { razorpayOrderId: razorpayOrder.id },
  });

  return NextResponse.json({
    orderId: order.id,
    razorpayOrderId: razorpayOrder.id,
    amount: razorpayOrder.amount,
    currency: razorpayOrder.currency,
    keyId: process.env.RAZORPAY_KEY_ID,
  });
}
