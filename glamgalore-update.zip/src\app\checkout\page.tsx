'use client';

import { useEffect, useState } from 'react';
import Script from 'next/script';
import Reveal from '@/components/Reveal';
import CheckoutSummary from '@/components/CheckoutSummary';
import { CHECKOUT_COUNTRIES } from '@/lib/currency';
import { trackMetaEvent } from '@/components/MetaPixel';
import { notifyCartUpdated } from '@/lib/cart-count';

export default function CheckoutPage() {
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [form, setForm] = useState({
    name: '', email: '', phone: '',
    line1: '', line2: '', city: '', state: '', pincode: '', country: 'India',
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cartItems, setCartItems] = useState<{ productId: string; variantId?: string | null; quantity: number }[]>([]);

  useEffect(() => {
    const items = JSON.parse(localStorage.getItem('cart') || '[]');
    setCartItems(items);
    if (items.length > 0) {
      trackMetaEvent('InitiateCheckout', {
        content_ids: items.map((i: { productId: string }) => i.productId),
        content_type: 'product',
        num_items: items.reduce((sum: number, i: { quantity: number }) => sum + i.quantity, 0),
      });
    }
  }, []);

  useEffect(() => {
    // Best-effort prefill only — the customer can always override, and the
    // submitted value (not this guess) is what actually determines tax/currency.
    fetch('/api/geo/currency')
      .then((res) => res.json())
      .then(({ country }) => {
        if (country) setForm((f) => ({ ...f, country }));
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    // Best-effort prefill if the customer happens to already be logged in —
    // but checkout no longer requires an account. A guest just fills in the
    // form below; the backend finds-or-creates the account behind the
    // scenes from the email they enter.
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then(({ customer }) => {
        if (customer) {
          setForm((f) => ({ ...f, name: customer.name || f.name, email: customer.email || f.email }));
        }
      })
      .finally(() => setCheckingAuth(false));
  }, []);

  async function handlePay() {
    setSubmitting(true);
    setError(null);

    try {
      if (typeof window === 'undefined' || !(window as any).Razorpay) {
        setError('Payment gateway is still loading — please wait a moment and try again.');
        return;
      }

      const cartItems = JSON.parse(localStorage.getItem('cart') || '[]');

      // 1. Create the order server-side (recomputes total from the DB,
      //    customer comes from the session cookie — not the request body).
      const res = await fetch('/api/checkout/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cartItems, shippingAddress: form }),
      });
      if (!res.ok) {
        const { error: message } = await res.json();
        setError(message || 'Something went wrong. Please try again.');
        return;
      }
      const order = await res.json();

      // 2. Open Razorpay's checkout sheet.
      const options = {
        key: order.keyId,
        amount: order.amount,
        currency: order.currency,
        name: 'Glam Galore',
        order_id: order.razorpayOrderId,
        prefill: { name: form.name, email: form.email, contact: form.phone },
        handler: async function (response: any) {
          // 3. Verify the payment signature server-side, then submit to CJ.
          try {
            const verifyRes = await fetch('/api/checkout/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(response),
            });
            const result = await verifyRes.json();
            if (result.success) {
              localStorage.removeItem('cart');
              notifyCartUpdated();
              window.location.href = `/order-confirmed?orderId=${result.orderId}`;
            } else {
              setError('Payment received, but confirming your order failed. Please contact support with your payment ID.');
            }
          } catch {
            setError('Payment received, but confirming your order failed. Please contact support with your payment ID.');
          }
        },
        modal: {
          ondismiss: () => setSubmitting(false),
        },
        theme: { color: '#e22120' },
      };

      const rzp = new (window as any).Razorpay(options);
      rzp.open();
    } catch (err) {
      console.error('Checkout failed:', err);
      setError('Something went wrong starting checkout. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  if (checkingAuth) {
    return (
      <main className="container">
        <p>Loading checkout...</p>
      </main>
    );
  }

  return (
    <main className="container">
      <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="afterInteractive" />
      <Reveal>
        <h1 className="section-heading">Checkout</h1>

        <form onSubmit={(e) => { e.preventDefault(); handlePay(); }} style={{ maxWidth: 480, margin: '0 auto' }}>
          {error && <p style={{ color: '#e22120' }}>{error}</p>}
          {(['name', 'email', 'phone', 'line1', 'line2', 'city', 'state', 'pincode'] as const).map((field) => (
            <input
              key={field}
              placeholder={field}
              value={form[field]}
              onChange={(e) => setForm({ ...form, [field]: e.target.value })}
              required={field !== 'line2'}
              style={{ display: 'block', width: '100%', padding: 10, margin: '8px 0' }}
            />
          ))}
          <select
            value={form.country}
            onChange={(e) => setForm({ ...form, country: e.target.value })}
            style={{ display: 'block', width: '100%', padding: 10, margin: '8px 0' }}
          >
            {CHECKOUT_COUNTRIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <CheckoutSummary cartItems={cartItems} country={form.country} state={form.state} />

          <button type="submit" className="btn" disabled={submitting} style={{ width: '100%' }}>
            {submitting ? 'Processing...' : 'Pay with Razorpay'}
          </button>
        </form>
      </Reveal>
    </main>
  );
}
