// Gates /admin/* pages and /api/admin/* routes behind HTTP Basic Auth.
// Only safe once the site is served over HTTPS (Basic Auth credentials are
// base64, not encrypted) — make sure TLS is terminated in front of this
// before it's relied on in production.
import { NextRequest, NextResponse } from 'next/server';

export const config = {
  matcher: ['/admin/:path*', '/api/admin/:path*'],
};

export function middleware(req: NextRequest) {
  const expectedUser = process.env.ADMIN_USER;
  const expectedPassword = process.env.ADMIN_PASSWORD;

  if (!expectedUser || !expectedPassword) {
    return new NextResponse('Admin auth is not configured (set ADMIN_USER / ADMIN_PASSWORD)', { status: 500 });
  }

  const authHeader = req.headers.get('authorization');
  const expected = 'Basic ' + Buffer.from(`${expectedUser}:${expectedPassword}`).toString('base64');

  if (authHeader !== expected) {
    return new NextResponse('Authentication required', {
      status: 401,
      headers: { 'WWW-Authenticate': 'Basic realm="Admin"' },
    });
  }

  return NextResponse.next();
}
