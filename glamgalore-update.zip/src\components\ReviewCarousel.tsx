'use client';

import { useRef } from 'react';

type ReviewCard = {
  id: string;
  authorName: string;
  rating: number;
  body: string;
  imageUrl?: string | null;
  productTitle?: string;
};

export default function ReviewCarousel({ reviews }: { reviews: ReviewCard[] }) {
  const trackRef = useRef<HTMLDivElement>(null);

  function scrollByCard(direction: 1 | -1) {
    const track = trackRef.current;
    if (!track) return;
    const card = track.querySelector('.review-card') as HTMLElement | null;
    const amount = card ? card.offsetWidth + 24 : 300;
    track.scrollBy({ left: amount * direction, behavior: 'smooth' });
  }

  return (
    <div className="review-carousel">
      <div className="review-carousel-track" ref={trackRef}>
        {reviews.map((r) => (
          <div className="review-card" key={r.id}>
            {r.imageUrl && (
              <div className="review-card-image">
                <img src={r.imageUrl} alt={r.authorName} loading="lazy" />
              </div>
            )}
            <div className="review-card-stars">{'★'.repeat(r.rating)}</div>
            <p className="review-card-body">&ldquo;{r.body}&rdquo;</p>
            <p className="review-card-author">
              {r.authorName}
              {r.productTitle ? ` — ${r.productTitle}` : ''}
            </p>
          </div>
        ))}
      </div>
      <div className="review-carousel-nav">
        <button type="button" aria-label="Previous review" onClick={() => scrollByCard(-1)}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
            <polyline points="15 6 9 12 15 18" />
          </svg>
        </button>
        <button type="button" aria-label="Next review" onClick={() => scrollByCard(1)}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
            <polyline points="9 6 15 12 9 18" />
          </svg>
        </button>
      </div>
    </div>
  );
}
