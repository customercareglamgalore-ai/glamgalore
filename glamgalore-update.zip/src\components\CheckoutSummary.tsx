'use client';

import { useEffect, useState } from 'react';

type CartItem = { productId: string; variantId?: string | null; quantity: number };

type Quote = {
  taxType: 'intra_state' | 'inter_state' | 'export_zero_rated' | 'export_taxed';
  subtotal: number;
  shippingCost: number;
  grandTotal: number;
  currency: string;
};

export default function CheckoutSummary({
  cartItems,
  country,
  state,
}: {
  cartItems: CartItem[];
  country: string;
  state: string;
}) {
  const [quote, setQuote] = useState<Quote | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (cartItems.length === 0) return;
    const timer = setTimeout(() => {
      fetch('/api/checkout/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cartItems, country, state }),
      })
        .then((r) => r.json())
        .then((data) => {
          if (data.error) {
            setError(data.error);
            setQuote(null);
          } else {
            setError(null);
            setQuote(data);
          }
        })
        .catch(() => setError('Could not calculate tax right now.'));
    }, 250);
    return () => clearTimeout(timer);
  }, [JSON.stringify(cartItems), country, state]);

  if (error) return <p style={{ color: '#e22120', fontSize: 13 }}>{error}</p>;
  if (!quote) return <p style={{ fontSize: 13, color: '#999' }}>Calculating total...</p>;

  const rowStyle: React.CSSProperties = { display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: 14 };
  const isZeroTax = quote.taxType === 'export_zero_rated';

  return (
    <div style={{ border: '1px solid #eee', padding: 16, margin: '16px 0' }}>
      <div style={rowStyle}>
        <span>Product Subtotal</span>
        <span>₹{quote.subtotal.toFixed(2)}</span>
      </div>
      <div style={rowStyle}>
        <span>Shipping</span>
        <span>{quote.shippingCost === 0 ? 'Free' : `₹${quote.shippingCost.toFixed(2)}`}</span>
      </div>
      <div style={{ ...rowStyle, borderTop: '1px solid #eee', marginTop: 8, paddingTop: 12, fontWeight: 600 }}>
        <span>Grand Total</span>
        <span>₹{quote.grandTotal.toFixed(2)}</span>
      </div>
      <p style={{ fontSize: 12, color: '#999', margin: '6px 0 0', textAlign: 'right' }}>
        {isZeroTax ? 'No taxes charged on international orders' : 'Inclusive of all taxes'}
      </p>
    </div>
  );
}
