import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

// Search/list orders for the admin orders page. Protected by middleware's
// HTTP Basic Auth on /api/admin/*, same as every other admin route.
//
// Matches by GG invoice number, internal id, customer name/email, or phone
// (from either the Customer record or the order's own shippingAddress —
// they can differ, e.g. a guest checkout or a number typed slightly
// differently). Phone matching is digit-only so "+91 98765 43210",
// "9876543210", and "098765-43210" all match the same search.
//
// Done as a bounded fetch + in-memory filter (not a DB WHERE) because phone
// formatting varies too much across shippingAddress (free-text JSON) to
// reliably match with a SQL `contains` — this mirrors the same digit-strip
// approach used in every one-off order lookup done manually until now.
const RESULT_LIMIT = 2000;

function normalizeDigits(s: string | null | undefined): string {
  return String(s || '').replace(/\D/g, '');
}

export async function GET(req: NextRequest) {
  const q = (req.nextUrl.searchParams.get('q') || '').trim();

  const orders = await prisma.order.findMany({
    orderBy: { createdAt: 'desc' },
    take: RESULT_LIMIT,
    include: { customer: true, items: true },
  });

  const qDigits = normalizeDigits(q);
  const qLower = q.toLowerCase();

  const filtered = q
    ? orders.filter((o) => {
        const addr = (o.shippingAddress as { name?: string; phone?: string } | null) || {};
        const haystackText = [o.invoiceNumber, o.id, o.customer?.name, o.customer?.email, addr.name]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        if (haystackText.includes(qLower)) return true;

        if (qDigits.length >= 4) {
          const phoneDigits = [normalizeDigits(o.customer?.phone), normalizeDigits(addr.phone)];
          if (phoneDigits.some((p) => p.includes(qDigits))) return true;
        }
        return false;
      })
    : orders.slice(0, 100); // no query — just show the most recent 100

  const rows = filtered.slice(0, 200).map((o) => ({
    id: o.id,
    invoiceNumber: o.invoiceNumber,
    createdAt: o.createdAt,
    customerName: (o.shippingAddress as { name?: string } | null)?.name || o.customer?.name || o.customer?.email || '',
    phone: (o.shippingAddress as { phone?: string } | null)?.phone || o.customer?.phone || '',
    total: o.total,
    currency: o.currency,
    discountCode: o.discountCode,
    discountAmount: o.discountAmount,
    status: o.status,
    paymentStatus: o.paymentStatus,
    refundStatus: o.refundStatus,
    refundedAmount: o.refundedAmount,
    itemCount: o.items.reduce((sum, i) => sum + i.quantity, 0),
  }));

  return NextResponse.json({ orders: rows, truncated: filtered.length > 200 });
}
