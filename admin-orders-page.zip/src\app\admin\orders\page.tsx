'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

type OrderRow = {
  id: string;
  invoiceNumber: string | null;
  createdAt: string;
  customerName: string;
  phone: string;
  total: string;
  currency: string;
  discountCode: string | null;
  discountAmount: string;
  status: string;
  paymentStatus: string;
  refundStatus: string;
  refundedAmount: string;
  itemCount: number;
};

const inputStyle: React.CSSProperties = { padding: 8, border: '1px solid #ccc', fontSize: 13 };
const btnStyle: React.CSSProperties = { padding: '8px 16px', background: '#000', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 13 };
const thStyle: React.CSSProperties = { padding: 6, textAlign: 'left', fontSize: 11, color: '#666', borderBottom: '1px solid #ccc' };
const tdStyle: React.CSSProperties = { padding: 6, fontSize: 13, borderBottom: '1px solid #f3f3f3' };

function money(v: string, currency: string) {
  const symbol = currency === 'INR' ? '₹' : currency + ' ';
  return symbol + Number(v).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function AdminOrdersPage() {
  const [q, setQ] = useState('');
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [truncated, setTruncated] = useState(false);

  function search(query: string) {
    setLoading(true);
    fetch(`/api/admin/orders?q=${encodeURIComponent(query)}`)
      .then((r) => r.json())
      .then((data) => {
        setOrders(data.orders);
        setTruncated(data.truncated);
      })
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    search(''); // most recent 100 on first load
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <main style={{ padding: 40, maxWidth: 1100, margin: '0 auto', fontFamily: 'system-ui' }}>
      <h1 style={{ fontSize: 20 }}>Orders</h1>
      <p style={{ fontSize: 12, color: '#999' }}>
        Search by GG number, customer name, email, or phone (any format — digits are matched regardless of spacing/+91).
        Blank search shows the 100 most recent orders.
      </p>

      <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
        <input
          style={{ ...inputStyle, flex: 1 }}
          placeholder="GG451994, phone number, name, or email"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && search(q)}
        />
        <button style={btnStyle} onClick={() => search(q)} disabled={loading}>
          {loading ? 'Searching…' : 'Search'}
        </button>
      </div>

      {truncated && (
        <p style={{ fontSize: 12, color: '#e29a00', marginTop: 8 }}>
          More than 200 matches — showing the first 200. Narrow your search for a complete list.
        </p>
      )}

      <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: 16 }}>
        <thead>
          <tr>
            <th style={thStyle}>GG#</th>
            <th style={thStyle}>Date</th>
            <th style={thStyle}>Customer</th>
            <th style={thStyle}>Phone</th>
            <th style={thStyle}>Items</th>
            <th style={thStyle}>Total</th>
            <th style={thStyle}>Discount</th>
            <th style={thStyle}>Payment</th>
            <th style={thStyle}>Status</th>
            <th style={thStyle}>Refunded</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((o) => (
            <tr key={o.id}>
              <td style={tdStyle}>
                <Link href={`/admin/orders/${o.id}`} style={{ color: '#000', fontWeight: 600 }}>
                  {o.invoiceNumber || o.id.slice(0, 10) + '…'}
                </Link>
              </td>
              <td style={tdStyle}>{new Date(o.createdAt).toLocaleDateString('en-IN')}</td>
              <td style={tdStyle}>{o.customerName}</td>
              <td style={tdStyle}>{o.phone}</td>
              <td style={tdStyle}>{o.itemCount}</td>
              <td style={tdStyle}>{money(o.total, o.currency)}</td>
              <td style={tdStyle}>
                {o.discountCode ? (
                  <>
                    <strong>{o.discountCode}</strong>
                    <div style={{ fontSize: 11, color: '#999' }}>{money(o.discountAmount, o.currency)}</div>
                  </>
                ) : (
                  <span style={{ color: '#ccc' }}>—</span>
                )}
              </td>
              <td style={tdStyle}>{o.paymentStatus}</td>
              <td style={tdStyle}>{o.status}</td>
              <td style={tdStyle}>
                {Number(o.refundedAmount) > 0 ? `${money(o.refundedAmount, o.currency)} (${o.refundStatus})` : '—'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {!loading && orders.length === 0 && <p style={{ marginTop: 20, color: '#999', fontSize: 13 }}>No orders found.</p>}
    </main>
  );
}
