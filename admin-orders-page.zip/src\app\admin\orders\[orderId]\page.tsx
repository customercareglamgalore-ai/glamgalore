'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';

type OrderDetail = {
  id: string;
  invoiceNumber: string | null;
  createdAt: string;
  status: string;
  paymentStatus: string;
  refundStatus: string;
  refundedAmount: string;
  refundedTax: string;
  total: string;
  subtotal: string;
  shippingCost: string;
  totalTax: string;
  currency: string;
  discountCode: string | null;
  discountAmount: string;
  razorpayPaymentId: string | null;
  cjOrderId: string | null;
  trackingNumber: string | null;
  trackingCarrier: string | null;
  customer: { name: string | null; email: string; phone: string | null } | null;
  shippingAddress: {
    name?: string; email?: string; phone?: string;
    line1?: string; line2?: string; city?: string; state?: string; pincode?: string; country?: string;
  };
  items: {
    id: string;
    quantity: number;
    unitPrice: string;
    product: { title: string; handle: string };
    variant: { optionValue?: string; option2Value?: string; sku?: string } | null;
  }[];
};

const boxStyle: React.CSSProperties = { border: '1px solid #eee', padding: 16, marginTop: 16 };
const labelStyle: React.CSSProperties = { fontSize: 11, color: '#999' };
const valueStyle: React.CSSProperties = { fontSize: 14, marginTop: 2 };
const btnStyle: React.CSSProperties = { padding: '8px 16px', background: '#000', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 13 };
const inputStyle: React.CSSProperties = { padding: 8, border: '1px solid #ccc', fontSize: 13 };

function money(v: string | number, currency: string) {
  const symbol = currency === 'INR' ? '₹' : currency + ' ';
  return symbol + Number(v).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function AdminOrderDetailPage() {
  const params = useParams();
  const orderId = params.orderId as string;

  const [order, setOrder] = useState<OrderDetail | null>(null);
  const [refundAmount, setRefundAmount] = useState('');
  const [refundReason, setRefundReason] = useState('');
  const [refunding, setRefunding] = useState(false);
  const [refundError, setRefundError] = useState<string | null>(null);

  function refresh() {
    fetch(`/api/admin/orders/${orderId}`)
      .then((r) => r.json())
      .then((data) => setOrder(data.order));
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderId]);

  async function submitRefund() {
    if (!order) return;
    const amount = Number(refundAmount);
    if (!amount || amount <= 0) {
      setRefundError('Enter a refund amount greater than 0');
      return;
    }
    setRefunding(true);
    setRefundError(null);
    const res = await fetch(`/api/admin/orders/${orderId}/refund`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount, reason: refundReason || undefined }),
    });
    setRefunding(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setRefundError(data.error || 'Refund failed');
      return;
    }
    setRefundAmount('');
    setRefundReason('');
    refresh();
  }

  if (!order) {
    return (
      <main style={{ padding: 40, maxWidth: 800, margin: '0 auto', fontFamily: 'system-ui' }}>
        <p>Loading…</p>
      </main>
    );
  }

  const address = order.shippingAddress || {};
  const remainingRefundable = Number(order.total) - Number(order.refundedAmount);

  return (
    <main style={{ padding: 40, maxWidth: 800, margin: '0 auto', fontFamily: 'system-ui' }}>
      <Link href="/admin/orders" style={{ fontSize: 12, color: '#666' }}>
        ← Back to orders
      </Link>
      <h1 style={{ fontSize: 20, marginTop: 8 }}>{order.invoiceNumber || order.id}</h1>
      <p style={{ fontSize: 12, color: '#999' }}>{new Date(order.createdAt).toLocaleString('en-IN')}</p>

      <div style={boxStyle}>
        <h2 style={{ fontSize: 14, marginTop: 0 }}>Status</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          <div><div style={labelStyle}>Order Status</div><div style={valueStyle}>{order.status}</div></div>
          <div><div style={labelStyle}>Payment Status</div><div style={valueStyle}>{order.paymentStatus}</div></div>
          <div><div style={labelStyle}>Refund Status</div><div style={valueStyle}>{order.refundStatus}</div></div>
          <div><div style={labelStyle}>Refunded</div><div style={valueStyle}>{money(order.refundedAmount, order.currency)}</div></div>
        </div>
      </div>

      <div style={boxStyle}>
        <h2 style={{ fontSize: 14, marginTop: 0 }}>Discount</h2>
        {order.discountCode ? (
          <p style={{ fontSize: 14 }}>
            <strong>{order.discountCode}</strong> — {money(order.discountAmount, order.currency)} off
          </p>
        ) : (
          <p style={{ fontSize: 13, color: '#999' }}>No discount code used on this order.</p>
        )}
      </div>

      <div style={boxStyle}>
        <h2 style={{ fontSize: 14, marginTop: 0 }}>Customer & Shipping</h2>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div><div style={labelStyle}>Name</div><div style={valueStyle}>{address.name || order.customer?.name || '—'}</div></div>
          <div><div style={labelStyle}>Phone</div><div style={valueStyle}>{address.phone || order.customer?.phone || '—'}</div></div>
          <div><div style={labelStyle}>Email</div><div style={valueStyle}>{address.email || order.customer?.email || '—'}</div></div>
          <div><div style={labelStyle}>Address</div><div style={valueStyle}>
            {[address.line1, address.line2, address.city, address.state, address.pincode, address.country].filter(Boolean).join(', ') || '—'}
          </div></div>
        </div>
      </div>

      <div style={boxStyle}>
        <h2 style={{ fontSize: 14, marginTop: 0 }}>Items</h2>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ textAlign: 'left', borderBottom: '1px solid #ccc' }}>
              <th style={{ padding: 6 }}>Product</th>
              <th style={{ padding: 6 }}>Variant</th>
              <th style={{ padding: 6 }}>SKU</th>
              <th style={{ padding: 6 }}>Qty</th>
              <th style={{ padding: 6 }}>Unit Price</th>
            </tr>
          </thead>
          <tbody>
            {order.items.map((i) => (
              <tr key={i.id} style={{ borderBottom: '1px solid #f3f3f3' }}>
                <td style={{ padding: 6 }}>{i.product.title}</td>
                <td style={{ padding: 6 }}>{[i.variant?.optionValue, i.variant?.option2Value].filter(Boolean).join(' / ') || '—'}</td>
                <td style={{ padding: 6 }}>{i.variant?.sku || '—'}</td>
                <td style={{ padding: 6 }}>{i.quantity}</td>
                <td style={{ padding: 6 }}>{money(i.unitPrice, order.currency)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div style={{ marginTop: 12, fontSize: 13, textAlign: 'right' }}>
          <div>Subtotal: {money(order.subtotal, order.currency)}</div>
          <div>Shipping: {money(order.shippingCost, order.currency)}</div>
          <div>Tax: {money(order.totalTax, order.currency)}</div>
          {Number(order.discountAmount) > 0 && <div>Discount: −{money(order.discountAmount, order.currency)}</div>}
          <div style={{ fontWeight: 600, marginTop: 4 }}>Total: {money(order.total, order.currency)}</div>
        </div>
      </div>

      <div style={boxStyle}>
        <h2 style={{ fontSize: 14, marginTop: 0 }}>Fulfillment</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
          <div><div style={labelStyle}>CJ Order ID</div><div style={valueStyle}>{order.cjOrderId || '—'}</div></div>
          <div><div style={labelStyle}>Tracking Number</div><div style={valueStyle}>{order.trackingNumber || '—'}</div></div>
          <div><div style={labelStyle}>Carrier</div><div style={valueStyle}>{order.trackingCarrier || '—'}</div></div>
        </div>
      </div>

      {order.razorpayPaymentId && remainingRefundable > 0 && (
        <div style={boxStyle}>
          <h2 style={{ fontSize: 14, marginTop: 0 }}>Issue Refund</h2>
          <p style={{ fontSize: 12, color: '#999' }}>
            Up to {money(remainingRefundable, order.currency)} refundable. This calls Razorpay directly — real money moves.
          </p>
          <div style={{ display: 'flex', gap: 8, marginTop: 8, alignItems: 'flex-start' }}>
            <input
              style={inputStyle}
              type="number"
              placeholder="Amount"
              value={refundAmount}
              onChange={(e) => setRefundAmount(e.target.value)}
            />
            <input
              style={{ ...inputStyle, flex: 1 }}
              placeholder="Reason (optional)"
              value={refundReason}
              onChange={(e) => setRefundReason(e.target.value)}
            />
            <button style={btnStyle} onClick={submitRefund} disabled={refunding}>
              {refunding ? 'Processing…' : 'Refund'}
            </button>
          </div>
          {refundError && <p style={{ color: '#e22120', fontSize: 13, marginTop: 8 }}>{refundError}</p>}
        </div>
      )}
    </main>
  );
}
