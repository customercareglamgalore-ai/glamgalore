import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

// Single-order detail for the admin order page — full line items (with
// product/variant so titles/SKUs render), address, tax breakdown, and
// everything the refund form on that page needs.
export async function GET(_req: NextRequest, { params }: { params: Promise<{ orderId: string }> }) {
  const { orderId } = await params;

  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: {
      customer: true,
      items: { include: { product: true, variant: true } },
    },
  });

  if (!order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 });
  }

  return NextResponse.json({ order });
}
