'use client';

import { useEffect, useRef, useState } from 'react';

// Renders the desktop hero image by default (safe for SSR, first paint, and
// no-JS) and swaps to the mobile hero video after mount if the viewport is
// narrow -- so only one asset (never both) is ever requested per device.
export default function HeroMedia({
  desktopSrc,
  mobileImageSrc,
  videoSrc,
  posterSrc,
  alt,
}: {
  desktopSrc: string;
  mobileImageSrc: string;
  videoSrc: string;
  posterSrc: string;
  alt: string;
}) {
  const [showMobileVideo, setShowMobileVideo] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const mql = window.matchMedia('(max-width: 1024px)');
    setShowMobileVideo(mql.matches);
  }, []);

  // Browsers throttle/park background or unfocused-tab video playback, which
  // can leave a short looping clip stuck mid-frame instead of cycling. This
  // nudges it back to life whenever the tab regains visibility/focus, or if
  // it ever pauses on its own without actually reaching the end.
  useEffect(() => {
    if (!showMobileVideo) return;
    const video = videoRef.current;
    if (!video) return;

    const resume = () => {
      if (video.paused && !video.ended) video.play().catch(() => {});
    };

    const handlePause = () => {
      if (!video.ended) resume();
    };

    video.addEventListener('pause', handlePause);
    document.addEventListener('visibilitychange', resume);
    window.addEventListener('focus', resume);

    return () => {
      video.removeEventListener('pause', handlePause);
      document.removeEventListener('visibilitychange', resume);
      window.removeEventListener('focus', resume);
    };
  }, [showMobileVideo]);

  if (showMobileVideo) {
    return (
      <>
        <video
          ref={videoRef}
          src={videoSrc}
          poster={posterSrc}
          autoPlay
          loop
          muted
          playsInline
          controls={false}
          disablePictureInPicture
          disableRemotePlayback
          aria-label={alt}
        />
        <span className="hero-cta">Shop Collection</span>
      </>
    );
  }

  // The desktop image already has its own "Shop Now" built into the photo
  // itself, so no separate HTML button is layered on top here.
  return (
    <picture>
      <source media="(min-width: 1025px)" srcSet={desktopSrc} />
      <img src={mobileImageSrc} alt={alt} draggable={false} />
    </picture>
  );
}
