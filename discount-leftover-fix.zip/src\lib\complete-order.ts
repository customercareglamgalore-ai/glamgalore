// Shared "finish the order" pipeline — pulls together whatever address is on
// the order (placeholder or already real), re-points it to the real customer,
// finalizes the GST split, submits to CJ, generates the invoice, and sends
// both customer and admin emails.
//
// Called from two places that can each fire independently for the same
// payment: the client-side handler (fires only if the browser stays on the
// page through payment) and the Razorpay webhook (fires from Razorpay's own
// servers regardless of what happens in the browser — the reliable one,
// since UPI/netbanking/3D-secure redirects routinely orphan the client-side
// callback). Also used by the admin "reconcile order" tool for manually
// completing a payment that Razorpay captured but that never got marked paid.
// Idempotent: if the order is already marked paid, this is a no-op, so it's
// safe for more than one caller to end up invoking it for the same payment.
import crypto from 'crypto';
import Razorpay from 'razorpay';
import { prisma } from '@/lib/db';
import { hashPassword } from '@/lib/auth';
import { submitOrderToCJ } from '@/lib/cj-dropshipping';
import { allocateInvoiceNumber } from '@/lib/invoice-numbering';
import { generateInvoicePdf } from '@/lib/invoice-pdf';
import { sendMail } from '@/lib/email';
import { buildOrderConfirmationEmail } from '@/lib/email-templates/order-confirmation';
import { buildAdminOrderNotificationEmail } from '@/lib/email-templates/admin-order-notification';
import { sendMetaPurchaseEvent } from '@/lib/meta-capi';
import { recordDiscountUsage } from '@/lib/discounts';
import { buildOrderTax } from '@/lib/order-tax';
import { ISO_CODE_TO_COUNTRY } from '@/lib/currency';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

const ORDER_WITH_ITEMS = {
  items: {
    include: {
      product: { include: { images: { take: 1, orderBy: { position: 'asc' as const } } } },
      variant: true,
    },
  },
};

export async function completeOrder(
  razorpayOrderId: string,
  razorpayPaymentId: string,
  meta?: { clientIp?: string | null; userAgent?: string | null; fbp?: string | null; fbc?: string | null },
): Promise<{ success: boolean; orderId?: string; alreadyDone?: boolean; error?: string }> {
  const existing = await prisma.order.findUnique({ where: { razorpayOrderId } });
  if (!existing) return { success: false, error: 'Order not found for this razorpayOrderId' };
  if (existing.paymentStatus === 'paid') return { success: true, orderId: existing.id, alreadyDone: true };

  // Our checkout always collects a real address before payment starts, so
  // this should never be empty in practice — but this fallback (pulling the
  // address Razorpay has on file for the payment) is kept as a safety net
  // for any order that somehow reaches here without one, so this function
  // stays safe to run for ANY captured payment on the account.
  const hasPlaceholderAddress = Object.keys(existing.shippingAddress as object).length === 0;

  let shippingAddress = existing.shippingAddress as unknown as {
    name: string; email: string; phone: string; line1: string; line2: string;
    city: string; state: string; pincode: string; country: string;
  };

  if (hasPlaceholderAddress) {
    const rzpOrder = await razorpay.orders.fetch(razorpayOrderId);
    const details = (rzpOrder as unknown as { customer_details?: {
      name?: string; contact?: string; email?: string;
      shipping_address?: { line1?: string; line2?: string; city?: string; state?: string; zipcode?: string | number; country?: string };
    } }).customer_details;
    const shipping = details?.shipping_address;
    // Razorpay returns this lowercase (e.g. "in", per their own Fetch Order
    // docs example) — ISO_CODE_TO_COUNTRY's keys are uppercase, so this must
    // be uppercased before lookup or it silently falls through to the raw
    // code, which then also fails to match COUNTRY_TO_ISO_CODE during CJ
    // submission (empty shippingCountryCode, CJ rejects the order).
    const countryCode = (shipping?.country || 'IN').toUpperCase();

    shippingAddress = {
      name: details?.name || '',
      email: details?.email || '',
      phone: details?.contact || '',
      line1: shipping?.line1 || '',
      line2: shipping?.line2 || '',
      city: shipping?.city || '',
      state: shipping?.state || '',
      pincode: shipping?.zipcode ? String(shipping.zipcode) : '',
      country: ISO_CODE_TO_COUNTRY[countryCode] || countryCode,
    };
  }

  let order = await prisma.order.update({
    where: { razorpayOrderId },
    data: {
      razorpayPaymentId,
      paymentStatus: 'paid',
      status: 'fulfilling',
      shippingAddress,
      customerState: shippingAddress.state,
      customerCountry: shippingAddress.country,
    },
    include: ORDER_WITH_ITEMS,
  });

  // Re-point the order from its placeholder guest customer to the real one,
  // found-or-created from the email Razorpay just gave us.
  if (shippingAddress.email) {
    try {
      const existingCustomer = await prisma.customer.findUnique({ where: { email: shippingAddress.email } });
      const realCustomer =
        existingCustomer ||
        (await prisma.customer.create({
          data: {
            email: shippingAddress.email,
            name: shippingAddress.name || null,
            phone: shippingAddress.phone || null,
            passwordHash: await hashPassword(crypto.randomBytes(32).toString('hex')),
          },
        }));
      if (realCustomer.id !== order.customerId) {
        order = await prisma.order.update({
          where: { id: order.id },
          data: { customerId: realCustomer.id },
          include: ORDER_WITH_ITEMS,
        });
      }
    } catch (err) {
      console.error('Failed to re-point order to real customer:', order.id, err);
    }
  }

  // Recompute the GST split now that we know the real delivery address —
  // this only refines the CGST/SGST/IGST breakdown for the invoice, it never
  // changes subtotal/shippingCost/total (the customer already paid that
  // exact amount via Razorpay).
  try {
    const cartItems = order.items.map((item) => ({
      productId: item.productId,
      variantId: item.variantId,
      quantity: item.quantity,
    }));
    const { computation } = await buildOrderTax(cartItems, { state: shippingAddress.state, country: shippingAddress.country });
    await prisma.order.update({
      where: { id: order.id },
      data: {
        taxableValue: computation.taxableValue,
        cgstAmount: computation.cgstTotal,
        sgstAmount: computation.sgstTotal,
        igstAmount: computation.igstTotal,
        totalTax: computation.totalTax,
        taxType: computation.taxType,
        gstRatesUsed: computation.lines,
      },
    });
  } catch (err) {
    console.error('Failed to recompute GST breakdown with real address:', order.id, err);
  }

  try {
    await recordDiscountUsage(order.discountCode, Number(order.discountAmount));
  } catch (err) {
    console.error('Failed to record discount usage:', order.id, err);
  }

  // Allocated before CJ submission (not after) so the friendly GG-number is
  // what CJ shows as their reference to this order, instead of our internal
  // database id — matters since it's what shows up if you ever look this
  // order up on CJ's own dashboard.
  let invoiceNumber: string | null = null;
  try {
    ({ invoiceNumber } = await allocateInvoiceNumber());
    order.invoiceNumber = invoiceNumber;
    await prisma.order.update({ where: { id: order.id }, data: { invoiceNumber, invoiceDate: new Date() } });
    const { filePath } = await generateInvoicePdf(order.id);
    await prisma.order.update({ where: { id: order.id }, data: { invoicePdfPath: filePath } });
  } catch (err) {
    console.error('Invoice generation failed, needs manual retry:', order.id, err);
  }

  try {
    const cjOrderId = await submitOrderToCJ(order);
    await prisma.order.update({ where: { id: order.id }, data: { cjOrderId } });
  } catch (err) {
    console.error('CJ order submission failed, needs manual retry:', order.id, err);
  }

  try {
    if (shippingAddress.email) {
      const { subject, html, text } = buildOrderConfirmationEmail({ ...order, invoiceNumber: invoiceNumber ?? order.invoiceNumber });
      await sendMail({ to: shippingAddress.email, subject, html, text });
    }
  } catch (err) {
    console.error('Order confirmation email failed:', order.id, err);
  }

  try {
    const adminEmail = process.env.ADMIN_NOTIFICATION_EMAIL;
    if (adminEmail) {
      const { subject, html, text } = buildAdminOrderNotificationEmail({ ...order, invoiceNumber: invoiceNumber ?? order.invoiceNumber });
      await sendMail({ to: adminEmail, subject, html, text });
    }
  } catch (err) {
    console.error('Admin order notification email failed:', order.id, err);
  }

  try {
    const [firstName, ...lastNameParts] = (shippingAddress.name || '').trim().split(/\s+/);
    await sendMetaPurchaseEvent({
      eventId: `purchase-${order.id}`,
      email: shippingAddress.email,
      phone: shippingAddress.phone,
      firstName: firstName || undefined,
      lastName: lastNameParts.join(' ') || undefined,
      city: shippingAddress.city,
      state: shippingAddress.state,
      zip: shippingAddress.pincode,
      country: shippingAddress.country,
      externalId: order.customerId,
      value: Number(order.total),
      currency: order.currency,
      contentIds: order.items.map((item) => item.productId),
      clientIp: meta?.clientIp ?? undefined,
      userAgent: meta?.userAgent ?? undefined,
      sourceUrl: `${process.env.NEXT_PUBLIC_SITE_URL}/order-confirmed?orderId=${order.id}`,
      fbp: meta?.fbp ?? undefined,
      fbc: meta?.fbc ?? undefined,
    });
  } catch (err) {
    console.error('Meta Conversions API Purchase event failed:', order.id, err);
  }

  return { success: true, orderId: order.id };
}
