// Resolves a checkout discount code against the order subtotal. Percentage
// codes are a % of subtotal; fixed codes are capped at subtotal so a
// discount can never make the pre-shipping total negative. Called from both
// the quote preview and order creation so the two stay consistent — usage
// is only ever recorded from checkout/verify, after payment succeeds.
//
// Global single-use model (not per-customer): every code is meant for one
// use, by whoever gets there first — no two customers, and not even the same
// customer twice, get the same code. Percentage codes enforce this via
// usageLimit/usageCount (set to 1 when the code is created). Fixed-value
// codes instead work as a shrinking pool: `value` IS the current remaining
// balance, decremented by whatever was actually applied each time the code
// is used, and the code auto-deactivates once that balance hits ₹0. So a
// ₹2650 code applied to a cart that only needed ₹2640 of it leaves ₹10 of
// balance behind — live for the NEXT person to use, not the same customer's
// private leftover. Nothing here needs to know who the customer is anymore.
import { prisma } from '@/lib/db';

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export type DiscountResolution = { code: string; amount: number } | { error: string };

export async function resolveDiscount(rawCode: string | null | undefined, subtotal: number): Promise<DiscountResolution | null> {
  const code = (rawCode || '').trim().toUpperCase();
  if (!code) return null;

  const discount = await prisma.discountCode.findUnique({ where: { code } });
  if (!discount || !discount.active) {
    return { error: 'That discount code is invalid or has expired.' };
  }
  // Fixed codes are gated purely by remaining balance (`value > 0`) — usageLimit
  // doesn't apply to them, since a fixed code is meant to stay usable across
  // however many people it takes to fully spend its value, not a fixed count
  // of transactions. Percentage codes have no balance to track, so usageLimit
  // (set to 1 for a true one-time code) is what gates those instead.
  if (discount.valueType === 'fixed') {
    if (Number(discount.value) <= 0) {
      return { error: "That discount code has already been used up." };
    }
  } else if (discount.usageLimit !== null && discount.usageCount >= discount.usageLimit) {
    return { error: 'That discount code has already been used up.' };
  }

  // Capped at subtotal - ₹1, not the full subtotal — a discount that wipes
  // out the whole order leaves Razorpay a ₹0 charge to process, which it
  // rejects outright ("Order amount less than minimum amount allowed"),
  // crashing checkout for anyone hitting it. Leaving at least ₹1 payable
  // means every discount code, fixed or percentage, always actually works,
  // including a 100%-off or oversized-fixed-amount code — the customer just
  // pays a token ₹1 instead of the checkout failing outright.
  const maxDiscount = Math.max(0, round2(subtotal - 1));
  const cappedByCode =
    discount.valueType === 'percentage'
      ? round2(subtotal * (Number(discount.value) / 100))
      : round2(Number(discount.value)); // fixed: `value` is already the live remaining balance
  const amount = Math.min(cappedByCode, maxDiscount);

  return { code: discount.code, amount: Math.max(0, amount) };
}

// Called once an order's payment has actually succeeded. `amountUsed` is
// that order's own discountAmount — how much of the code was actually spent
// this time, which for a fixed code may be less than its full value.
export async function recordDiscountUsage(code: string | null | undefined, amountUsed: number) {
  if (!code) return;
  const discount = await prisma.discountCode.findUnique({ where: { code } });
  if (!discount) return;

  if (discount.valueType === 'fixed') {
    const remaining = Math.max(0, round2(Number(discount.value) - amountUsed));
    await prisma.discountCode.update({
      where: { code },
      data: {
        value: remaining,
        usageCount: { increment: 1 },
        active: remaining > 0, // fully spent — auto-deactivate rather than leave a live ₹0 code around
      },
    });
  } else {
    await prisma.discountCode.update({ where: { code }, data: { usageCount: { increment: 1 } } });
  }
}
