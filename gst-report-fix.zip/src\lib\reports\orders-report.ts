import ExcelJS from 'exceljs';
import type { Prisma } from '@prisma/client';

// One row per line item (piece-wise), not per order — each product/variant
// keeps its own HSN code, GST rate, and tax split, since a single order can
// mix items taxed at different slab rates (5% under ₹2500/piece, 18% at or
// above it). Order-level fields (shipping, discounts, refunds, grand total)
// only appear on that order's FIRST item row, blank on the rest, so summing
// any column in a spreadsheet doesn't double-count them per extra line item.
export const ORDER_REPORT_COLUMNS = [
  'Order ID', 'Date', 'Customer Name', 'State', 'Country', 'Product', 'Variant', 'HSN Code',
  'Quantity', 'Unit Price', 'GST Rate', 'Line Taxable Value', 'Line CGST', 'Line SGST', 'Line IGST', 'Line Total Tax',
  'Order Shipping', 'Order Discounts', 'Order Grand Total', 'Order Refunded Amount', 'Order Refunded Tax', 'Order Net Total',
  'Payment Status', 'Payment Method', 'Order Status',
];

export type OrderForReport = Prisma.OrderGetPayload<{
  include: { items: { include: { product: true; variant: true } }; customer: true };
}>;

export type ReportRow = (string | number)[];

export function buildOrderReportRows(orders: OrderForReport[]): ReportRow[] {
  const rows: ReportRow[] = [];

  for (const o of orders) {
    o.items.forEach((item, i) => {
      const isFirst = i === 0;
      const variantLabel = [item.variant?.optionValue, item.variant?.option2Value].filter(Boolean).join(' / ');
      const lineTax = Number(item.cgstAmount ?? 0) + Number(item.sgstAmount ?? 0) + Number(item.igstAmount ?? 0);

      rows.push([
        o.invoiceNumber || o.id,
        o.createdAt.toISOString().slice(0, 10),
        o.customer?.name || o.customer?.email || '',
        o.customerState || '',
        o.customerCountry,
        item.product.title,
        variantLabel || '',
        item.hsnCode || '',
        item.quantity,
        Number(item.unitPrice),
        item.gstRate !== null ? Number(item.gstRate) : '',
        Number(item.taxableValue ?? 0),
        Number(item.cgstAmount ?? 0),
        Number(item.sgstAmount ?? 0),
        Number(item.igstAmount ?? 0),
        lineTax,
        isFirst ? Number(o.shippingCost) : '',
        isFirst ? Number(o.discountAmount) : '',
        isFirst ? Number(o.total) : '',
        isFirst ? Number(o.refundedAmount) : '',
        isFirst ? Number(o.refundedTax) : '',
        isFirst ? Number(o.total) - Number(o.refundedAmount) : '',
        o.paymentStatus,
        'Razorpay',
        o.status,
      ]);
    });
  }

  return rows;
}

export async function ordersToXlsxBuffer(rows: ReportRow[]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Orders');
  sheet.addRow(ORDER_REPORT_COLUMNS);
  sheet.getRow(1).font = { bold: true };
  rows.forEach((r) => sheet.addRow(r));
  sheet.columns.forEach((col) => {
    col.width = 16;
  });
  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}
