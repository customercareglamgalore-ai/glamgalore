import { prisma } from '@/lib/db';

export type GstSummary = {
  totalSales: number;
  taxableSales: number;
  gstCollected: number;
  cgstTotal: number;
  sgstTotal: number;
  igstTotal: number;
  exportSales: number;
  stateWise: { state: string; taxableSales: number; cgst: number; sgst: number; igst: number; totalSales: number }[];
  rateWise: { rate: number; quantity: number; taxableSales: number; cgst: number; sgst: number; igst: number; totalTax: number }[];
  monthly: { month: string; totalSales: number }[];
  daily: { day: string; totalSales: number }[];
};

function num(v: unknown): number {
  return v === null || v === undefined ? 0 : Number(v);
}

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

// All totals here are net of refunds: paid orders that were later (fully or
// partially) refunded have their refundedAmount/refundedTax subtracted, so
// this reflects what was actually kept, not the gross amount originally charged.
export async function getGstSummary(from: Date, to: Date): Promise<GstSummary> {
  const [totalsRows, stateRows, rateRows, monthlyRows, dailyRows] = await Promise.all([
    prisma.$queryRaw<
      { total_sales: string; taxable_sales: string; cgst_total: string; sgst_total: string; igst_total: string; refunded_tax: string; export_sales: string }[]
    >`
      SELECT
        COALESCE(SUM("total"), 0) - COALESCE(SUM("refundedAmount"), 0) AS total_sales,
        COALESCE(SUM("taxableValue"), 0) AS taxable_sales,
        COALESCE(SUM("cgstAmount"), 0) AS cgst_total,
        COALESCE(SUM("sgstAmount"), 0) AS sgst_total,
        COALESCE(SUM("igstAmount"), 0) AS igst_total,
        COALESCE(SUM("refundedTax"), 0) AS refunded_tax,
        COALESCE(SUM(CASE WHEN "customerCountry" <> 'India' THEN "total" ELSE 0 END), 0) AS export_sales
      FROM "Order"
      WHERE "paymentStatus" IN ('paid', 'refunded') AND "createdAt" BETWEEN ${from} AND ${to}
    `,
    prisma.$queryRaw<{ state: string; taxable_sales: string; cgst: string; sgst: string; igst: string; total_sales: string }[]>`
      SELECT
        COALESCE("customerState", 'Unknown') AS state,
        COALESCE(SUM("taxableValue"), 0) AS taxable_sales,
        COALESCE(SUM("cgstAmount"), 0) AS cgst,
        COALESCE(SUM("sgstAmount"), 0) AS sgst,
        COALESCE(SUM("igstAmount"), 0) AS igst,
        COALESCE(SUM("total") - SUM("refundedAmount"), 0) AS total_sales
      FROM "Order"
      WHERE "paymentStatus" IN ('paid', 'refunded') AND "createdAt" BETWEEN ${from} AND ${to} AND "customerCountry" = 'India'
      GROUP BY "customerState"
      ORDER BY "customerState"
    `,
    // Piece-wise breakdown: each OrderItem carries the GST rate actually applied
    // to that line (5% under the ₹2500 apparel slab, 18% at/above it), snapshotted
    // at order time — grouping by that gives taxable value/tax split by rate,
    // instead of one lump total per order. Not refund-adjusted (refunds are only
    // tracked at order level, not per line), so this is gross, unlike the totals above.
    prisma.$queryRaw<{ rate: string; quantity: string; taxable_sales: string; cgst: string; sgst: string; igst: string }[]>`
      SELECT
        oi."gstRate" AS rate,
        COALESCE(SUM(oi."quantity"), 0) AS quantity,
        COALESCE(SUM(oi."taxableValue"), 0) AS taxable_sales,
        COALESCE(SUM(oi."cgstAmount"), 0) AS cgst,
        COALESCE(SUM(oi."sgstAmount"), 0) AS sgst,
        COALESCE(SUM(oi."igstAmount"), 0) AS igst
      FROM "OrderItem" oi
      JOIN "Order" o ON o.id = oi."orderId"
      WHERE o."paymentStatus" IN ('paid', 'refunded') AND o."createdAt" BETWEEN ${from} AND ${to} AND oi."gstRate" IS NOT NULL
      GROUP BY oi."gstRate"
      ORDER BY oi."gstRate"
    `,
    prisma.$queryRaw<{ month: string; total_sales: string }[]>`
      SELECT TO_CHAR(DATE_TRUNC('month', "createdAt"), 'YYYY-MM') AS month,
        COALESCE(SUM("total") - SUM("refundedAmount"), 0) AS total_sales
      FROM "Order"
      WHERE "paymentStatus" IN ('paid', 'refunded') AND "createdAt" BETWEEN ${from} AND ${to}
      GROUP BY 1 ORDER BY 1
    `,
    prisma.$queryRaw<{ day: string; total_sales: string }[]>`
      SELECT TO_CHAR(DATE_TRUNC('day', "createdAt"), 'YYYY-MM-DD') AS day,
        COALESCE(SUM("total") - SUM("refundedAmount"), 0) AS total_sales
      FROM "Order"
      WHERE "paymentStatus" IN ('paid', 'refunded') AND "createdAt" BETWEEN ${from} AND ${to}
      GROUP BY 1 ORDER BY 1
    `,
  ]);

  const t = totalsRows[0];
  const gstCollected = num(t?.cgst_total) + num(t?.sgst_total) + num(t?.igst_total) - num(t?.refunded_tax);

  return {
    totalSales: num(t?.total_sales),
    taxableSales: num(t?.taxable_sales),
    gstCollected,
    cgstTotal: num(t?.cgst_total),
    sgstTotal: num(t?.sgst_total),
    igstTotal: num(t?.igst_total),
    exportSales: num(t?.export_sales),
    stateWise: stateRows.map((r) => ({
      state: r.state,
      taxableSales: num(r.taxable_sales),
      cgst: num(r.cgst),
      sgst: num(r.sgst),
      igst: num(r.igst),
      totalSales: num(r.total_sales),
    })),
    rateWise: rateRows.map((r) => ({
      rate: num(r.rate),
      quantity: num(r.quantity),
      taxableSales: num(r.taxable_sales),
      cgst: num(r.cgst),
      sgst: num(r.sgst),
      igst: num(r.igst),
      totalTax: round2(num(r.cgst) + num(r.sgst) + num(r.igst)),
    })),
    monthly: monthlyRows.map((r) => ({ month: r.month, totalSales: num(r.total_sales) })),
    daily: dailyRows.map((r) => ({ day: r.day, totalSales: num(r.total_sales) })),
  };
}
