'use client';

import { useEffect, useState } from 'react';

type GstSummary = {
  totalSales: number;
  taxableSales: number;
  gstCollected: number;
  cgstTotal: number;
  sgstTotal: number;
  igstTotal: number;
  exportSales: number;
  stateWise: { state: string; taxableSales: number; cgst: number; sgst: number; igst: number; totalSales: number }[];
  rateWise: { rate: number; quantity: number; taxableSales: number; cgst: number; sgst: number; igst: number; totalTax: number }[];
  monthly: { month: string; totalSales: number }[];
  daily: { day: string; totalSales: number }[];
};

function toDateInput(d: Date) {
  return d.toISOString().slice(0, 10);
}

function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

function startOfMonth() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

function startOfYear() {
  const d = new Date();
  return new Date(d.getFullYear(), 0, 1);
}

const inputStyle: React.CSSProperties = { padding: 8, border: '1px solid #ccc', fontSize: 13 };
const btnStyle: React.CSSProperties = { padding: '8px 16px', background: '#000', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 13 };
const linkBtnStyle: React.CSSProperties = { ...btnStyle, background: '#eee', color: '#000', textDecoration: 'none', display: 'inline-block' };

export default function AdminReportsPage() {
  const [from, setFrom] = useState(toDateInput(startOfMonth()));
  const [to, setTo] = useState(toDateInput(new Date()));
  const [summary, setSummary] = useState<GstSummary | null>(null);
  const [loading, setLoading] = useState(false);

  function refresh() {
    setLoading(true);
    fetch(`/api/admin/reports/gst-summary?from=${from}&to=${to}`)
      .then((r) => r.json())
      .then((data) => setSummary(data))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function quickRange(start: Date) {
    setFrom(toDateInput(start));
    setTo(toDateInput(new Date()));
  }

  const reportUrl = (format: 'csv' | 'xlsx') => `/api/admin/reports/orders?from=${from}&to=${to}&format=${format}`;

  return (
    <main style={{ padding: 40, maxWidth: 900, margin: '0 auto', fontFamily: 'system-ui' }}>
      <h1 style={{ fontSize: 20 }}>Reports</h1>

      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, marginTop: 20, flexWrap: 'wrap' }}>
        <div>
          <label style={{ display: 'block', fontSize: 12, color: '#666', marginBottom: 4 }}>From</label>
          <input style={inputStyle} type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 12, color: '#666', marginBottom: 4 }}>To</label>
          <input style={inputStyle} type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
        <button style={btnStyle} onClick={refresh} disabled={loading}>{loading ? 'Loading...' : 'Apply'}</button>
        <button style={{ ...btnStyle, background: '#eee', color: '#000' }} onClick={() => quickRange(startOfToday())}>Today</button>
        <button style={{ ...btnStyle, background: '#eee', color: '#000' }} onClick={() => quickRange(startOfMonth())}>This Month</button>
        <button style={{ ...btnStyle, background: '#eee', color: '#000' }} onClick={() => quickRange(startOfYear())}>This Year</button>
      </div>

      <div style={{ marginTop: 20 }}>
        <a href={reportUrl('csv')} style={linkBtnStyle}>Download Orders CSV</a>
        <a href={reportUrl('xlsx')} style={{ ...linkBtnStyle, marginLeft: 8 }}>Download Orders Excel</a>
      </div>

      {summary && (
        <>
          <div style={{ marginTop: 32, borderTop: '1px solid #eee', paddingTop: 20 }}>
            <h2 style={{ fontSize: 15 }}>GST Summary</h2>
            <p style={{ fontSize: 11, color: '#999' }}>Net of refunds.</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginTop: 12 }}>
              {[
                ['Total Sales', summary.totalSales],
                ['Taxable Sales', summary.taxableSales],
                ['GST Collected', summary.gstCollected],
                ['Export Sales', summary.exportSales],
                ['CGST Total', summary.cgstTotal],
                ['SGST Total', summary.sgstTotal],
                ['IGST Total', summary.igstTotal],
              ].map(([label, value]) => (
                <div key={label as string} style={{ border: '1px solid #eee', padding: 12 }}>
                  <div style={{ fontSize: 11, color: '#999' }}>{label}</div>
                  <div style={{ fontSize: 16, fontWeight: 600 }}>₹{Number(value).toFixed(2)}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ marginTop: 32 }}>
            <h2 style={{ fontSize: 15 }}>Tax by Rate (Piece-wise)</h2>
            <p style={{ fontSize: 11, color: '#999' }}>
              Per-piece GST rate applied at checkout — under ₹2,500/piece taxed at 5%, ₹2,500/piece and above at 18%. Gross figures, not adjusted for refunds.
            </p>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, marginTop: 8 }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '1px solid #ccc' }}>
                  <th style={{ padding: 6 }}>Rate</th>
                  <th style={{ padding: 6 }}>Pieces</th>
                  <th style={{ padding: 6 }}>Taxable Value</th>
                  <th style={{ padding: 6 }}>CGST</th>
                  <th style={{ padding: 6 }}>SGST</th>
                  <th style={{ padding: 6 }}>IGST</th>
                  <th style={{ padding: 6 }}>Total Tax</th>
                </tr>
              </thead>
              <tbody>
                {summary.rateWise.map((r) => (
                  <tr key={r.rate} style={{ borderBottom: '1px solid #f3f3f3' }}>
                    <td style={{ padding: 6 }}>{r.rate}%</td>
                    <td style={{ padding: 6 }}>{r.quantity}</td>
                    <td style={{ padding: 6 }}>₹{r.taxableSales.toFixed(2)}</td>
                    <td style={{ padding: 6 }}>₹{r.cgst.toFixed(2)}</td>
                    <td style={{ padding: 6 }}>₹{r.sgst.toFixed(2)}</td>
                    <td style={{ padding: 6 }}>₹{r.igst.toFixed(2)}</td>
                    <td style={{ padding: 6, fontWeight: 600 }}>₹{r.totalTax.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop: 32 }}>
            <h2 style={{ fontSize: 15 }}>State-wise Sales</h2>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, marginTop: 8 }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '1px solid #ccc' }}>
                  <th style={{ padding: 6 }}>State</th>
                  <th style={{ padding: 6 }}>Taxable</th>
                  <th style={{ padding: 6 }}>CGST</th>
                  <th style={{ padding: 6 }}>SGST</th>
                  <th style={{ padding: 6 }}>IGST</th>
                  <th style={{ padding: 6 }}>Total</th>
                </tr>
              </thead>
              <tbody>
                {summary.stateWise.map((s) => (
                  <tr key={s.state} style={{ borderBottom: '1px solid #f3f3f3' }}>
                    <td style={{ padding: 6 }}>{s.state}</td>
                    <td style={{ padding: 6 }}>₹{s.taxableSales.toFixed(2)}</td>
                    <td style={{ padding: 6 }}>₹{s.cgst.toFixed(2)}</td>
                    <td style={{ padding: 6 }}>₹{s.sgst.toFixed(2)}</td>
                    <td style={{ padding: 6 }}>₹{s.igst.toFixed(2)}</td>
                    <td style={{ padding: 6 }}>₹{s.totalSales.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop: 32, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32 }}>
            <div>
              <h2 style={{ fontSize: 15 }}>Monthly Sales</h2>
              {summary.monthly.map((m) => (
                <div key={m.month} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '4px 0', borderBottom: '1px solid #f3f3f3' }}>
                  <span>{m.month}</span>
                  <span>₹{m.totalSales.toFixed(2)}</span>
                </div>
              ))}
            </div>
            <div>
              <h2 style={{ fontSize: 15 }}>Daily Sales</h2>
              <div style={{ maxHeight: 300, overflowY: 'auto' }}>
                {summary.daily.map((d) => (
                  <div key={d.day} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '4px 0', borderBottom: '1px solid #f3f3f3' }}>
                    <span>{d.day}</span>
                    <span>₹{d.totalSales.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </main>
  );
}
