// One-off: reconcile Razorpay's August refunds CSV against our Order records,
// and cancel GG451888 (removing it from sales entirely). Run from the project
// root so @prisma/client resolves: `node adjust-aug-refunds.js` after copying
// this file into /var/www/glamgalore/.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// From scrooge_refunds - Aug 26.csv (payment_id, refund amount)
const REFUNDS = [
  { paymentId: 'pay_TLO0eCitxOVZiG', amount: 1699.00 },
  { paymentId: 'pay_T9vGxdZk6RT6iL', amount: 1774.12 },
  { paymentId: 'pay_T91C38pdLfR1Pu', amount: 724.00 },
  { paymentId: 'pay_TIpcIzLtJEBAT8', amount: 8181.36 },
  { paymentId: 'pay_TJdZDc4Gr57Oak', amount: 2639.12 },
  { paymentId: 'pay_TMD8ztsqGTkTYc', amount: 2799.00 },
  { paymentId: 'pay_TJJKSpKfpfP42l', amount: 4783.26 },
  { paymentId: 'pay_Sw0bmRtorcbPc1', amount: 2899.00 },
  { paymentId: 'pay_T3YyCyZUI8TlQx', amount: 2499.00 },
  { paymentId: 'pay_TKsDsQbGh1ORgK', amount: 3499.00 },
  { paymentId: 'pay_TOiweUOESUJ2td', amount: 3499.00 },
  { paymentId: 'pay_TPoKl4PL87l5tj', amount: 2699.00 },
  { paymentId: 'pay_TPyEi9nH8kcqwB', amount: 2899.00 },
  { paymentId: 'pay_TI67WwYUEUsDK1', amount: 3044.13 },
  { paymentId: 'pay_TRea7F2gfsIgeA', amount: 2599.00 },
  { paymentId: 'pay_TLXvSnmIso4kei', amount: 3499.00 },
  { paymentId: 'pay_TNKV3k5nvZqf14', amount: 2348.13 },
  { paymentId: 'pay_TMzU9Ui27iOQjO', amount: 1130.13 },
  { paymentId: 'pay_TN9wbzB32ALSJX', amount: 2999.00 },
];

const CANCEL_ORDER = 'GG451888';
const TOLERANCE = 1.0; // rupees — treat "refund >= total - 1" as a full refund

function round2(n) {
  return Math.round(n * 100) / 100;
}

async function main() {
  console.log('=== Cancelling', CANCEL_ORDER, '===');
  const cancelOrder = await prisma.order.findFirst({ where: { invoiceNumber: { contains: CANCEL_ORDER.replace(/^GG/i, '') } } });
  if (!cancelOrder) {
    console.log('  NOT FOUND — check the GG number and re-run just this part.');
  } else {
    const updated = await prisma.order.update({
      where: { id: cancelOrder.id },
      data: {
        status: 'cancelled',
        paymentStatus: 'refunded',
        refundStatus: 'full',
        refundedAmount: cancelOrder.total,
        refundedTax: cancelOrder.totalTax,
      },
    });
    console.log('  Cancelled:', updated.invoiceNumber, '— total', updated.total.toString(), 'now fully refunded/removed from sales.');
  }

  console.log('\n=== Reconciling', REFUNDS.length, 'refunds ===');
  let matched = 0, alreadyApplied = 0, notFound = 0;
  for (const r of REFUNDS) {
    const order = await prisma.order.findFirst({ where: { razorpayPaymentId: r.paymentId } });
    if (!order) {
      console.log(`  ${r.paymentId}  ₹${r.amount}  -> NOT FOUND (no order with this payment ID; could be a pre-August order, or a payment/refund test)`);
      notFound++;
      continue;
    }

    const currentRefunded = Number(order.refundedAmount || 0);
    if (round2(currentRefunded) >= round2(r.amount)) {
      console.log(`  ${r.paymentId}  ₹${r.amount}  -> ${order.invoiceNumber || order.id}: already reflects ₹${currentRefunded} refunded, skipping`);
      alreadyApplied++;
      continue;
    }

    const total = Number(order.total);
    const totalTax = Number(order.totalTax);
    const isFull = r.amount >= total - TOLERANCE;

    if (isFull) {
      await prisma.order.update({
        where: { id: order.id },
        data: {
          paymentStatus: 'refunded',
          refundStatus: 'full',
          refundedAmount: total,
          refundedTax: totalTax,
        },
      });
      console.log(`  ${r.paymentId}  ₹${r.amount}  -> ${order.invoiceNumber || order.id}: FULL refund (order total ₹${total})`);
    } else {
      const fraction = total > 0 ? r.amount / total : 0;
      const proratedTax = round2(totalTax * fraction);
      await prisma.order.update({
        where: { id: order.id },
        data: {
          refundStatus: 'partial',
          refundedAmount: round2(r.amount),
          refundedTax: proratedTax,
        },
      });
      console.log(`  ${r.paymentId}  ₹${r.amount}  -> ${order.invoiceNumber || order.id}: PARTIAL refund (order total ₹${total}, refunded tax ₹${proratedTax})`);
    }
    matched++;
  }

  console.log('\n=== Summary ===');
  console.log('Newly applied:', matched, ' | Already applied (skipped):', alreadyApplied, ' | Not found:', notFound);
  if (notFound > 0) {
    console.log('Not-found payment IDs need a manual look — likely orders from outside this August export, or refunds not tied to a real order in our DB.');
  }
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
