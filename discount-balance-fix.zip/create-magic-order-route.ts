// Creates a Razorpay order for the "Magic Checkout" flow — cart page sends
// the customer straight into Razorpay's own popup (which collects name,
// phone, and address), instead of our custom checkout form. Because we
// don't have the customer's address yet at this point, tax/shipping are
// computed assuming domestic (India) pricing — shipping is free worldwide
// regardless, and GST is only ever a display/invoicing breakdown of an
// already tax-inclusive sticker price, so it never changes the amount
// actually charged. The real address (and a final, address-accurate tax
// breakdown) is filled in during /api/checkout/verify-magic, once Razorpay
// hands it back after payment.
import { NextRequest, NextResponse } from 'next/server';
import Razorpay from 'razorpay';
import crypto from 'crypto';
import { prisma } from '@/lib/db';
import { getCustomerIdFromSession, hashPassword, setSessionCookie } from '@/lib/auth';
import { buildOrderTax, OrderTaxError } from '@/lib/order-tax';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function POST(req: NextRequest) {
  const { cartItems, discountCode, specialInstructions } = await req.json();
  if (!Array.isArray(cartItems) || cartItems.length === 0) {
    return NextResponse.json({ error: 'Cart is empty' }, { status: 400 });
  }
  const customerNote = typeof specialInstructions === 'string' ? specialInstructions.trim().slice(0, 500) || null : null;

  let customerId = await getCustomerIdFromSession();
  if (!customerId) {
    // No address/email yet — this placeholder customer gets re-pointed to
    // the real one (found-or-created from the email Razorpay hands back)
    // once payment is verified.
    const placeholderEmail = `guest-${crypto.randomUUID()}@pending.glamgalore.in`;
    const customer = await prisma.customer.create({
      data: { email: placeholderEmail, passwordHash: await hashPassword(crypto.randomBytes(32).toString('hex')) },
    });
    customerId = customer.id;
    await setSessionCookie(customerId);
  }

  let computation;
  let lineMeta;
  let discountAmount;
  let appliedDiscountCode;
  try {
    let discountError;
    ({ computation, lineMeta, discountAmount, discountCode: appliedDiscountCode, discountError } = await buildOrderTax(
      cartItems,
      { state: '', country: 'India' },
      discountCode,
      customerId,
    ));
    if (discountError) {
      return NextResponse.json({ error: discountError }, { status: 400 });
    }
  } catch (err) {
    if (err instanceof OrderTaxError) {
      return NextResponse.json({ error: err.message }, { status: err.status });
    }
    throw err;
  }

  // A fixed-amount discount code is capped at the subtotal in resolveDiscount
  // (so it can never go negative), but if it's equal to or larger than the
  // subtotal the order total drops to ₹0 — which Razorpay flatly rejects
  // ("Order amount less than minimum amount allowed"). Catching it here,
  // before ever calling Razorpay, gives a real explanation instead of a
  // generic "something went wrong" the customer (and whoever built the
  // discount code) has no way to diagnose.
  if (computation.grandTotal < 1) {
    return NextResponse.json(
      { error: 'This discount code reduces your order total below the minimum chargeable amount. Try a smaller cart total or a different code.' },
      { status: 400 },
    );
  }

  const products = await prisma.product.findMany({ where: { id: { in: lineMeta.map((m) => m.productId) } } });
  const productById = new Map(products.map((p) => [p.id, p]));

  const order = await prisma.order.create({
    data: {
      customerId,
      status: 'pending',
      subtotal: computation.subtotal,
      shippingCost: computation.shippingCost,
      total: computation.grandTotal,
      shippingAddress: {},
      customerNote,
      currency: 'INR',
      discountCode: appliedDiscountCode,
      discountAmount,
      taxableValue: computation.taxableValue,
      cgstAmount: computation.cgstTotal,
      sgstAmount: computation.sgstTotal,
      igstAmount: computation.igstTotal,
      totalTax: computation.totalTax,
      taxType: computation.taxType,
      gstRatesUsed: computation.lines,

      items: {
        create: lineMeta.map((meta, i) => {
          const line = computation.lines[i];
          return {
            productId: meta.productId,
            variantId: meta.variantId,
            quantity: meta.quantity,
            unitPrice: meta.unitPrice,
            hsnCode: line.hsnCode,
            gstRate: line.gstRate,
            taxableValue: line.taxableValue,
            cgstAmount: line.cgstAmount,
            sgstAmount: line.sgstAmount,
            igstAmount: line.igstAmount,
          };
        }),
      },
    },
  });

  const amountPaise = Math.round(computation.grandTotal * 100);

  // line_items_total must equal the sum of each line's offer_price — if a
  // discount is applied, the individual lines have to reflect it too, not
  // just the order total (per Razorpay's own "Pre-discount Handling" docs).
  // Each line's post-discount gross value is taxableValue + its tax, already
  // computed correctly (with rounding-safe discount proration) by
  // computeOrderTax — the last line absorbs any leftover paise so the sum
  // matches amountPaise exactly.
  let lineItemsAllocated = 0;
  const lineItems = lineMeta.map((meta, i) => {
    const product = productById.get(meta.productId);
    const line = computation.lines[i];
    const isLast = i === lineMeta.length - 1;
    const linePaise = Math.round((line.taxableValue + line.cgstAmount + line.sgstAmount + line.igstAmount) * 100);
    const offerPricePaise = isLast ? amountPaise - lineItemsAllocated : linePaise;
    lineItemsAllocated += offerPricePaise;
    return {
      sku: product?.handle || meta.productId,
      variant_id: meta.variantId || undefined,
      price: Math.round(meta.unitPrice * 100),
      offer_price: Math.max(0, offerPricePaise),
      quantity: meta.quantity,
      name: product?.title || 'Product',
    };
  });

  const razorpayOrder = await razorpay.orders.create({
    amount: amountPaise,
    currency: 'INR',
    receipt: order.id,
    line_items_total: amountPaise,
    line_items: lineItems,
    notes: customerNote ? { customer_note: customerNote } : undefined,
  });

  await prisma.order.update({
    where: { id: order.id },
    data: { razorpayOrderId: razorpayOrder.id },
  });

  return NextResponse.json({
    orderId: order.id,
    razorpayOrderId: razorpayOrder.id,
    amount: razorpayOrder.amount,
    currency: razorpayOrder.currency,
    keyId: process.env.RAZORPAY_KEY_ID,
  });
}
