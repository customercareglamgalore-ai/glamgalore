// Resolves a checkout discount code against the order subtotal. Percentage
// codes are a % of subtotal; fixed codes are capped at subtotal so a
// discount can never make the pre-shipping total negative. Called from both
// the quote preview and order creation so the two stay consistent — usage
// is only ever incremented from checkout/verify, after payment succeeds.
import { prisma } from '@/lib/db';

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export type DiscountResolution = { code: string; amount: number } | { error: string };

export async function resolveDiscount(
  rawCode: string | null | undefined,
  subtotal: number,
  customerId?: string | null,
): Promise<DiscountResolution | null> {
  const code = (rawCode || '').trim().toUpperCase();
  if (!code) return null;

  const discount = await prisma.discountCode.findUnique({ where: { code } });
  if (!discount || !discount.active) {
    return { error: 'That discount code is invalid or has expired.' };
  }
  if (discount.usageLimit !== null && discount.usageCount >= discount.usageLimit) {
    return { error: 'That discount code has already been used up.' };
  }

  // Per-customer allowance: no new table needed — a customer's own past
  // orders already record exactly how much of this code they've drawn down
  // (only orders that actually completed payment count; abandoned/pending
  // carts don't). A fixed-value code is a balance, not a one-shot voucher —
  // e.g. a ₹2450 code applied to a ₹2299 cart only spends ₹2298 of it
  // (capped at subtotal - ₹1, same as before), leaving ₹152 still valid for
  // a later order from the same customer. Once their cumulative use reaches
  // the code's full value, it's expired for them specifically — other
  // customers each get their own full ₹2450 allowance, untouched.
  // Percentage codes have no meaningful "leftover balance" to carry, so
  // those are simply one-use-per-customer.
  let perCustomerCap: number | null = null;
  if (customerId) {
    const priorOrders = await prisma.order.findMany({
      where: { customerId, discountCode: code, paymentStatus: { in: ['paid', 'refunded'] } },
      select: { discountAmount: true },
    });
    if (discount.valueType === 'percentage') {
      if (priorOrders.length > 0) {
        return { error: "You've already used this discount code." };
      }
    } else {
      const alreadyUsed = priorOrders.reduce((sum, o) => sum + Number(o.discountAmount || 0), 0);
      perCustomerCap = Math.max(0, round2(Number(discount.value) - alreadyUsed));
      if (perCustomerCap <= 0) {
        return { error: "You've already used up this discount code's full value." };
      }
    }
  }

  // Capped at subtotal - ₹1, not the full subtotal — a discount that wipes
  // out the whole order leaves Razorpay a ₹0 charge to process, which it
  // rejects outright ("Order amount less than minimum amount allowed"),
  // crashing checkout for anyone hitting it. Leaving at least ₹1 payable
  // means every discount code, fixed or percentage, always actually works,
  // including a 100%-off or oversized-fixed-amount code — the customer just
  // pays a token ₹1 instead of the checkout failing outright.
  const maxDiscount = Math.max(0, round2(subtotal - 1));
  const cappedByCode =
    discount.valueType === 'percentage'
      ? round2(subtotal * (Number(discount.value) / 100))
      : Math.min(round2(Number(discount.value)), perCustomerCap ?? Number(discount.value));
  const amount = Math.min(cappedByCode, maxDiscount);

  return { code: discount.code, amount: Math.max(0, amount) };
}

export async function recordDiscountUsage(code: string | null | undefined) {
  if (!code) return;
  await prisma.discountCode.updateMany({ where: { code }, data: { usageCount: { increment: 1 } } });
}
