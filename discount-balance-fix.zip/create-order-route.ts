// Creates a Razorpay order server-side, before showing the payment sheet.
// This is the secure pattern: never trust an amount sent from the browser —
// always recompute it (and the GST breakdown) from the cart/address stored
// in your database and submitted shipping address.

import { NextRequest, NextResponse } from 'next/server';
import Razorpay from 'razorpay';
import { prisma } from '@/lib/db';
import { getCustomerIdFromSession, hashPassword, setSessionCookie } from '@/lib/auth';
import { buildOrderTax, OrderTaxError } from '@/lib/order-tax';
import { minorUnitFactor } from '@/lib/currency';
import crypto from 'crypto';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function POST(req: NextRequest) {
  const { cartItems, shippingAddress, discountCode } = await req.json();
  if (!Array.isArray(cartItems) || cartItems.length === 0) {
    return NextResponse.json({ error: 'Cart is empty' }, { status: 400 });
  }

  // Enforced server-side, not just via the form's `required` attributes —
  // the whole point of building our own checkout is to guarantee every order
  // has a real name, email, and complete address, unlike Magic Checkout's
  // address form which regularly skipped these.
  const REQUIRED_ADDRESS_FIELDS: Record<string, string> = {
    name: 'Name',
    email: 'Email',
    phone: 'Phone number',
    line1: 'Address line 1',
    city: 'City',
    state: 'State',
    pincode: 'Pincode',
    country: 'Country',
  };
  const missing = Object.entries(REQUIRED_ADDRESS_FIELDS)
    .filter(([key]) => !String(shippingAddress?.[key] || '').trim())
    .map(([, label]) => label);
  if (missing.length > 0) {
    return NextResponse.json({ error: `${missing.join(', ')} ${missing.length > 1 ? 'are' : 'is'} required` }, { status: 400 });
  }

  // Checkout no longer requires a separate "create account" step. If the
  // shopper isn't logged in, transparently find-or-create their customer
  // record from the email they just entered, so there's still an account
  // behind the scenes (for the order-confirmed page, track-order, etc.)
  // without them having to consciously sign up first.
  let customerId = await getCustomerIdFromSession();
  if (!customerId) {
    const email = String(shippingAddress?.email || '').trim().toLowerCase();
    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }
    const existing = await prisma.customer.findUnique({ where: { email } });
    const customer =
      existing ||
      (await prisma.customer.create({
        data: {
          email,
          name: shippingAddress.name || null,
          phone: shippingAddress.phone || null,
          passwordHash: await hashPassword(crypto.randomBytes(32).toString('hex')),
        },
      }));
    customerId = customer.id;
    await setSessionCookie(customerId);
  }

  let computation;
  let lineMeta;
  let discountAmount;
  let appliedDiscountCode;
  let currency;
  let fxRateApplied;
  try {
    let discountError;
    ({ computation, lineMeta, discountAmount, discountCode: appliedDiscountCode, discountError, currency, fxRateApplied } = await buildOrderTax(
      cartItems,
      { state: shippingAddress.state, country: shippingAddress.country },
      discountCode,
      customerId,
    ));
    if (discountError) {
      return NextResponse.json({ error: discountError }, { status: 400 });
    }
  } catch (err) {
    if (err instanceof OrderTaxError) {
      return NextResponse.json({ error: err.message }, { status: err.status });
    }
    throw err;
  }

  // currency/fxRateApplied come from buildOrderTax — the single place that
  // resolves a customer's local currency against admin-configured exchange
  // rates (falling back to USD if their specific currency isn't configured
  // yet), shared with /api/checkout/quote so the live preview a customer
  // sees always matches what they're actually charged here.
  const chargeAmount = currency === 'INR' ? computation.grandTotal : Math.ceil(computation.grandTotal * fxRateApplied);

  // A fixed-amount discount code is capped at the subtotal in resolveDiscount
  // (so it can never go negative), but if it's equal to or larger than the
  // subtotal the order total drops to ~0 — which Razorpay flatly rejects
  // ("Order amount less than minimum amount allowed"). Catching it here,
  // before creating anything, gives a real explanation instead of a generic
  // "something went wrong" — and avoids creating a DB order row just to
  // delete it again when the Razorpay call below would otherwise fail.
  if (chargeAmount < 1) {
    return NextResponse.json(
      { error: 'This discount code reduces your order total below the minimum chargeable amount. Try a smaller cart total or a different code.' },
      { status: 400 },
    );
  }

  const order = await prisma.order.create({
    data: {
      customerId,
      status: 'pending',
      subtotal: computation.subtotal,
      shippingCost: computation.shippingCost,
      total: computation.grandTotal,
      shippingAddress,

      currency,
      fxRateApplied,
      discountCode: appliedDiscountCode,
      discountAmount,
      taxableValue: computation.taxableValue,
      cgstAmount: computation.cgstTotal,
      sgstAmount: computation.sgstTotal,
      igstAmount: computation.igstTotal,
      totalTax: computation.totalTax,
      taxType: computation.taxType,
      gstRatesUsed: computation.lines,
      customerState: shippingAddress.state,
      customerCountry: shippingAddress.country,
      customerGSTIN: shippingAddress.gstin || null,

      items: {
        create: lineMeta.map((meta, i) => {
          const line = computation.lines[i];
          return {
            productId: meta.productId,
            variantId: meta.variantId,
            quantity: meta.quantity,
            unitPrice: meta.unitPrice,
            hsnCode: line.hsnCode,
            gstRate: line.gstRate,
            taxableValue: line.taxableValue,
            cgstAmount: line.cgstAmount,
            sgstAmount: line.sgstAmount,
            igstAmount: line.igstAmount,
          };
        }),
      },
    },
  });

  // Razorpay itself can still reject a currency your account isn't actually
  // enabled to charge in (most of the ~190 currencies newly supported here
  // have never been used before) — caught explicitly so that shows up as a
  // real, readable error instead of an uncaught 500 that the frontend can
  // only report as "something went wrong."
  let razorpayOrder;
  try {
    razorpayOrder = await razorpay.orders.create({
      amount: Math.round(chargeAmount * minorUnitFactor(currency)),
      currency,
      receipt: order.id,
    });
  } catch (err: any) {
    console.error('Razorpay order creation failed:', order.id, currency, err);
    await prisma.order.delete({ where: { id: order.id } }).catch(() => {});
    const rzpMessage = err?.error?.description || err?.message;
    return NextResponse.json(
      { error: rzpMessage ? `Payment setup failed: ${rzpMessage}` : 'Payment setup failed. Please try again or contact support.' },
      { status: 502 },
    );
  }

  await prisma.order.update({
    where: { id: order.id },
    data: { razorpayOrderId: razorpayOrder.id },
  });

  return NextResponse.json({
    orderId: order.id,
    razorpayOrderId: razorpayOrder.id,
    amount: razorpayOrder.amount,
    currency: razorpayOrder.currency,
    keyId: process.env.RAZORPAY_KEY_ID,
  });
}
