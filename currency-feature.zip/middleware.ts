// Three independent things live here:
//  1. /admin/* and /api/admin/* — HTTP Basic Auth (only safe over HTTPS).
//  2. The rest of the site — an optional, admin-togglable "coming soon"
//     password wall (StoreSettings.siteLocked). Search/social crawlers are
//     explicitly let through so indexing and the Meta catalog feed can keep
//     working while human visitors see the gate. Toggle from /admin/settings.
//  3. IP-geolocation, cached 24h in a `geo_currency` cookie — the single
//     source of truth `getRequestCurrency()` (src/lib/request-currency.ts)
//     and the cart page both read, for localized/marked-up price display and
//     for routing non-India visitors to the regular (address-first) checkout
//     instead of Magic Checkout. Skipped for API/admin requests, which don't
//     render prices and would otherwise fire a redundant lookup alongside
//     the page's own request on a visitor's very first hit before the
//     cookie exists.
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { prisma } from '@/lib/db';
import { CHECKOUT_COUNTRIES, COUNTRY_TO_CURRENCY } from '@/lib/currency';

export const runtime = 'nodejs';

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|icon.png|apple-icon.png).*)'],
};

const CRAWLER_UA =
  /googlebot|bingbot|duckduckbot|slurp|yandexbot|baiduspider|facebookexternalhit|meta-externalagent|meta-externalfetcher|applebot|twitterbot|linkedinbot|pinterest/i;

const ALWAYS_ALLOWED_PATHS = new Set([
  '/sitemap.xml', '/robots.txt', '/feed.xml', '/site-locked', '/api/site-unlock',
  '/api/magic-checkout/shipping-info', // called directly by Razorpay's servers — must stay reachable regardless of site lock
  '/api/magic-checkout/shipping', // same — fresh URL replacing shipping-info above, to rule out server-side caching tied to the old path
  '/api/webhooks/razorpay', // same — Razorpay's servers call this directly, no unlock cookie involved
  '/api/checkout/promotions', // same — Magic Checkout's "Get Promotions" server-to-server call
  '/api/checkout/apply-promotion', // same — Magic Checkout's "Apply Promotions" server-to-server call
]);

const GEO_COOKIE_NAME = 'geo_currency';
const GEO_COOKIE_MAX_AGE = 60 * 60 * 24; // 24h

function unlockCookieValue(password: string): string {
  return crypto.createHash('sha256').update(`site-unlock:${password}`).digest('hex');
}

function matchKnownCountry(name: string | undefined): string {
  if (!name) return 'India';
  const match = CHECKOUT_COUNTRIES.find((c) => c.toLowerCase() === name.toLowerCase());
  return match ?? 'India'; // default to India for anything we don't have a rate/option for
}

async function resolveGeoCookieValue(req: NextRequest): Promise<string> {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim();
  let country = 'India';
  if (ip && ip !== '127.0.0.1' && ip !== '::1') {
    try {
      const geoRes = await fetch(`https://ipapi.co/${ip}/json/`, { signal: AbortSignal.timeout(2000) });
      if (geoRes.ok) {
        const data = await geoRes.json();
        country = matchKnownCountry(data.country_name);
      }
    } catch {
      // Geolocation is a best-effort UX nicety, not required — fall back to India silently.
    }
  }
  const currency = COUNTRY_TO_CURRENCY[country] ?? 'USD';
  return `${country}:${currency}`;
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  let geoCookieValue: string | null = null;
  if (!pathname.startsWith('/api') && !pathname.startsWith('/admin') && !req.cookies.get(GEO_COOKIE_NAME)) {
    geoCookieValue = await resolveGeoCookieValue(req);
  }

  function respond(res: NextResponse): NextResponse {
    if (geoCookieValue) {
      res.cookies.set(GEO_COOKIE_NAME, geoCookieValue, {
        maxAge: GEO_COOKIE_MAX_AGE,
        httpOnly: false, // the cart page reads this client-side to decide Magic Checkout vs. regular checkout
        sameSite: 'lax',
        path: '/',
      });
    }
    return res;
  }

  if (pathname.startsWith('/admin') || pathname.startsWith('/api/admin')) {
    const expectedUser = process.env.ADMIN_USER;
    const expectedPassword = process.env.ADMIN_PASSWORD;

    if (!expectedUser || !expectedPassword) {
      return new NextResponse('Admin auth is not configured (set ADMIN_USER / ADMIN_PASSWORD)', { status: 500 });
    }

    const authHeader = req.headers.get('authorization');
    const expected = 'Basic ' + Buffer.from(`${expectedUser}:${expectedPassword}`).toString('base64');

    if (authHeader !== expected) {
      return new NextResponse('Authentication required', {
        status: 401,
        headers: { 'WWW-Authenticate': 'Basic realm="Admin"' },
      });
    }

    return NextResponse.next();
  }

  if (ALWAYS_ALLOWED_PATHS.has(pathname)) {
    return respond(NextResponse.next());
  }

  const userAgent = req.headers.get('user-agent') || '';
  if (CRAWLER_UA.test(userAgent)) {
    return respond(NextResponse.next());
  }

  let settings: { siteLocked: boolean; sitePassword: string | null } | null = null;
  try {
    settings = await prisma.storeSettings.findUnique({
      where: { id: 'singleton' },
      select: { siteLocked: true, sitePassword: true },
    });
  } catch {
    // Fail open — a DB hiccup shouldn't take the whole site down.
    return respond(NextResponse.next());
  }

  if (!settings?.siteLocked) {
    return respond(NextResponse.next());
  }

  const unlockCookie = req.cookies.get('site_unlock')?.value;
  if (settings.sitePassword && unlockCookie === unlockCookieValue(settings.sitePassword)) {
    return respond(NextResponse.next());
  }

  const url = req.nextUrl.clone();
  url.pathname = '/site-locked';
  return respond(NextResponse.rewrite(url));
}
