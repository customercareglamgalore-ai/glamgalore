'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useCurrency } from './CurrencyProvider';
import { localizePrice } from '@/lib/localize-price';

type Product = { handle: string; title: string; price: string; compareAtPrice?: string; images: string[] };

export default function SearchModal({ onClose }: { onClose: () => void }) {
  const currency = useCurrency();
  const [query, setQuery] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [trending, setTrending] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch('/api/search/trending')
      .then((res) => res.json())
      .then((data) => setTrending(data.products));
  }, []);

  useEffect(() => {
    if (!query.trim()) {
      setProducts([]);
      return;
    }
    setLoading(true);
    const timer = setTimeout(() => {
      fetch(`/api/search?q=${encodeURIComponent(query)}`)
        .then((res) => res.json())
        .then((data) => setProducts(data.products))
        .finally(() => setLoading(false));
    }, 300);
    return () => clearTimeout(timer);
  }, [query]);

  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose();
    }
    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <div className="search-modal-overlay" onClick={onClose}>
      <div className="search-modal" onClick={(e) => e.stopPropagation()}>
        <div className="search-modal-input-row">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <circle cx="11" cy="11" r="7" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            autoFocus
            placeholder="Search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <button type="button" aria-label="Close search" onClick={onClose}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
              <line x1="5" y1="5" x2="19" y2="19" />
              <line x1="19" y1="5" x2="5" y2="19" />
            </svg>
          </button>
        </div>

        {loading && <p className="search-modal-status">Searching...</p>}
        {!loading && query.trim() && products.length === 0 && (
          <p className="search-modal-status">No products found for &quot;{query}&quot;.</p>
        )}

        {products.length > 0 && (
          <div className="search-modal-results">
            <p className="search-modal-label">Products</p>
            <div className="search-modal-grid">
              {products.map((p) => (
                <Link key={p.handle} href={`/products/${p.handle}`} className="search-result-card" onClick={onClose}>
                  <div className="search-result-image">
                    {p.images[0] && <img src={p.images[0]} alt={p.title} />}
                  </div>
                  <div>
                    <p className="search-result-title">{p.title}</p>
                    <p className="search-result-price">{localizePrice(Number(p.price), currency).formatted}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {!query.trim() && trending.length > 0 && (
          <div className="search-modal-results">
            <p className="search-modal-label">Trending Products</p>
            <div className="search-modal-grid">
              {trending.map((p) => (
                <Link key={p.handle} href={`/products/${p.handle}`} className="search-result-card" onClick={onClose}>
                  <div className="search-result-image">
                    {p.images[0] && <img src={p.images[0]} alt={p.title} />}
                  </div>
                  <div>
                    <p className="search-result-title">{p.title}</p>
                    <p className="search-result-price">{localizePrice(Number(p.price), currency).formatted}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
