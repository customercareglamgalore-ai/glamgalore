// Pure, synchronous price formatting — safe to import from both server and
// client components (no next/headers or DB access here, just arithmetic on
// numbers already looked up by getRequestCurrency in request-currency.ts).
// Split into its own file specifically so client components (ProductCard,
// cart, ReelStrip, etc.) can import just this without pulling in
// request-currency.ts's next/headers + prisma dependencies, which would
// otherwise break the client bundle.
import { applyInternationalMarkup } from './international-pricing';

const CURRENCY_SYMBOLS: Record<string, string> = {
  INR: '₹', USD: '$', GBP: '£', EUR: '€', CAD: 'CA$', AUD: 'AU$', SGD: 'S$', AED: 'AED ',
};

export type RequestCurrency = { country: string; currency: string; rate: number };

export const INDIA_CURRENCY: RequestCurrency = { country: 'India', currency: 'INR', rate: 1 };

export function localizePrice(inrPrice: number, ctx: RequestCurrency): { amount: number; formatted: string; currency: string } {
  if (ctx.currency === 'INR') {
    return { amount: inrPrice, formatted: `₹${inrPrice}`, currency: 'INR' };
  }
  const marked = applyInternationalMarkup(inrPrice);
  // Rounded up to a whole unit (no decimals) — same "never undercharge,
  // never show an odd fractional price" spirit as the INR markup step
  // itself rounding up to the nearest 10.
  const converted = Math.ceil(marked * ctx.rate);
  const symbol = CURRENCY_SYMBOLS[ctx.currency] ?? `${ctx.currency} `;
  return { amount: converted, formatted: `${symbol}${converted}`, currency: ctx.currency };
}
