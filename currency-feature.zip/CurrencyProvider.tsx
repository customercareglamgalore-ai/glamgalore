'use client';

import { createContext, useContext } from 'react';
import type { RequestCurrency } from '@/lib/request-currency';

const CurrencyContext = createContext<RequestCurrency>({ country: 'India', currency: 'INR', rate: 1 });

// Value is computed server-side (RootLayout calls getRequestCurrency(), which
// reads the geo_currency cookie set by middleware) and handed down here once
// per request — every client component under it (ProductCard, ReelStrip,
// cart, etc.) reads it via useCurrency() instead of re-deriving it.
export function CurrencyProvider({ value, children }: { value: RequestCurrency; children: React.ReactNode }) {
  return <CurrencyContext.Provider value={value}>{children}</CurrencyContext.Provider>;
}

export function useCurrency(): RequestCurrency {
  return useContext(CurrencyContext);
}
