export type NavLink = { href: string; title: string };

// "Category" = core product types, shown as their own nav group.
export const CATEGORY_LINKS: NavLink[] = [
  { href: '/collections/all', title: 'Shop All' },
  { href: '/collections/mini-dresses', title: 'Mini Dress' },
  { href: '/collections/co-ords', title: 'Co-ords' },
  { href: '/collections/swimwear', title: 'Swimwear' },
  { href: '/collections/playsuits', title: 'Playsuits' },
  { href: '/collections/strictly-tops', title: 'Tops' },
];

// "Collection" = themed/curated collections, shown as their own nav group.
export const COLLECTION_LINKS: NavLink[] = [
  { href: '/collections/spring-has-sprung', title: 'Summer Collection' },
  { href: '/collections/active', title: 'Sweat Sesh' },
  { href: '/collections/love-spark', title: 'The Date Night' },
  { href: '/collections/frontpage', title: 'Celebrity Closet' },
  { href: '/collections/top-selling', title: 'Top Selling' },
  { href: '/collections/denim', title: 'Denim' },
  { href: '/collections/office-siren', title: 'Office Siren' },
  { href: '/collections/sweater-weather', title: 'Sweater Weather' },
  { href: '/collections/the-divine-feminine', title: 'The Divine Feminine' },
  { href: '/collections/barbiecore', title: 'Barbiecore' },
];

export const COLLECTION_TITLES: Record<string, string> = Object.fromEntries(
  [...CATEGORY_LINKS, ...COLLECTION_LINKS]
    .filter((l) => l.href.startsWith('/collections/'))
    .map((l) => [l.href.replace('/collections/', ''), l.title])
);
