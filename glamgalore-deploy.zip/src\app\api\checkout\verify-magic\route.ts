// Verifies payment for the Magic Checkout flow. Same signature-verification
// requirement as the standard /api/checkout/verify route, but this one also
// has to pull the customer's name/contact/email/address back from Razorpay
// first — Magic Checkout collects those inside its own popup, so unlike the
// standard flow we never had them on our side until now.
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import Razorpay from 'razorpay';
import { prisma } from '@/lib/db';
import { hashPassword } from '@/lib/auth';
import { submitOrderToCJ } from '@/lib/cj-dropshipping';
import fs from 'fs';
import { allocateInvoiceNumber } from '@/lib/invoice-numbering';
import { generateInvoicePdf } from '@/lib/invoice-pdf';
import { sendMail } from '@/lib/email';
import { buildOrderConfirmationEmail } from '@/lib/email-templates/order-confirmation';
import { buildAdminOrderNotificationEmail } from '@/lib/email-templates/admin-order-notification';
import { sendMetaPurchaseEvent } from '@/lib/meta-capi';
import { recordDiscountUsage } from '@/lib/discounts';
import { buildOrderTax } from '@/lib/order-tax';
import { ISO_CODE_TO_COUNTRY } from '@/lib/currency';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function POST(req: NextRequest) {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json();

  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  if (expectedSignature !== razorpay_signature) {
    return NextResponse.json({ error: 'Payment verification failed' }, { status: 400 });
  }

  // Pull the address/contact Magic Checkout collected. customer_details is
  // only populated once the customer has actually filled it in — should
  // always be present by the time payment succeeds, but we fall back to an
  // empty address rather than fail the response if the shape ever surprises
  // us (payment already succeeded at this point).
  const rzpOrder = await razorpay.orders.fetch(razorpay_order_id);
  const details = (rzpOrder as unknown as { customer_details?: {
    name?: string; contact?: string; email?: string;
    shipping_address?: { line1?: string; line2?: string; city?: string; state?: string; zipcode?: string | number; country?: string };
  } }).customer_details;
  const shipping = details?.shipping_address;
  const countryCode = shipping?.country || 'IN';

  const shippingAddress = {
    name: details?.name || '',
    email: details?.email || '',
    phone: details?.contact || '',
    line1: shipping?.line1 || '',
    line2: shipping?.line2 || '',
    city: shipping?.city || '',
    state: shipping?.state || '',
    pincode: shipping?.zipcode ? String(shipping.zipcode) : '',
    country: ISO_CODE_TO_COUNTRY[countryCode] || countryCode,
  };

  let order = await prisma.order.update({
    where: { razorpayOrderId: razorpay_order_id },
    data: {
      razorpayPaymentId: razorpay_payment_id,
      razorpaySignature: razorpay_signature,
      paymentStatus: 'paid',
      status: 'fulfilling',
      shippingAddress,
      customerState: shippingAddress.state,
      customerCountry: shippingAddress.country,
    },
    include: {
      items: {
        include: {
          product: { include: { images: { take: 1, orderBy: { position: 'asc' } } } },
          variant: true,
        },
      },
    },
  });

  // Re-point the order from its placeholder guest customer to the real one,
  // found-or-created from the email Razorpay just gave us. The charge amount
  // was already fixed when the order was created — this only fixes up who
  // it's attributed to and, below, refines the GST split for the invoice.
  if (shippingAddress.email) {
    try {
      const existing = await prisma.customer.findUnique({ where: { email: shippingAddress.email } });
      const realCustomer =
        existing ||
        (await prisma.customer.create({
          data: {
            email: shippingAddress.email,
            name: shippingAddress.name || null,
            phone: shippingAddress.phone || null,
            passwordHash: await hashPassword(crypto.randomBytes(32).toString('hex')),
          },
        }));
      if (realCustomer.id !== order.customerId) {
        order = await prisma.order.update({
          where: { id: order.id },
          data: { customerId: realCustomer.id },
          include: {
            items: {
              include: {
                product: { include: { images: { take: 1, orderBy: { position: 'asc' } } } },
                variant: true,
              },
            },
          },
        });
      }
    } catch (err) {
      console.error('Failed to re-point order to real customer:', order.id, err);
    }
  }

  // Recompute the GST split now that we know the real delivery address —
  // this only refines the CGST/SGST/IGST breakdown for the invoice, it never
  // changes subtotal/shippingCost/total (the customer already paid that
  // exact amount via Razorpay).
  try {
    const cartItems = order.items.map((item) => ({
      productId: item.productId,
      variantId: item.variantId,
      quantity: item.quantity,
    }));
    const { computation } = await buildOrderTax(cartItems, { state: shippingAddress.state, country: shippingAddress.country });
    await prisma.order.update({
      where: { id: order.id },
      data: {
        taxableValue: computation.taxableValue,
        cgstAmount: computation.cgstTotal,
        sgstAmount: computation.sgstTotal,
        igstAmount: computation.igstTotal,
        totalTax: computation.totalTax,
        taxType: computation.taxType,
        gstRatesUsed: computation.lines,
      },
    });
  } catch (err) {
    console.error('Failed to recompute GST breakdown with real address:', order.id, err);
  }

  // Only counted against the code's usage limit once payment is actually
  // confirmed, so abandoned carts don't burn through a limited-use code.
  try {
    await recordDiscountUsage(order.discountCode);
  } catch (err) {
    console.error('Failed to record discount usage:', order.id, err);
  }

  // Push the order to CJ Dropshipping for fulfillment now that payment is confirmed.
  try {
    const cjOrderId = await submitOrderToCJ(order);
    await prisma.order.update({ where: { id: order.id }, data: { cjOrderId } });
  } catch (err) {
    console.error('CJ order submission failed, needs manual retry:', order.id, err);
  }

  // Allocate an invoice number and generate the PDF now that the order is paid.
  let invoiceNumber: string | null = null;
  let invoicePdfPath: string | null = null;
  try {
    ({ invoiceNumber } = await allocateInvoiceNumber());
    await prisma.order.update({ where: { id: order.id }, data: { invoiceNumber, invoiceDate: new Date() } });
    const { filePath } = await generateInvoicePdf(order.id);
    invoicePdfPath = filePath;
    await prisma.order.update({ where: { id: order.id }, data: { invoicePdfPath: filePath } });
  } catch (err) {
    console.error('Invoice generation failed, needs manual retry:', order.id, err);
  }

  // Send the order confirmation email with the invoice attached. Best-effort.
  try {
    if (shippingAddress.email) {
      const { subject, html, text } = buildOrderConfirmationEmail({ ...order, invoiceNumber: invoiceNumber ?? order.invoiceNumber });
      const attachments = invoicePdfPath
        ? [{ filename: `${invoiceNumber ?? 'invoice'}.pdf`, content: fs.readFileSync(invoicePdfPath), contentType: 'application/pdf' }]
        : undefined;
      await sendMail({ to: shippingAddress.email, subject, html, text, attachments });
    }
  } catch (err) {
    console.error('Order confirmation email failed:', order.id, err);
  }

  // Notify the store owner that a new order came in.
  try {
    const adminEmail = process.env.ADMIN_NOTIFICATION_EMAIL;
    if (adminEmail) {
      const { subject, html, text } = buildAdminOrderNotificationEmail(order);
      await sendMail({ to: adminEmail, subject, html, text });
    }
  } catch (err) {
    console.error('Admin order notification email failed:', order.id, err);
  }

  // Server-side Purchase event via Meta Conversions API.
  try {
    await sendMetaPurchaseEvent({
      eventId: `purchase-${order.id}`,
      email: shippingAddress.email,
      phone: shippingAddress.phone,
      value: Number(order.total),
      currency: order.currency,
      contentIds: order.items.map((item) => item.productId),
      clientIp: req.headers.get('x-forwarded-for'),
      userAgent: req.headers.get('user-agent'),
      sourceUrl: `${process.env.NEXT_PUBLIC_SITE_URL}/order-confirmed?orderId=${order.id}`,
    });
  } catch (err) {
    console.error('Meta Conversions API Purchase event failed:', order.id, err);
  }

  return NextResponse.json({ success: true, orderId: order.id });
}
