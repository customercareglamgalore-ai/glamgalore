// International orders (anywhere other than India) are priced 30% above the
// India price, rounded up to the nearest 10 — applied to the INR-equivalent
// unit price before FX conversion, so it's one well-defined "international
// price" per product regardless of which currency it ends up charged in.
// Domestic (India) orders are completely unaffected.

const INTERNATIONAL_MARKUP = 1.3;

export function isIndiaCountry(country: string): boolean {
  return country.trim().toLowerCase() === 'india';
}

export function applyInternationalMarkup(inrUnitPrice: number): number {
  return Math.ceil((inrUnitPrice * INTERNATIONAL_MARKUP) / 10) * 10;
}
