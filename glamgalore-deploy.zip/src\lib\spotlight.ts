// Shared turn-taking coordinator so the two floating "pop-up" surfaces on the
// site — the reel toast (ReelBubbles) and the Divine Notes affirmation —
// never show at the same time. They take turns: affirmation, then reel,
// then affirmation, then reel... Whichever surface isn't available on the
// current page (e.g. no reels on this page) is skipped, and the other one
// just keeps taking every turn.
//
// This is a plain singleton (not React state) so it keeps ticking across
// client-side navigations without caring which components are mounted.

export type SpotlightKind = 'affirmation' | 'reel';
type Listener = (active: SpotlightKind | null) => void;

const SHOW_MS = 3000;
const GAP_MS = 4000;

class Spotlight {
  private listeners = new Set<Listener>();
  private active: SpotlightKind | null = null;
  private reelAvailable = false;
  private started = false;
  private nextKind: SpotlightKind = 'affirmation';

  setReelAvailable(available: boolean) {
    this.reelAvailable = available;
  }

  subscribe(listener: Listener) {
    this.listeners.add(listener);
    listener(this.active);
    this.ensureStarted();
    return () => {
      this.listeners.delete(listener);
    };
  }

  private ensureStarted() {
    if (this.started) return;
    this.started = true;
    setTimeout(() => this.tick(), GAP_MS);
  }

  private emit() {
    this.listeners.forEach((listener) => listener(this.active));
  }

  private tick() {
    let kind = this.nextKind;
    if (kind === 'reel' && !this.reelAvailable) kind = 'affirmation';

    this.active = kind;
    this.emit();
    this.nextKind = kind === 'affirmation' ? 'reel' : 'affirmation';

    setTimeout(() => {
      this.active = null;
      this.emit();
      setTimeout(() => this.tick(), GAP_MS);
    }, SHOW_MS);
  }
}

export const spotlight = new Spotlight();
