import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/db';

const contactSchema = z.object({
  name: z.string().max(200).optional(),
  email: z.string().email(),
  phone: z.string().max(20).optional(),
  comment: z.string().min(1).max(4000),
});

export async function POST(req: NextRequest) {
  const parsed = contactSchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: 'Please fill in a valid email and message.' }, { status: 400 });
  }

  await prisma.contactMessage.create({
    data: {
      name: parsed.data.name,
      email: parsed.data.email,
      phone: parsed.data.phone,
      comment: parsed.data.comment,
    },
  });

  return NextResponse.json({ success: true });
}
