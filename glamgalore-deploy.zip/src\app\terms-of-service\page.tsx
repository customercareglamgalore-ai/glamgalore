import Reveal from '@/components/Reveal';

export const metadata = {
  title: 'Terms of Service — Glam Galore',
  description: 'The terms and conditions governing your use of Glam Galore.',
};

export default function TermsOfServicePage() {
  return (
    <main className="blog-post-page">
      <Reveal className="container blog-post-container">
        <h1>Terms of Service</h1>
        <div className="blog-post-body">
          <h2>Overview</h2>
          <p>
            This website is operated by GLAM GALORE. Throughout the site, the terms &ldquo;we&rdquo;,
            &ldquo;us&rdquo; and &ldquo;our&rdquo; refer to GLAM GALORE. GLAM GALORE offers this website,
            including all information and services available from this site to you, the user, conditioned
            upon your acceptance of all terms, conditions, policies and notices stated here.
          </p>
          <p>
            By visiting our site and/or purchasing something from us, you engage in our &ldquo;Service&rdquo;
            and agree to be bound by the following terms and conditions (&ldquo;Terms of Service&rdquo;,
            &ldquo;Terms&rdquo;), including those additional terms and conditions and policies referenced
            herein and/or available by hyperlink. These Terms of Service apply to all users of the site,
            including without limitation users who are browsers, vendors, customers, and contributors of
            content.
          </p>
          <p>
            Please read these Terms of Service carefully before accessing or using our website. By accessing
            or using any part of the site, you agree to be bound by these Terms of Service. If you do not
            agree to all the terms and conditions of this agreement, then you may not access the website or
            use any services.
          </p>
          <p>
            Any new features or tools which are added to the current store shall also be subject to these
            Terms of Service. We reserve the right to update, change or replace any part of these Terms of
            Service by posting updates and/or changes to our website. It is your responsibility to check this
            page periodically for changes. Your continued use of or access to the website following the
            posting of any changes constitutes acceptance of those changes.
          </p>

          <h2>Section 1 — Online Store Terms</h2>
          <p>
            By agreeing to these Terms of Service, you represent that you are at least the age of majority
            in your state or province of residence, or that you have given us your consent to allow any of
            your minor dependents to use this site.
          </p>
          <p>
            You may not use our products for any illegal or unauthorized purpose nor may you, in the use of
            the Service, violate any laws in your jurisdiction (including but not limited to copyright laws).
          </p>
          <p>You must not transmit any worms or viruses or any code of a destructive nature.</p>
          <p>A breach or violation of any of the Terms will result in an immediate termination of your Services.</p>

          <h2>Section 2 — General Conditions</h2>
          <p>We reserve the right to refuse service to anyone for any reason at any time.</p>
          <p>
            You understand that your content (not including credit card information) may be transferred
            unencrypted and involve (a) transmissions over various networks; and (b) changes to conform and
            adapt to technical requirements of connecting networks or devices. Credit card information is
            always encrypted during transfer over networks.
          </p>
          <p>
            You agree not to reproduce, duplicate, copy, sell, resell or exploit any portion of the Service,
            use of the Service, or access to the Service without express written permission by us.
          </p>

          <h2>Section 3 — Accuracy, Completeness and Timeliness of Information</h2>
          <p>
            We are not responsible if information made available on this site is not accurate, complete or
            current. The material on this site is provided for general information only and should not be
            relied upon or used as the sole basis for making decisions without consulting primary, more
            accurate, more complete or more timely sources of information. Any reliance on the material on
            this site is at your own risk.
          </p>
          <p>
            This site may contain certain historical information. Historical information is not current and
            is provided for your reference only. We reserve the right to modify the contents of this site at
            any time, but we have no obligation to update any information on our site.
          </p>

          <h2>Section 4 — Modifications to the Service and Prices</h2>
          <p>Prices for our products are subject to change without notice.</p>
          <p>We reserve the right at any time to modify or discontinue the Service (or any part or content thereof) without notice at any time.</p>
          <p>We shall not be liable to you or to any third party for any modification, price change, suspension or discontinuance of the Service.</p>

          <h2>Section 5 — Products or Services</h2>
          <p>
            Certain products or services may be available exclusively online through the website. These
            products or services may have limited quantities and are subject to return or exchange only
            according to our Returns &amp; Refunds policy.
          </p>
          <p>
            We have made every effort to display as accurately as possible the colors and images of our
            products that appear at the store. We cannot guarantee that your device&apos;s display of any
            color will be accurate.
          </p>
          <p>
            We reserve the right, but are not obligated, to limit the sales of our products or Services to
            any person, geographic region or jurisdiction, on a case-by-case basis. All descriptions of
            products or product pricing are subject to change at any time without notice, at our sole
            discretion. We reserve the right to discontinue any product at any time.
          </p>

          <h2>Section 6 — Accuracy of Billing and Account Information</h2>
          <p>
            We reserve the right to refuse any order you place with us. We may, in our sole discretion, limit
            or cancel quantities purchased per person, per household or per order. In the event that we make
            a change to or cancel an order, we may attempt to notify you using the contact details provided
            at the time the order was made.
          </p>
          <p>
            You agree to provide current, complete and accurate purchase and account information for all
            purchases made at our store, and to promptly update your information so that we can complete your
            transactions and contact you as needed.
          </p>
          <p>For more detail, please review our Returns &amp; Refunds policy.</p>

          <h2>Section 7 — Optional Tools</h2>
          <p>We may provide you with access to third-party tools over which we neither monitor nor have any control nor input.</p>
          <p>
            You acknowledge and agree that we provide access to such tools &ldquo;as is&rdquo; and &ldquo;as
            available&rdquo; without any warranties, representations or conditions of any kind and without
            any endorsement. We shall have no liability whatsoever arising from or relating to your use of
            optional third-party tools.
          </p>

          <h2>Section 8 — Third-Party Links</h2>
          <p>
            Certain content, products and services available via our Service may include materials from
            third parties. Third-party links on this site may direct you to third-party websites that are
            not affiliated with us. We are not responsible for examining or evaluating the content or
            accuracy of, and do not warrant and will not have any liability for, any third-party materials or
            websites.
          </p>

          <h2>Section 9 — User Comments, Feedback and Other Submissions</h2>
          <p>
            If you send us creative ideas, suggestions, proposals, plans, reviews, or other materials
            (collectively, &ldquo;comments&rdquo;), you agree that we may, at any time, without restriction,
            edit, copy, publish, distribute and otherwise use in any medium any comments that you forward to
            us, without obligation to maintain them in confidence or pay compensation.
          </p>
          <p>
            You agree that your comments will not violate any right of any third party, including copyright,
            trademark, privacy or other personal or proprietary right, and will not contain unlawful, abusive
            or obscene material.
          </p>

          <h2>Section 10 — Personal Information</h2>
          <p>Your submission of personal information through the store is governed by our Privacy Policy.</p>

          <h2>Section 11 — Errors, Inaccuracies and Omissions</h2>
          <p>
            Occasionally there may be information on our site or in the Service that contains typographical
            errors, inaccuracies or omissions relating to product descriptions, pricing, promotions, offers,
            shipping charges, transit times and availability. We reserve the right to correct any errors,
            inaccuracies or omissions, and to change or update information or cancel orders if any
            information is inaccurate at any time without prior notice, including after you have submitted
            your order.
          </p>

          <h2>Section 12 — Prohibited Uses</h2>
          <p>
            In addition to other prohibitions set forth in these Terms, you are prohibited from using the
            site or its content: (a) for any unlawful purpose; (b) to solicit others to perform or
            participate in any unlawful acts; (c) to violate any applicable regulations, rules or laws; (d) to
            infringe upon or violate our intellectual property rights or the intellectual property rights of
            others; (e) to harass, abuse, insult, harm, defame, slander, disparage, intimidate, or
            discriminate; (f) to submit false or misleading information; (g) to upload or transmit viruses or
            any other malicious code; (h) to collect or track the personal information of others; (i) to
            spam, phish, pharm, pretext, spider, crawl, or scrape; (j) for any obscene or immoral purpose; or
            (k) to interfere with or circumvent the security features of the Service.
          </p>

          <h2>Section 13 — Disclaimer of Warranties; Limitation of Liability</h2>
          <p>We do not guarantee, represent or warrant that your use of our service will be uninterrupted, timely, secure or error-free.</p>
          <p>
            You expressly agree that your use of, or inability to use, the Service is at your sole risk. The
            Service and all products and services delivered to you through the Service are (except as
            expressly stated by us) provided &ldquo;as is&rdquo; and &ldquo;as available&rdquo; for your use,
            without any representation, warranties or conditions of any kind, either express or implied.
          </p>
          <p>
            In no case shall GLAM GALORE, our directors, officers, employees, affiliates, agents, contractors,
            interns, suppliers, service providers or licensors be liable for any injury, loss, claim, or any
            direct, indirect, incidental, punitive, special, or consequential damages of any kind arising from
            your use of any of the Service or any products procured using the Service, or for any other claim
            related in any way to your use of the Service or any product, even if advised of their
            possibility. Because some jurisdictions do not allow the exclusion or limitation of liability for
            consequential or incidental damages, in such jurisdictions our liability shall be limited to the
            maximum extent permitted by law.
          </p>

          <h2>Section 14 — Indemnification</h2>
          <p>
            You agree to indemnify, defend and hold harmless GLAM GALORE and our affiliates, partners,
            officers, directors, agents, contractors, licensors, service providers, subcontractors, suppliers
            and employees, from any claim or demand, including reasonable attorneys&apos; fees, made by any
            third party due to or arising out of your breach of these Terms of Service or your violation of
            any law or the rights of a third party.
          </p>

          <h2>Section 15 — Severability</h2>
          <p>
            In the event that any provision of these Terms of Service is determined to be unlawful, void or
            unenforceable, that provision shall nonetheless be enforceable to the fullest extent permitted by
            applicable law, and the unenforceable portion shall be severed, without affecting the validity and
            enforceability of any remaining provisions.
          </p>

          <h2>Section 16 — Termination</h2>
          <p>
            These Terms of Service are effective unless and until terminated by either you or us. You may
            terminate at any time by notifying us that you no longer wish to use our Services, or by ceasing
            to use our site. If, in our sole judgment, you fail to comply with any term of these Terms of
            Service, we may terminate this agreement at any time without notice and deny you access to our
            Services.
          </p>

          <h2>Section 17 — Entire Agreement</h2>
          <p>
            The failure of us to exercise or enforce any right or provision of these Terms of Service shall
            not constitute a waiver of such right or provision. These Terms of Service and any policies or
            operating rules posted by us on this site constitute the entire agreement between you and us and
            govern your use of the Service, superseding any prior agreements or communications between you
            and us.
          </p>

          <h2>Section 18 — Governing Law</h2>
          <p>These Terms of Service shall be governed by and construed in accordance with the laws of India.</p>

          <h2>Section 19 — Changes to Terms of Service</h2>
          <p>
            We reserve the right, at our sole discretion, to update, change or replace any part of these
            Terms of Service by posting updates and changes to our website. Your continued use of or access
            to our website following the posting of any changes constitutes acceptance of those changes.
          </p>

          <h2>Section 20 — Contact Information</h2>
          <p>
            Questions about the Terms of Service should be sent to us at{' '}
            <a href="mailto:support@glamgalore.in">support@glamgalore.in</a>.
          </p>
        </div>
      </Reveal>
    </main>
  );
}
