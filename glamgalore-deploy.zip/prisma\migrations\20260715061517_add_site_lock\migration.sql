-- AlterTable
ALTER TABLE "StoreSettings" ADD COLUMN     "siteLocked" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "sitePassword" TEXT;
