'use client';

import { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Reveal from '@/components/Reveal';

type Customer = { id: string; name: string | null; email: string };

const linkStyle: React.CSSProperties = {
  background: 'none',
  border: 'none',
  padding: 0,
  textDecoration: 'underline',
  cursor: 'pointer',
};

export default function AccountPage() {
  return (
    <Suspense fallback={<main className="container"><p>Loading...</p></main>}>
      <AccountPageInner />
    </Suspense>
  );
}

function AccountPageInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get('redirect') || '/account';

  const [customer, setCustomer] = useState<Customer | null | undefined>(undefined);
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '' });
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then(({ customer }) => setCustomer(customer));
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    const res = await fetch(`/api/auth/${mode}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setSubmitting(false);

    if (!res.ok) {
      setError(data.error || 'Something went wrong');
      return;
    }
    setCustomer(data.customer);
    router.push(redirectTo);
  }

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    setCustomer(null);
  }

  if (customer === undefined) {
    return (
      <main className="container">
        <p>Loading...</p>
      </main>
    );
  }

  if (customer) {
    return (
      <main className="container" style={{ maxWidth: 480, margin: '0 auto' }}>
        <Reveal>
          <h1 className="section-heading">My account</h1>
          <p>Signed in as {customer.name || customer.email} ({customer.email})</p>
          <button className="btn" onClick={handleLogout}>Log out</button>
        </Reveal>
      </main>
    );
  }

  return (
    <main className="container" style={{ maxWidth: 480, margin: '0 auto' }}>
      <Reveal>
      <h1 className="section-heading">{mode === 'login' ? 'Log in' : 'Create an account'}</h1>

      <form onSubmit={handleSubmit}>
        {error && <p style={{ color: '#e22120' }}>{error}</p>}

        {mode === 'signup' && (
          <input
            placeholder="Full name"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            required
            style={{ display: 'block', width: '100%', padding: 10, margin: '8px 0' }}
          />
        )}
        <input
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          required
          style={{ display: 'block', width: '100%', padding: 10, margin: '8px 0' }}
        />
        {mode === 'signup' && (
          <input
            placeholder="Phone"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            style={{ display: 'block', width: '100%', padding: 10, margin: '8px 0' }}
          />
        )}
        <input
          type="password"
          placeholder="Password"
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          required
          minLength={8}
          style={{ display: 'block', width: '100%', padding: 10, margin: '8px 0' }}
        />

        <button type="submit" className="btn" disabled={submitting} style={{ width: '100%' }}>
          {submitting ? 'Please wait...' : mode === 'login' ? 'Log in' : 'Sign up'}
        </button>
      </form>

      <p style={{ marginTop: 16 }}>
        {mode === 'login' ? (
          <>Don&apos;t have an account?{' '}
            <button type="button" style={linkStyle} onClick={() => setMode('signup')}>Sign up</button>
          </>
        ) : (
          <>Already have an account?{' '}
            <button type="button" style={linkStyle} onClick={() => setMode('login')}>Log in</button>
          </>
        )}
      </p>
      </Reveal>
    </main>
  );
}
