'use client';

import { useState } from 'react';

type ReviewCard = {
  id: string;
  authorName: string;
  rating: number;
  body: string;
  imageUrl?: string | null;
  productTitle?: string;
};

export default function ReviewCarousel({ reviews }: { reviews: ReviewCard[] }) {
  // Some review photos come from a third-party CDN that's since revoked
  // access (broken links left over from before this store moved off its old
  // review app) — drop the whole card rather than show a broken image.
  const [brokenIds, setBrokenIds] = useState<Set<string>>(new Set());
  const visibleReviews = reviews.filter((r) => !brokenIds.has(r.id));

  function markBroken(id: string) {
    setBrokenIds((prev) => new Set(prev).add(id));
  }

  if (visibleReviews.length === 0) return null;

  // Duplicate the list so the CSS marquee can loop seamlessly from the end
  // of the first copy straight into the start of the second.
  const trackReviews = [...visibleReviews, ...visibleReviews];

  return (
    <div className="review-carousel">
      <div className="review-carousel-track">
        {trackReviews.map((r, i) => (
          <div className="review-card" key={`${r.id}-${i}`}>
            {r.imageUrl && (
              <div className="review-card-image">
                <img src={r.imageUrl} alt={r.authorName} loading="lazy" onError={() => markBroken(r.id)} />
              </div>
            )}
            <div className="review-card-stars">{'★'.repeat(r.rating)}</div>
            <p className="review-card-body">&ldquo;{r.body}&rdquo;</p>
            <p className="review-card-author">
              {r.authorName}
              {r.productTitle ? ` — ${r.productTitle}` : ''}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
