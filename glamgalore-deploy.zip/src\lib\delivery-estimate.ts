// Central place for the delivery-estimate policy, so the calculated window,
// the disclaimer copy, and the delayed threshold never drift out of sync.
// International orders quote a slightly longer window than domestic ones —
// see src/lib/international-pricing.ts's isIndiaCountry for the same
// India/international split used elsewhere (checkout pricing, tax).
export const DOMESTIC_MIN_DAYS = 15;
export const DOMESTIC_MAX_DAYS = 18;
export const DOMESTIC_DELAYED_AFTER_DAYS = 21;

export const INTERNATIONAL_MIN_DAYS = 18;
export const INTERNATIONAL_MAX_DAYS = 21;
export const INTERNATIONAL_DELAYED_AFTER_DAYS = 24;

function isIndia(country: string): boolean {
  return country.trim().toLowerCase() === 'india';
}

export function getDeliveryDisclaimer(country: string): string {
  return isIndia(country)
    ? `Please note our delivery timeline is between ${DOMESTIC_MIN_DAYS}-${DOMESTIC_MAX_DAYS} days and can be delayed up to ${DOMESTIC_DELAYED_AFTER_DAYS} days in certain circumstances. Thank you for your patience.`
    : `Please note our delivery timeline is between ${INTERNATIONAL_MIN_DAYS}-${INTERNATIONAL_MAX_DAYS} days and can be delayed up to ${INTERNATIONAL_DELAYED_AFTER_DAYS} days in certain circumstances. Thank you for your patience.`;
}

function addDays(date: Date, days: number): Date {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
}

export type DeliveryEstimate = {
  estimatedStart: Date;
  estimatedEnd: Date;
  isDelivered: boolean;
  isDelayed: boolean;
  /** 0-1, how far elapsed time is through the estimate window (clamped). */
  progress: number;
};

export function getDeliveryEstimate(
  orderCreatedAt: Date | string,
  orderStatus: string,
  country: string = 'India',
  now: Date = new Date()
): DeliveryEstimate {
  const createdAt = new Date(orderCreatedAt);
  const [minDays, maxDays, delayedAfterDays] = isIndia(country)
    ? [DOMESTIC_MIN_DAYS, DOMESTIC_MAX_DAYS, DOMESTIC_DELAYED_AFTER_DAYS]
    : [INTERNATIONAL_MIN_DAYS, INTERNATIONAL_MAX_DAYS, INTERNATIONAL_DELAYED_AFTER_DAYS];

  const estimatedStart = addDays(createdAt, minDays);
  const estimatedEnd = addDays(createdAt, maxDays);
  const delayedThreshold = addDays(createdAt, delayedAfterDays);

  const isDelivered = orderStatus === 'delivered';
  const isDelayed = !isDelivered && now.getTime() > delayedThreshold.getTime();

  const totalWindowMs = estimatedEnd.getTime() - createdAt.getTime();
  const elapsedMs = now.getTime() - createdAt.getTime();
  const progress = Math.min(1, Math.max(0, elapsedMs / totalWindowMs));

  return { estimatedStart, estimatedEnd, isDelivered, isDelayed, progress };
}
