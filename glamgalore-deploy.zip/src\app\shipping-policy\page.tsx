import Reveal from '@/components/Reveal';

export const metadata = {
  title: 'Shipping Policy — Glam Galore',
  description: 'Processing times, delivery estimates, tracking, and international shipping at Glam Galore.',
};

export default function ShippingPolicyPage() {
  return (
    <main className="blog-post-page">
      <Reveal className="container blog-post-container">
        <h1>Shipping Policy</h1>
        <div className="blog-post-body">
          <p>
            We strive to deliver products purchased from Glam Galore in excellent condition and in the
            fastest time possible. It normally takes between 2–3 business days to process and ship an order.
            Please note our delivery timeline is between 15–18 days and can be delayed up to 21 days in
            certain circumstances (excluding holidays and weekends). Your shipping cost will be calculated at
            checkout.
          </p>
          <p>
            If an order is cancelled before it is shipped from our warehouse, or is lost or undelivered to
            your address, we will refund the complete order amount including any shipping charges paid.
          </p>

          <h2>Do you deliver outside India?</h2>
          <p>Yes — we offer free shipping worldwide. Delivery time is 18–21 days.</p>

          <h2>How do I check the status of my order?</h2>
          <p>
            You will receive an order confirmation email once you place your order. Once your order ships,
            you can check its live status any time on our{' '}
            <a href="/track-order">Track Your Order</a> page using your order number and the email used at
            checkout. If you don&apos;t receive the order confirmation email, please write to us at{' '}
            <a href="mailto:support@glamgalore.in">support@glamgalore.in</a>.
          </p>

          <h2>How are my orders delivered?</h2>
          <p>All orders placed on Glam Galore are dispatched through our trusted courier and logistics partners.</p>

          <h2>What do I do if tracking says delivered but I haven&apos;t received my package?</h2>
          <p>
            Please contact the local courier first to check on the package. If it still hasn&apos;t been
            found, email us at <a href="mailto:support@glamgalore.in">support@glamgalore.in</a> and we will
            assist you as soon as possible.
          </p>

          <h2>I received a partial order or a tampered/void packet</h2>
          <p>
            Please reach out to us for pilferage within 48 hours of delivery, failing which the claim will
            not be entertained. While we investigate, please note:
          </p>
          <ul>
            <li>Do not use the item for which the claim is being raised.</li>
            <li>
              We may ask for a short description of the case and photos of the packet and box (if any),
              covering any sides that look tampered or damaged.
            </li>
            <li>The refund will be processed after the investigation.</li>
          </ul>
          <p>You may not be eligible for a refund if:</p>
          <ul>
            <li>Adequate information about the case was not provided.</li>
            <li>Snapshots of the packet and box (if any) were not provided.</li>
            <li>A pilferage claim was not made on the same day as delivery.</li>
            <li>
              The packaging was disposed of within 3–4 days of delivery — we may need to pick it up for
              investigation.
            </li>
            <li>The item for which the claim was raised has been used.</li>
          </ul>
        </div>
      </Reveal>
    </main>
  );
}
