import Reveal from '@/components/Reveal';
import TrackOrderForm from '@/components/TrackOrderForm';

export const metadata = {
  title: 'Track Your Order — Glam Galore',
  robots: { index: false, follow: false },
};

export default function TrackOrderPage() {
  return (
    <main className="container" style={{ maxWidth: 560, margin: '0 auto' }}>
      <Reveal>
        <h1 className="section-heading">Track Your Order</h1>
        <p>Enter your order number and the email you used at checkout to see the latest status.</p>
        <div style={{ marginTop: 32 }}>
          <TrackOrderForm />
        </div>
      </Reveal>
    </main>
  );
}
