// "Divine Notes" — ambient, non-interactive affirmations that float over the
// page as the customer browses, like the reel pop-up (ReelBubbles.tsx): one
// appears for a few seconds in an out-of-the-way spot, fades out, then
// another appears elsewhere. The two take turns via a shared coordinator
// (see src/lib/spotlight.ts) so they never show at the same time.
//
// Placements are position: fixed, so — like the WhatsApp button and the reel
// toast — they float over whatever content happens to be scrolled beneath
// them. To keep the "never covers products/buttons/prices" spirit as intact
// as floating allows: every placement stays clear of the two corners already
// claimed by other floating UI (bottom-right = WhatsApp button, bottom-left
// = reel toast on collection pages), keeps well clear of the very top so it
// never overlaps the header, and uses a low-opacity, pointer-events:none,
// small-width treatment so any incidental overlap with page content reads as
// a soft watermark rather than something blocking or jarring.

import type { CSSProperties } from 'react';

export const DIVINE_NOTE_AFFIRMATIONS = [
  'You are the muse.',
  'Your presence is the luxury.',
  'The universe conspires in your favor.',
  'Softness is your superpower.',
  'The right things recognize your energy.',
  'Luxury begins within.',
  'She remembered who she was.',
  "You don't chase. You attract.",
  'Every goddess deserves beautiful things.',
  'Lucky looks good on you.',
];

// A scatter of positions covering the whole page — corners, edges, and the
// center column — not just the left/right margins. Still clear of the
// bottom-left/bottom-right corners (reel toast / WhatsApp button) and the
// very top (header).
export const FLOAT_PLACEMENTS: CSSProperties[] = [
  { top: 'max(120px, 16vh)', left: '5%', textAlign: 'left', transform: 'rotate(-1deg)' },
  { top: 'max(110px, 12vh)', left: '50%', textAlign: 'center', transform: 'translateX(-50%) rotate(0.5deg)' },
  { top: 'max(120px, 18vh)', right: '6%', textAlign: 'right', transform: 'rotate(-1.5deg)' },
  { top: '30%', left: '28%', textAlign: 'left', transform: 'rotate(1deg)' },
  { top: '28%', right: '26%', textAlign: 'right', transform: 'rotate(-0.5deg)' },
  { top: '38%', left: '4%', textAlign: 'left', transform: 'rotate(1deg)' },
  { top: '34%', right: '5%', textAlign: 'right', transform: 'rotate(-0.5deg)' },
  { top: '46%', left: '50%', textAlign: 'center', transform: 'translateX(-50%) rotate(-1deg)' },
  { top: '58%', left: '6%', textAlign: 'left', transform: 'rotate(-1.2deg)' },
  { top: '55%', right: '7%', textAlign: 'right', transform: 'rotate(1.5deg)' },
  { top: '62%', left: '30%', textAlign: 'left', transform: 'rotate(0.8deg)' },
  { top: '60%', right: '28%', textAlign: 'right', transform: 'rotate(-0.8deg)' },
  { bottom: '30%', left: '50%', textAlign: 'center', transform: 'translateX(-50%) rotate(-0.5deg)' },
  { top: '24%', left: '50%', textAlign: 'center', transform: 'translateX(-50%) rotate(1deg)' },
  { bottom: '38%', right: '6%', textAlign: 'right', transform: 'rotate(1deg)' },
  { bottom: '40%', left: '6%', textAlign: 'left', transform: 'rotate(-1deg)' },
];
