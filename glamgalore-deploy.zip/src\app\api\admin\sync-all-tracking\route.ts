import { NextResponse } from 'next/server';
import { syncAllPendingTracking } from '@/lib/tracking-sync';

// Trigger manually from the admin, or point a scheduled job (system cron,
// e.g. hourly) at this route to keep tracking numbers flowing in automatically.
export async function POST() {
  const results = await syncAllPendingTracking();
  return NextResponse.json({ synced: results.length, results });
}
