import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET() {
  const rules = await prisma.taxRule.findMany({ orderBy: { category: 'asc' } });
  return NextResponse.json({ rules });
}

export async function POST(req: NextRequest) {
  const { category, gstRate, hsnCode } = await req.json();
  if (!category || gstRate === undefined || gstRate === null) {
    return NextResponse.json({ error: 'category and gstRate are required' }, { status: 400 });
  }

  const rule = await prisma.taxRule.upsert({
    where: { category },
    update: { gstRate, hsnCode: hsnCode || null },
    create: { category, gstRate, hsnCode: hsnCode || null },
  });

  return NextResponse.json({ ok: true, rule });
}

export async function DELETE(req: NextRequest) {
  const { id } = await req.json();
  if (!id) {
    return NextResponse.json({ error: 'id is required' }, { status: 400 });
  }
  await prisma.taxRule.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
