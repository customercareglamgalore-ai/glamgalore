import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET() {
  const reels = await prisma.reel.findMany({
    orderBy: { position: 'asc' },
    take: 200,
    include: { product: { select: { handle: true, title: true } } },
  });

  return NextResponse.json({
    reels: reels.map((r) => ({
      id: r.id,
      videoUrl: r.videoUrl,
      thumbnailUrl: r.thumbnailUrl,
      position: r.position,
      productHandle: r.product.handle,
      productTitle: r.product.title,
      featuredHome: r.featuredHome,
    })),
  });
}
