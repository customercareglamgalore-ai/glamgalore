import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import fs from 'fs';
import path from 'path';

const INBOX_DIR = path.join(process.cwd(), 'public', 'reels-inbox');
const REELS_DIR = path.join(process.cwd(), 'public', 'reels');
const SKIPPED_DIR = path.join(process.cwd(), 'public', 'reels-inbox', 'skipped');

function safeFilename(filename: string) {
  return path.basename(filename);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const filename = safeFilename(body.filename || '');
  const productHandle = body.productHandle as string | undefined;
  const skip = Boolean(body.skip);

  const sourcePath = path.join(INBOX_DIR, filename);
  if (!filename || !fs.existsSync(sourcePath)) {
    return NextResponse.json({ error: 'File not found' }, { status: 404 });
  }

  if (skip) {
    if (!fs.existsSync(SKIPPED_DIR)) fs.mkdirSync(SKIPPED_DIR, { recursive: true });
    fs.renameSync(sourcePath, path.join(SKIPPED_DIR, filename));
    return NextResponse.json({ ok: true, skipped: true });
  }

  if (!productHandle) {
    return NextResponse.json({ error: 'productHandle is required' }, { status: 400 });
  }

  const product = await prisma.product.findUnique({ where: { handle: productHandle } });
  if (!product) {
    return NextResponse.json({ error: 'Product not found' }, { status: 404 });
  }

  if (!fs.existsSync(REELS_DIR)) fs.mkdirSync(REELS_DIR, { recursive: true });
  fs.renameSync(sourcePath, path.join(REELS_DIR, filename));

  // position is a global ordering (used for both the homepage carousel and
  // this admin tool's reorder view), not per-product -- so new reels always
  // append to the very end regardless of which product they belong to.
  const last = await prisma.reel.findFirst({ orderBy: { position: 'desc' } });
  const nextPosition = (last?.position ?? -1) + 1;

  const reel = await prisma.reel.create({
    data: {
      productId: product.id,
      videoUrl: `/reels/${filename}`,
      position: nextPosition,
    },
  });

  return NextResponse.json({ ok: true, reel });
}
