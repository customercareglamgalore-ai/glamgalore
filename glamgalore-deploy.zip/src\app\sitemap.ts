import type { MetadataRoute } from 'next';
import { prisma } from '@/lib/db';
import { CATEGORY_LINKS, COLLECTION_LINKS } from '@/lib/collections';

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://glamgalore.in';

const STATIC_PAGES = [
  '',
  '/about',
  '/contact',
  '/blog',
  '/privacy-policy',
  '/terms-of-service',
  '/shipping-policy',
  '/returns-refunds',
  '/help-center',
  '/track-order',
];

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [products, blogPosts] = await Promise.all([
    prisma.product.findMany({ where: { status: 'active' }, select: { handle: true, updatedAt: true } }),
    prisma.blogPost.findMany({ select: { handle: true, publishedAt: true } }),
  ]);

  const staticEntries: MetadataRoute.Sitemap = STATIC_PAGES.map((path) => ({
    url: `${SITE_URL}${path}`,
    lastModified: new Date(),
  }));

  const collectionEntries: MetadataRoute.Sitemap = [...CATEGORY_LINKS, ...COLLECTION_LINKS]
    .filter((l) => l.href.startsWith('/collections/'))
    .map((l) => ({ url: `${SITE_URL}${l.href}`, lastModified: new Date() }));

  const productEntries: MetadataRoute.Sitemap = products.map((p) => ({
    url: `${SITE_URL}/products/${p.handle}`,
    lastModified: p.updatedAt,
  }));

  const blogEntries: MetadataRoute.Sitemap = blogPosts.map((p) => ({
    url: `${SITE_URL}/blog/${p.handle}`,
    lastModified: p.publishedAt,
  }));

  return [...staticEntries, ...collectionEntries, ...productEntries, ...blogEntries];
}
