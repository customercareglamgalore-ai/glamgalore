// Imports data/blog-posts.json (parsed from the Shopify "Blog Posts" Matrixify
// export) into Postgres.
//
// Usage: node scripts/import-blog-posts.js

const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();

function stripHtml(html) {
  return html
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

async function main() {
  const raw = fs.readFileSync(path.join(__dirname, '../data/blog-posts.json'), 'utf-8');
  const posts = JSON.parse(raw).filter((p) => p.published);

  console.log(`Importing ${posts.length} blog posts...`);

  for (const p of posts) {
    await prisma.blogPost.upsert({
      where: { handle: p.handle },
      update: {
        title: p.title,
        author: p.author,
        bodyHtml: p.bodyHtml,
        summary: stripHtml(p.summaryHtml),
        imageUrl: p.imageUrl,
        publishedAt: p.createdAt ? new Date(p.createdAt) : null,
      },
      create: {
        handle: p.handle,
        title: p.title,
        author: p.author,
        bodyHtml: p.bodyHtml,
        summary: stripHtml(p.summaryHtml),
        imageUrl: p.imageUrl,
        publishedAt: p.createdAt ? new Date(p.createdAt) : null,
      },
    });
  }

  console.log('Done.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
