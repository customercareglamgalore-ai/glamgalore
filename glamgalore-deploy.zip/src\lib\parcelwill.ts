// ParcelWILL (formerly ParcelPanel) tracking API client.
// Docs: https://docs.parcelpanel.com/woocommerce/api/pp-woo-api/
// This is their generic (non-Shopify-app) REST API — the right fit for a
// custom store like this one, since it supports pushing tracking numbers
// directly rather than relying on a platform-specific auto-sync app.

const BASE_URL = 'https://wp-api.parcelwill.net/api/v1/tracking';

function headers() {
  return {
    'PP-Api-Key': process.env.PARCELWILL_API_KEY!,
    'Content-Type': 'application/json',
  };
}

function isConfigured() {
  return Boolean(process.env.PARCELWILL_API_KEY);
}

export type ParcelWillCheckpoint = {
  status: string;
  message: string;
  location?: string;
  time: string;
};

export type ParcelWillTracking = {
  order_id: number | string;
  tracking_number: string;
  courier_code?: string;
  status?: string;
  checkpoints?: ParcelWillCheckpoint[];
};

// Pushes a tracking number to ParcelWILL once CJ has shipped an order.
// Safe to call again for the same order (ParcelWILL de-dupes on order_id).
export async function createTracking(input: {
  orderId: string;
  trackingNumber: string;
  courierCode?: string;
}): Promise<boolean> {
  if (!isConfigured()) {
    console.warn('ParcelWILL not configured (PARCELWILL_API_KEY missing) — skipping tracking push.');
    return false;
  }

  const res = await fetch(`${BASE_URL}/create`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({
      order_id: input.orderId,
      tracking_number: input.trackingNumber,
      courier_code: input.courierCode,
    }),
  });

  if (!res.ok) {
    console.error('ParcelWILL createTracking failed:', res.status, await res.text());
    return false;
  }
  return true;
}

// Looks up live tracking status/checkpoints for an order already pushed to ParcelWILL.
export async function listTracking(orderId: string): Promise<ParcelWillTracking | null> {
  if (!isConfigured()) return null;

  const res = await fetch(`${BASE_URL}/list`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ order_id: orderId }),
  });

  if (!res.ok) {
    console.error('ParcelWILL listTracking failed:', res.status, await res.text());
    return null;
  }
  const data = await res.json();
  return data?.data ?? null;
}
