// Hand-picked reels shown as an auto-cycling popup on collection pages.
// Each entry pins a specific Reel row (there can be several per product) and
// an optional display label override (defaults to the product's title).
import { prisma } from './db';

export const CURATED_REEL_BUBBLES = [
  { reelId: 'cmrf2zzn60005qm4gi9o5rf8b' }, // Aurelia (formerly Tallulah)
  { reelId: 'cmrevtufv003xvfyu0ksx8a57', label: 'GLAM GALORE' }, // Riviera
  { reelId: 'cmrf3v3dw0001ncv3xz6f0vyz' }, // Imani
  { reelId: 'cmrit4lzk0001stehcg07btvf' }, // Madison
  { reelId: 'cmrevegas001jvfyumxjel4hs' }, // Love Spark
];

export async function getCuratedReelBubbles() {
  const reels = await prisma.reel.findMany({
    where: { id: { in: CURATED_REEL_BUBBLES.map((c) => c.reelId) } },
    include: {
      product: {
        include: { images: { take: 1, orderBy: { position: 'asc' } }, variants: true },
      },
    },
  });
  const byId = new Map(reels.map((r) => [r.id, r]));

  return CURATED_REEL_BUBBLES.map((c) => {
    const r = byId.get(c.reelId);
    if (!r) return null;
    return {
      id: r.id,
      videoUrl: r.videoUrl,
      thumbnailUrl: r.thumbnailUrl,
      caption: r.caption,
      label: c.label || r.product.title,
      product: {
        id: r.product.id,
        handle: r.product.handle,
        title: r.product.title,
        price: r.product.price?.toString() || '',
        compareAtPrice: r.product.compareAtPrice?.toString(),
        imageUrl: r.product.images[0]?.url,
        variants: r.product.variants.map((v) => ({
          id: v.id,
          optionName: v.optionName,
          optionValue: v.optionValue,
          option2Name: v.option2Name,
          option2Value: v.option2Value,
          swatchHex: v.swatchHex,
          imageUrl: v.imageUrl,
        })),
      },
    };
  }).filter((x): x is NonNullable<typeof x> => x !== null);
}
