# Glam Galore — Deployment Handoff

This is a self-contained checklist to finish putting the latest version of the site live on `glamgalore.in`. Hand this to whoever is doing the server work — no other context should be needed.

## Current state (as of 2026-07-14)

- **Domain**: `glamgalore.in`, registered at Hostinger. Nameservers were switched to Hostinger's (`apollo.dns-parking.com` / `athena.dns-parking.com`) and DNS is propagating — may already be live by the time this is read, check with `dig +short glamgalore.in`.
- **VPS**: Hostinger KVM 2, hostname `srv1822472.hstgr.cloud`, IP **`200.97.168.89`**, Ubuntu 24.04 LTS, located in Mumbai. Reachable via Hostinger's **browser-based terminal** (hPanel → VPS → your server → "Terminal" button, top right) — this works even if direct SSH access is broken, since it authenticates through the Hostinger panel session rather than a password/key.
- **App**: Next.js site running under PM2 as process name `glamgalore`, working directory `/var/www/glamgalore`. Confirmed **online**, but running an **older version of the code** — everything built in the most recent work session (see "What's new" below) is only on the local development machine, not yet on this server.
- **Important**: `/var/www/glamgalore` is **not a git repository** — there's no `git pull` option. Code needs to be transferred to the server some other way (see Step 2 below for options).
- **SSH**: A password-based login was reset via hPanel → VPS → Overview → "Change" next to Root password. An SSH key was also added to `/root/.ssh/authorized_keys` during this session but was not confirmed working — password login is likely the more reliable option going forward, or use the Hostinger browser terminal directly.

## Step 1 — Confirm DNS has landed

```
dig +short glamgalore.in
```
Should return `200.97.168.89`. If not yet, wait — can take up to 24–48h after a nameserver change, though usually much faster.

## Step 2 — Get the latest code onto the server

The local project (on the Windows dev machine, folder `glamgalore-site`) is not a git repo, and neither is the copy on the VPS. Simplest options, in order of preference:

**Option A (recommended) — set up git properly, once:**
1. Create a private GitHub repo.
2. From the local project folder: `git init`, `git add .`, commit, push to the new repo (exclude `.env`, `node_modules`, `.next` via `.gitignore`).
3. On the VPS: `cd /var/www && git clone <repo-url> glamgalore-new`, copy the real `.env` into it, then swap it in for the old `/var/www/glamgalore` folder.
4. From then on, deploying is just `git pull && npm install && npx prisma migrate deploy && npm run build && pm2 restart glamgalore` — repeatable and low-risk.

**Option B — direct file transfer (no git):**
1. On the local machine, zip the project folder **excluding** `node_modules`, `.next`, and `.env`.
2. `scp` the zip to the server (needs working SSH — see SSH note above).
3. Unzip into `/var/www/glamgalore` (back up the existing folder first: `cp -r /var/www/glamgalore /var/www/glamgalore-backup-$(date +%F)`).
4. Copy the production `.env` back in (don't overwrite it with the local dev one — see Step 3).
5. `npm install && npx prisma migrate deploy && npm run build && pm2 restart glamgalore`

## Step 3 — Production `.env`

On the server, `/var/www/glamgalore/.env` needs:
```
NEXT_PUBLIC_SITE_URL="https://glamgalore.in"
```
(Confirm this is actually set to the real domain, not `localhost` — it feeds every email link, OG tag, and absolute image URL sent to customers.)

**Do not overwrite the server's `.env` with the local development one** — the server's has production Razorpay/database credentials that must be preserved.

## Step 4 — SSL certificate

```
sudo nano /etc/nginx/sites-available/glamgalore
# confirm: server_name glamgalore.in www.glamgalore.in;

sudo nginx -t && sudo systemctl reload nginx

sudo certbot --nginx -d glamgalore.in -d www.glamgalore.in
```
Accept certbot's offer to auto-redirect HTTP → HTTPS.

## Step 5 — Verify

- `curl -I https://glamgalore.in` should return `200 OK`.
- Load the homepage in a browser.
- Load `/admin/reports` — should prompt for Basic Auth (`ADMIN_USER` / `ADMIN_PASSWORD` from `.env`).

## Still outstanding (not part of this deployment, but flagged)

**SMTP is not configured anywhere** — `sendMail()` in the codebase silently no-ops without it. This means **no customer has ever received an order confirmation or shipping email**, in production or otherwise, for the entire life of this store so far. Needs a provider (Gmail app password is fastest to stand up; SendGrid/Resend are more production-grade) and the corresponding `SMTP_*` env vars added to `.env`.

## What's new in this session (why deploying matters)

- Product "Tallulah" renamed to "Aurelia" throughout
- 30% international price markup (rounded to nearest ₹10), zero tax on international orders
- All prices shown tax-inclusive to customers; full GST breakdown only visible in `/admin`
- Redesigned order-confirmation and shipping-confirmation emails
- Order-confirmed page: product images added, headline changed to "Your wish is our command"
- "Divine Notes" — floating ambient affirmations, alternating with the existing reel pop-up so they never overlap
- "You may also like" section added to product pages
- Track-order lookup fixed to accept historical Shopify order numbers (with/without `#`/`GG` prefix)
- Six new legal/info pages: About, Privacy Policy, Terms of Service, Shipping Policy, Returns & Refunds, Help Center — plus About Us added to the homepage
- Shipping policy simplified: free worldwide shipping, 18–21 day international delivery estimate
- New "Sold Out" feature: products can be marked `isOutOfStock` (currently set on WRAPPED UP and OFF DUTY) — shows a badge on cards, disables purchase on the product page, and is blocked server-side at checkout too
