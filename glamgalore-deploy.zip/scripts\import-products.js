// Imports data/products.json into Postgres.
//
// This expects the merged shape produced from the native Shopify CSV export
// (products_export_1.csv) combined with the Matrixify metafield export:
// real prices, variants (color/size), images, and collections are all
// present. See data/products.json for the exact shape.
//
// Usage: DATABASE_URL=postgres://... node scripts/import-products.js
// Optional: pass --active-only to skip draft/archived products.

const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();
const activeOnly = process.argv.includes('--active-only');

async function main() {
  const raw = fs.readFileSync(path.join(__dirname, '../data/products.json'), 'utf-8');
  let products = JSON.parse(raw);

  if (activeOnly) {
    products = products.filter((p) => p.status === 'active');
  }

  console.log(`Importing ${products.length} products${activeOnly ? ' (active only)' : ''}...`);

  // Shopify's native product CSV has no creation-date column, so `createdAt`
  // used to default to "whenever this import ran" -- unrelated to real
  // Shopify history, which broke "newest/oldest" sorting and made the
  // homepage's Top Selling / Celebrity Closet picks arbitrary. Numeric
  // Shopify product IDs are assigned in strictly increasing order as
  // products are created, so we use ID rank as a reliable stand-in for
  // real creation order and synthesize evenly-spaced timestamps from it.
  const ranked = [...products].sort((a, b) => {
    const aId = a.shopify_id ? BigInt(a.shopify_id) : -1n;
    const bId = b.shopify_id ? BigInt(b.shopify_id) : -1n;
    return aId < bId ? -1 : aId > bId ? 1 : 0;
  });
  const createdAtByHandle = new Map();
  const baseTime = new Date('2022-01-01T00:00:00Z').getTime();
  ranked.forEach((p, i) => {
    createdAtByHandle.set(p.handle, new Date(baseTime + i * 60000));
  });

  let created = 0;
  let skipped = 0;

  for (const p of products) {
    if (!p.price) {
      skipped++;
      continue;
    }

    const createdAt = createdAtByHandle.get(p.handle);

    const product = await prisma.product.upsert({
      where: { handle: p.handle },
      update: {
        title: p.title,
        descriptionHtml: p.description_html,
        description: p.description || null,
        features: p.features || [],
        seoTitle: p.seo_title || null,
        seoDescription: p.seo_description || null,
        vendor: p.vendor,
        type: p.type,
        tags: p.tags,
        collections: p.collections || [],
        price: p.price,
        compareAtPrice: p.compare_at_price,
        shopifyId: p.shopify_id ? String(p.shopify_id) : undefined,
        status: p.status,
        createdAt,
      },
      create: {
        createdAt,
        handle: p.handle,
        title: p.title,
        descriptionHtml: p.description_html,
        description: p.description || null,
        features: p.features || [],
        seoTitle: p.seo_title || null,
        seoDescription: p.seo_description || null,
        vendor: p.vendor,
        type: p.type,
        tags: p.tags,
        collections: p.collections || [],
        price: p.price,
        compareAtPrice: p.compare_at_price,
        shopifyId: p.shopify_id ? String(p.shopify_id) : undefined,
        status: p.status,
      },
    });

    // Replace images/variants on each run so re-imports stay in sync with the export.
    await prisma.productImage.deleteMany({ where: { productId: product.id } });
    if (p.images?.length) {
      await prisma.productImage.createMany({
        data: p.images.map((img) => ({
          productId: product.id,
          url: img.url,
          position: img.position || 0,
        })),
      });
    }

    await prisma.productVariant.deleteMany({ where: { productId: product.id } });
    if (p.variants?.length) {
      await prisma.productVariant.createMany({
        data: p.variants.map((v) => ({
          productId: product.id,
          optionName: v.option1_name,
          optionValue: v.option1_value,
          option2Name: v.option2_name,
          option2Value: v.option2_value,
          imageUrl: v.variant_image || null,
          price: v.price_inr,
          sku: v.sku,
          inventoryQty: 0, // not in this export -- sync separately via CJ or Shopify inventory export
        })),
      });
    }

    created++;
  }

  console.log(`Done. Created/updated: ${created}. Skipped (no price): ${skipped}.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
