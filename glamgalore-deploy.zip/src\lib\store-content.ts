// Static copy shown on every product page. Fill these in with the real
// policy/cause text — left blank for now, and the accordion section for
// each is skipped while its value is empty.
export const INTERNATIONAL_SHIPPING_INFO =
  "We offer free international shipping so Glam Galore can reach you no matter where you are. Every order is carefully prepared before it's shipped, with an estimated delivery timeline of 18–21 business days.";
export const FOR_A_CAUSE_INFO =
  "Every Purchase Makes a Difference.\n\nAt Glam Galore, fashion is about more than what you wear—it's about the impact you create.\n\nWe're proud to donate 1% of our proceeds to a rescue foundation supporting survivors of sex trafficking, helping provide them with safety, rehabilitation, and a chance to rebuild their lives.\n\nThank you for shopping with purpose and being part of something bigger than fashion.";

// No real size chart data exists anywhere in the product export (checked
// body_html, metafields) — only generic supplier disclaimer text mentioning
// "check the size chart" with no actual measurements. Add real measurements
// here (e.g. a table per garment type) once you have them.
export const SIZE_CHART_INFO = '';

// Pulled from the real "INCHES" page (handle: dimensions) in the Shopify
// pages export. Measurements are in cm, matching the table header on that
// page verbatim.
export const SIZE_CHART_NOTE =
  'This is a standard size chart, and the sizing may vary from piece to piece. Kindly WhatsApp us at 9769708781 with your Bust, Waist & Hip measurement for the accurate sizing.';

export const SIZE_CHART_TABLE = {
  unit: 'cm',
  columns: ['Size', 'Bust', 'Waist', 'Hips'],
  rows: [
    ['S', '78-84', '60-64', '77-92'],
    ['M', '82-88', '64-68', '81-96'],
    ['L', '86-92', '68-72', '85-100'],
    ['XL', '90-96', '72-76', '104-110'],
  ],
};
