import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';
import { prisma } from '@/lib/db';
import { getStoreSettings } from '@/lib/settings';

const INVOICES_DIR = path.join(process.cwd(), 'storage', 'invoices');

type ShippingAddress = {
  name: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
  country?: string;
};

const TAX_TYPE_LABEL: Record<string, string> = {
  intra_state: 'Intra-state (CGST + SGST)',
  inter_state: 'Inter-state (IGST)',
  export_zero_rated: 'Zero-rated export supply — no GST charged',
  export_taxed: 'Export supply (IGST)',
};

export function invoicePdfPath(invoiceNumber: string) {
  return path.join(INVOICES_DIR, `${invoiceNumber}.pdf`);
}

export async function generateInvoicePdf(orderId: string): Promise<{ filePath: string }> {
  const order = await prisma.order.findUniqueOrThrow({
    where: { id: orderId },
    include: { items: { include: { product: true, variant: true } }, customer: true },
  });

  if (!order.invoiceNumber) {
    throw new Error(`Order ${orderId} has no invoiceNumber allocated yet`);
  }

  const settings = await getStoreSettings();
  const address = order.shippingAddress as unknown as ShippingAddress;

  if (!fs.existsSync(INVOICES_DIR)) fs.mkdirSync(INVOICES_DIR, { recursive: true });
  const filePath = invoicePdfPath(order.invoiceNumber);

  const doc = new PDFDocument({ size: 'A4', margin: 50 });
  const writeStream = fs.createWriteStream(filePath);
  doc.pipe(writeStream);

  // Business header
  doc.fontSize(18).font('Helvetica-Bold').text(settings.businessLegalName);
  doc.fontSize(9).font('Helvetica');
  if (settings.businessGSTIN) doc.text(`GSTIN: ${settings.businessGSTIN}`);
  const bizAddressLines = [settings.businessAddressLine1, settings.businessAddressLine2]
    .filter(Boolean)
    .concat([[settings.businessCity, settings.businessState, settings.businessPincode].filter(Boolean).join(', ')]);
  bizAddressLines.forEach((line) => line && doc.text(line));

  doc.moveDown(1);
  doc.fontSize(16).font('Helvetica-Bold').text('TAX INVOICE', { align: 'center' });
  doc.moveDown(1);

  // Invoice meta + bill-to, side by side
  const metaTop = doc.y;
  doc.fontSize(10).font('Helvetica-Bold').text('Invoice Number:', 50, metaTop, { continued: true }).font('Helvetica').text(` ${order.invoiceNumber}`);
  doc.font('Helvetica-Bold').text('Invoice Date:', 50, doc.y, { continued: true }).font('Helvetica').text(` ${order.invoiceDate?.toLocaleDateString('en-IN') ?? ''}`);
  doc.font('Helvetica-Bold').text('Order ID:', 50, doc.y, { continued: true }).font('Helvetica').text(` ${order.id}`);
  doc.font('Helvetica-Bold').text('Place of Supply:', 50, doc.y, { continued: true }).font('Helvetica').text(` ${TAX_TYPE_LABEL[order.taxType] ?? order.taxType}`);

  doc.font('Helvetica-Bold').text('Bill / Ship To:', 320, metaTop);
  doc.font('Helvetica').fontSize(9);
  doc.text(address.name, 320);
  doc.text(address.line1, 320);
  if (address.line2) doc.text(address.line2, 320);
  doc.text(`${address.city}, ${address.state} ${address.pincode}`, 320);
  doc.text(order.customerCountry, 320);
  if (order.customerGSTIN) doc.text(`GSTIN: ${order.customerGSTIN}`, 320);

  doc.moveDown(2);

  // Line items table
  const tableTop = doc.y;
  const cols = { hsn: 50, desc: 110, qty: 290, rate: 330, taxable: 390, tax: 450, total: 510 };
  doc.fontSize(9).font('Helvetica-Bold');
  doc.text('HSN', cols.hsn, tableTop);
  doc.text('Description', cols.desc, tableTop);
  doc.text('Qty', cols.qty, tableTop);
  doc.text('Rate', cols.rate, tableTop);
  doc.text('Taxable', cols.taxable, tableTop);
  doc.text('Tax', cols.tax, tableTop);
  doc.text('Total', cols.total, tableTop);
  doc.moveTo(50, doc.y + 4).lineTo(560, doc.y + 4).stroke();
  doc.moveDown(0.6);

  doc.font('Helvetica');
  order.items.forEach((item) => {
    const y = doc.y;
    const variantLabel = item.variant
      ? ` (${[item.variant.optionValue, item.variant.option2Value].filter(Boolean).join('/')})`
      : '';
    const lineTax = Number(item.cgstAmount ?? 0) + Number(item.sgstAmount ?? 0) + Number(item.igstAmount ?? 0);
    const lineTotal = Number(item.taxableValue ?? 0) + lineTax;

    doc.text(item.hsnCode ?? '—', cols.hsn, y, { width: 55 });
    doc.text(`${item.product.title}${variantLabel}`, cols.desc, y, { width: 175 });
    doc.text(String(item.quantity), cols.qty, y, { width: 35 });
    doc.text(`Rs. ${Number(item.unitPrice).toFixed(2)}`, cols.rate, y, { width: 55 });
    doc.text(`Rs. ${Number(item.taxableValue ?? 0).toFixed(2)}`, cols.taxable, y, { width: 55 });
    doc.text(`Rs. ${lineTax.toFixed(2)}`, cols.tax, y, { width: 55 });
    doc.text(`Rs. ${lineTotal.toFixed(2)}`, cols.total, y, { width: 55 });
    doc.moveDown(1);
  });

  doc.moveTo(50, doc.y + 2).lineTo(560, doc.y + 2).stroke();
  doc.moveDown(1);

  // Totals block — explicit label/value columns (rather than continued+align,
  // which wraps unpredictably once the combined text exceeds pdfkit's implicit
  // column width for longer rows like "Taxable Value:"/"Grand Total:").
  const totalsLabelX = 350;
  const totalsValueX = 450;
  function totalRow(label: string, value: string, bold = false) {
    doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(10);
    const y = doc.y;
    doc.text(label, totalsLabelX, y, { width: 95 });
    doc.text(value, totalsValueX, y, { width: 110, align: 'right' });
    doc.y = y;
    doc.moveDown(1);
  }

  totalRow('Taxable Value:', `Rs. ${Number(order.taxableValue).toFixed(2)}`);
  if (order.taxType === 'intra_state') {
    totalRow('CGST:', `Rs. ${Number(order.cgstAmount).toFixed(2)}`);
    totalRow('SGST:', `Rs. ${Number(order.sgstAmount).toFixed(2)}`);
  } else if (order.taxType === 'inter_state' || order.taxType === 'export_taxed') {
    totalRow('IGST:', `Rs. ${Number(order.igstAmount).toFixed(2)}`);
  }
  if (Number(order.discountAmount) > 0) {
    totalRow('Discount:', `Rs. -${Number(order.discountAmount).toFixed(2)}`);
  }
  totalRow('Shipping:', `Rs. ${Number(order.shippingCost).toFixed(2)}`);
  totalRow('Grand Total:', `Rs. ${Number(order.total).toFixed(2)}`, true);

  if (order.taxType === 'export_zero_rated') {
    doc.moveDown(1.5);
    doc.fontSize(9).font('Helvetica-Oblique').text('Zero-rated export supply — no GST charged on this invoice.', 50);
  }

  doc.end();

  await new Promise<void>((resolve, reject) => {
    writeStream.on('finish', () => resolve());
    writeStream.on('error', reject);
  });

  return { filePath };
}
