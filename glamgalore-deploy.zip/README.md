# Glam Galore — custom storefront (migration from Shopify)

## Data status: complete

`data/products.json` now has the full picture, merged from your native
Shopify CSV export plus the Matrixify metafield export:

- **1,076 total products** (747 active, 328 draft, 1 archived)
- **Real INR prices and compare-at prices** per variant
- **Images** — 5 on average per product, in original order
- **Variants** — color/size options, one row per SKU
- **Collections** — 26 real collections (barbiecore, swimwear, co-ords, etc.),
  deduplicated from the join-table export
- **Reel/review flags** — which products have ReelUp reels (76) or
  Judge.me/spr reviews (96) attached, ready for a follow-up pass to import
  the actual review text and reel video URLs

Also extracted: `data/collections.json` (26 collections) and
`data/discounts.json` (304 historical discount codes, in case you want to
recreate any active ones on the new site).

## What's in this scaffold

- **`prisma/schema.prisma`** — database schema: products, variants, reviews,
  reels, customers, orders, and CJ Dropshipping/Razorpay fields.
- **`scripts/import-products.js`** — loads `products.json` into Postgres,
  including images and variants. Run with `--active-only` to skip drafts.
- **`src/app/api/checkout/create-order/route.ts`** — creates a Razorpay order,
  recomputing the total server-side from the database.
- **`src/app/api/checkout/verify/route.ts`** — verifies the Razorpay payment
  signature, then submits the paid order to CJ Dropshipping for fulfillment.
- **`src/lib/cj-dropshipping.ts`** — CJ API client: product sync, order
  submission, tracking lookup.
- **`src/app/products/[handle]/page.tsx`** + `ReviewList` / `ReelStrip`
  components — product page rebuilding what Judge.me/spr reviews and ReelUp
  reels were doing on the old theme.

## The website itself: built

- **`src/app/globals.css`** — real brand tokens pulled from your live theme's
  settings (black/white/serif, `#e22120` red accent) instead of a generic
  template look.
- **`src/app/page.tsx`** — homepage rebuilding your actual section order:
  hero → Top Selling → Shop by Category → Celebrity Closet → Featured
  Collections, matching `templates/index.json` from your theme export.
- **`src/app/collections/[handle]/page.tsx`** — collection pages, pulling
  live from your 26 real collections.
- **`src/app/products/[handle]/page.tsx`** — product page with reviews and
  reel sections.
- **`src/app/cart/page.tsx`** + **`/api/cart/hydrate`** — cart page that
  re-fetches current prices from the database rather than trusting stale
  localStorage data.
- **`src/app/checkout/page.tsx`** — full checkout: collects shipping details,
  opens Razorpay's payment sheet, verifies the signature, and hands off to
  CJ Dropshipping for fulfillment. This is the complete buy flow, wired
  end to end.
- **`src/components/Header.tsx`** / **`Footer.tsx`** — site chrome.

## Reviews and reels: what's actually recoverable

- **Reviews — fully recovered.** `data/reviews.json` has 148 real reviews
  (author, star rating, text, photo URLs) parsed straight out of the
  metafield JSON. `scripts/import-reviews.js` loads them into the database,
  linked to their product by handle. Run this after `import-products.js`.

- **Reels — only ID references, not the videos.** `data/reel_references.json`
  shows 84 products have a ReelUp reel attached, but the export only stores
  a numeric ID (e.g. `[157930]`) pointing into ReelUp's own hosting — the
  actual video files aren't in any of the files you've given me. To recover
  the reel videos themselves, you'd need to either: (a) check if ReelUp's
  app dashboard has a bulk video export/download option, or (b) I can write
  a script against ReelUp's API if you have access to it — let me know
  which app plan you're on and I'll check what's possible.



## Still to do

1. ~~**Customer accounts.**~~ Done — `src/lib/auth.ts` + `/api/auth/*` +
   `/account` page. Signup/login use bcrypt-hashed passwords and a signed
   httpOnly session cookie. Checkout now requires a logged-in customer and
   derives `customerId` from the session server-side (never trusts the
   request body) before creating an `Order`.
2. **CJ product binding.** Each product needs a `cjProductId` (and each
   variant a `cjVariantId`) so orders route to the right CJ listing.
3. **Reel videos** — deferred per your request. `data/reel_references.json`
   is there whenever you're ready to pick it back up.
4. **Hosting** — needs Node.js + Postgres (VPS/Cloud plan, not basic shared
   hosting).
5. **Real Razorpay + CJ Dropshipping API keys** — currently placeholders in
   `.env`. Checkout order-creation works end to end (verified locally); only
   the live Razorpay call needs real keys.

## Setup (once you're on a VPS)

```bash
npm install
cp .env.example .env   # fill in real values, including a random SESSION_SECRET
npx prisma migrate dev --name init
npm run migrate:products -- --active-only
node scripts/import-reviews.js
npm run dev
```

Generate `SESSION_SECRET` with:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```
