-- AlterTable
ALTER TABLE "ProductVariant" ADD COLUMN     "option2Name" TEXT,
ADD COLUMN     "option2Value" TEXT;
