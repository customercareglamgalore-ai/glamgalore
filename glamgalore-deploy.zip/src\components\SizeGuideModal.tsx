'use client';

import { useEffect } from 'react';
import { createPortal } from 'react-dom';
import { SIZE_CHART_NOTE, SIZE_CHART_TABLE } from '@/lib/store-content';

export default function SizeGuideModal({ onClose }: { onClose: () => void }) {
  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose();
    }
    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return createPortal(
    <div className="size-guide-overlay" onClick={onClose}>
      <div className="size-guide-modal" onClick={(e) => e.stopPropagation()}>
        <button type="button" className="size-guide-close" aria-label="Close" onClick={onClose}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
            <line x1="5" y1="5" x2="19" y2="19" />
            <line x1="19" y1="5" x2="5" y2="19" />
          </svg>
        </button>

        <h2 className="size-guide-title">Size Guide</h2>
        <p className="size-guide-note">{SIZE_CHART_NOTE}</p>

        <div className="size-guide-table-wrap">
          <table className="size-guide-table">
            <thead>
              <tr>
                {SIZE_CHART_TABLE.columns.map((col) => (
                  <th key={col}>
                    {col === 'Size' ? col : `${col} (${SIZE_CHART_TABLE.unit})`}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {SIZE_CHART_TABLE.rows.map((row) => (
                <tr key={row[0]}>
                  {row.map((cell, i) => (
                    <td key={i}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>,
    document.body
  );
}
