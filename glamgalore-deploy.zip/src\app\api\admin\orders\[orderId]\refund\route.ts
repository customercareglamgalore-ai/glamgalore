import { NextRequest, NextResponse } from 'next/server';
import Razorpay from 'razorpay';
import { prisma } from '@/lib/db';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function POST(req: NextRequest, { params }: { params: Promise<{ orderId: string }> }) {
  const { orderId } = await params;
  const { amount, reason } = await req.json();

  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 });
  }
  if (!order.razorpayPaymentId) {
    return NextResponse.json({ error: 'Order has no captured payment to refund' }, { status: 400 });
  }
  if (!amount || amount <= 0 || amount > Number(order.total) - Number(order.refundedAmount)) {
    return NextResponse.json({ error: 'Invalid refund amount' }, { status: 400 });
  }

  // Issue the real refund via Razorpay first — only record it once that succeeds.
  await razorpay.payments.refund(order.razorpayPaymentId, {
    amount: Math.round(amount * 100),
    notes: reason ? { reason } : undefined,
  });

  // Proportional tax netting: refunding X% of the order value also nets out
  // X% of the tax that was charged on it, for accurate GST reporting.
  const refundRatio = amount / Number(order.total);
  const additionalRefundedTax = refundRatio * Number(order.totalTax);

  const newRefundedAmount = Number(order.refundedAmount) + amount;
  const newRefundedTax = Number(order.refundedTax) + additionalRefundedTax;
  const refundStatus = newRefundedAmount >= Number(order.total) ? 'full' : 'partial';

  const updated = await prisma.order.update({
    where: { id: orderId },
    data: {
      refundedAmount: newRefundedAmount,
      refundedTax: newRefundedTax,
      refundStatus,
      paymentStatus: refundStatus === 'full' ? 'refunded' : order.paymentStatus,
    },
  });

  return NextResponse.json({ ok: true, order: updated });
}
