import { prisma } from '@/lib/db';
import { fetchCJTracking } from '@/lib/cj-dropshipping';
import { createTracking } from '@/lib/parcelwill';
import { sendMail } from '@/lib/email';
import { buildShippingConfirmationEmail } from '@/lib/email-templates/shipping-confirmation';

export type TrackingSyncResult = {
  orderId: string;
  updated: boolean;
  trackingNumber?: string;
  pushedToParcelWill?: boolean;
  error?: string;
};

// Pulls current tracking info from CJ for one order, saves it locally, and
// pushes it to ParcelWILL so the customer-facing /track-order page (and
// ParcelWILL's own notifications, if enabled) have real data to show.
// Safe to call repeatedly — re-fetches and re-pushes idempotently.
export async function syncOrderTracking(orderId: string): Promise<TrackingSyncResult> {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) return { orderId, updated: false, error: 'Order not found' };
  if (!order.cjOrderId) return { orderId, updated: false, error: 'Order has no cjOrderId — not yet submitted to CJ' };

  try {
    const cjTracking = await fetchCJTracking(order.cjOrderId);
    const trackingNumber: string | undefined = cjTracking?.trackNumber;
    const carrier: string | undefined = cjTracking?.logisticName;

    if (!trackingNumber) {
      return { orderId, updated: false, error: 'CJ has no tracking number yet (order likely not shipped)' };
    }

    const updated = await prisma.order.update({
      where: { id: orderId },
      data: { trackingNumber, trackingCarrier: carrier, status: 'shipped' },
      include: {
        items: {
          include: {
            product: { include: { images: { take: 1, orderBy: { position: 'asc' } } } },
            variant: true,
          },
        },
      },
    });

    const pushed = await createTracking({ orderId: order.id, trackingNumber, courierCode: carrier });

    // Best-effort — no-ops silently if SMTP isn't configured yet, never fails the sync.
    try {
      const address = updated.shippingAddress as unknown as { email?: string };
      if (address.email) {
        const { subject, html, text } = buildShippingConfirmationEmail(updated, trackingNumber);
        await sendMail({ to: address.email, subject, html, text });
      }
    } catch (err) {
      console.error('Shipping confirmation email failed:', orderId, err);
    }

    return { orderId, updated: true, trackingNumber, pushedToParcelWill: pushed };
  } catch (err) {
    return { orderId, updated: false, error: err instanceof Error ? err.message : String(err) };
  }
}

// Runs the sync across every order that's been submitted to CJ but doesn't
// have a tracking number locally yet. Call this from an admin action or a
// scheduled job (e.g. a system cron hitting a protected route every hour).
export async function syncAllPendingTracking(): Promise<TrackingSyncResult[]> {
  const pending = await prisma.order.findMany({
    where: { cjOrderId: { not: null }, trackingNumber: null },
    select: { id: true },
  });

  const results: TrackingSyncResult[] = [];
  for (const { id } of pending) {
    results.push(await syncOrderTracking(id));
  }
  return results;
}
