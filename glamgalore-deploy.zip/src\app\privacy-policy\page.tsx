import Reveal from '@/components/Reveal';

export const metadata = {
  title: 'Privacy Policy — Glam Galore',
  description: 'How Glam Galore collects, uses, and discloses your personal information.',
};

export default function PrivacyPolicyPage() {
  return (
    <main className="blog-post-page">
      <Reveal className="container blog-post-container">
        <h1>Privacy Policy</h1>
        <div className="blog-post-body">
          <p>
            Glam Galore operates this store and website, including all related information, content,
            features, tools, products and services, in order to provide you, the customer, with a curated
            shopping experience (the &ldquo;Services&rdquo;). This Privacy Policy describes how we collect,
            use, and disclose your personal information when you visit, use, or make a purchase or other
            transaction using the Services or otherwise communicate with us. If there is a conflict between
            our Terms of Service and this Privacy Policy, this Privacy Policy controls with respect to the
            collection, processing, and disclosure of your personal information.
          </p>
          <p>
            Please read this Privacy Policy carefully. By using and accessing any of the Services, you
            acknowledge that you have read this Privacy Policy and understand the collection, use, and
            disclosure of your information as described in this Privacy Policy.
          </p>

          <h2>Personal Information We Collect or Process</h2>
          <p>
            When we use the term &ldquo;personal information&rdquo;, we are referring to information that
            identifies or can reasonably be linked to you or another person. We may collect or process the
            following categories of personal information, depending on how you interact with the Services:
          </p>
          <ul>
            <li>Contact details including your name, billing address, shipping address, phone number, and email address.</li>
            <li>
              Payment information including card or UPI details, transaction details, form of payment, and
              payment confirmation — processed on our behalf by our payment gateway partner (Razorpay); we do
              not store your full card or bank details ourselves.
            </li>
            <li>Account information including your username, password, preferences and settings.</li>
            <li>Transaction information including items you view, add to cart or wishlist, purchase, return, exchange or cancel, and your past orders.</li>
            <li>Communications with us, for example when sending a customer support inquiry.</li>
            <li>Device information including information about your device, browser, network connection, IP address, and other identifiers.</li>
            <li>Usage information including how and when you interact with or navigate the Services.</li>
          </ul>

          <h2>Personal Information Sources</h2>
          <p>We may collect personal information from the following sources:</p>
          <ul>
            <li>Directly from you, including when you create an account, place an order, or communicate with us;</li>
            <li>Automatically through the Services, including through cookies and similar technologies;</li>
            <li>From our service providers, when they collect or process personal information on our behalf; and</li>
            <li>From our partners or other third parties.</li>
          </ul>

          <h2>How We Use Your Personal Information</h2>
          <ul>
            <li>
              <strong>Provide, tailor and improve the Services.</strong> To process your payments, fulfil and
              ship your orders, remember your preferences, send order and account notifications, process
              returns and exchanges, and create a personalised shopping experience.
            </li>
            <li>
              <strong>Marketing and advertising.</strong> To send marketing communications by email or
              WhatsApp, and to show you relevant advertisements on our site or elsewhere (including through
              Meta&apos;s advertising tools).
            </li>
            <li>
              <strong>Security and fraud prevention.</strong> To authenticate your account, provide a secure
              checkout experience, and detect or prevent fraudulent or unauthorised activity.
            </li>
            <li>
              <strong>Communicating with you.</strong> To provide customer support and maintain our business
              relationship with you.
            </li>
            <li>
              <strong>Legal reasons.</strong> To comply with applicable law, respond to valid legal process,
              and enforce our Terms of Service.
            </li>
          </ul>

          <h2>How We Disclose Personal Information</h2>
          <p>We may disclose your personal information to third parties for legitimate purposes, including:</p>
          <ul>
            <li>Our payment gateway partner (Razorpay), to securely process your payment;</li>
            <li>Our fulfilment and logistics partners (including our dropshipping/fulfilment partner and courier companies), to ship your order and provide tracking;</li>
            <li>Vendors who support our operations (e.g. hosting, email delivery, and analytics providers);</li>
            <li>Meta (Facebook/Instagram), for advertising and analytics via tools such as the Meta Pixel;</li>
            <li>When you direct or consent to our disclosure of information to a third party; and</li>
            <li>To comply with applicable legal obligations, enforce our terms or policies, or protect the rights of Glam Galore, our users, or others.</li>
          </ul>

          <h2>Third-Party Websites and Links</h2>
          <p>
            The Services may provide links to websites or online platforms operated by third parties. We do
            not guarantee and are not responsible for the privacy or security practices of such sites. Review
            their own privacy policies before providing any information to them.
          </p>

          <h2>Children&apos;s Data</h2>
          <p>
            The Services are not intended for use by children, and we do not knowingly collect personal
            information from children under the age of majority in their jurisdiction. If you are a parent or
            guardian and believe your child has provided us with personal information, contact us using the
            details below to request its deletion.
          </p>

          <h2>Security and Retention of Your Information</h2>
          <p>
            No security measures are perfect or impenetrable, and we cannot guarantee &ldquo;perfect
            security&rdquo;. We recommend that you do not use unsecure channels to communicate sensitive or
            confidential information to us. We retain your personal information for as long as needed to
            provide the Services, comply with legal obligations, resolve disputes, and enforce our agreements
            and policies — including retaining order and invoicing records as required under applicable Indian
            tax law.
          </p>

          <h2>Your Rights and Choices</h2>
          <p>Depending on where you live, you may have some or all of the following rights in relation to your personal information:</p>
          <ul>
            <li><strong>Right to access/know</strong> — request access to personal information we hold about you.</li>
            <li><strong>Right to delete</strong> — request that we delete personal information we maintain about you.</li>
            <li><strong>Right to correct</strong> — request that we correct inaccurate personal information.</li>
            <li><strong>Right of portability</strong> — request a copy of your personal information, in certain circumstances.</li>
            <li>
              <strong>Managing communication preferences</strong> — you may opt out of promotional emails at
              any time using the unsubscribe link. We may still send non-promotional emails, such as those
              about your account or orders.
            </li>
          </ul>
          <p>
            You may exercise any of these rights by contacting us using the details below. We may need to
            verify your identity before processing your request, as permitted or required under applicable
            law. We will not discriminate against you for exercising any of these rights.
          </p>

          <h2>Complaints</h2>
          <p>
            If you have concerns about how we process your personal information, please contact us using the
            details below. You may also have the right to lodge a complaint with your local data protection
            authority.
          </p>

          <h2>International Transfers</h2>
          <p>
            As we ship internationally and work with service providers located in different countries, we may
            transfer, store and process your personal information outside the country you live in, using
            appropriate safeguards where required by applicable law.
          </p>

          <h2>Changes to This Privacy Policy</h2>
          <p>
            We may update this Privacy Policy from time to time to reflect changes to our practices or for
            other operational, legal, or regulatory reasons. We will post the revised Privacy Policy on this
            page and update the &ldquo;last updated&rdquo; date.
          </p>

          <h2>Contact Us</h2>
          <p>
            Questions or complaints about this Privacy Policy, or requests relating to your personal
            information, can be sent to our Grievance Officer at{' '}
            <a href="mailto:support@glamgalore.in">support@glamgalore.in</a>.
          </p>

          <p style={{ fontSize: 13, color: '#999', marginTop: 32 }}>Last updated: 14 July 2026.</p>
        </div>
      </Reveal>
    </main>
  );
}
