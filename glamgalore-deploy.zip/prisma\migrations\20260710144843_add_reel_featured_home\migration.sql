-- AlterTable
ALTER TABLE "Reel" ADD COLUMN     "featuredHome" BOOLEAN NOT NULL DEFAULT true;
