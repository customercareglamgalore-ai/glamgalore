// Creates a Razorpay order for the "Magic Checkout" flow — cart page sends
// the customer straight into Razorpay's own popup (which collects name,
// phone, and address), instead of our custom checkout form. Because we
// don't have the customer's address yet at this point, tax/shipping are
// computed assuming domestic (India) pricing — shipping is free worldwide
// regardless, and GST is only ever a display/invoicing breakdown of an
// already tax-inclusive sticker price, so it never changes the amount
// actually charged. The real address (and a final, address-accurate tax
// breakdown) is filled in during /api/checkout/verify-magic, once Razorpay
// hands it back after payment.
import { NextRequest, NextResponse } from 'next/server';
import Razorpay from 'razorpay';
import crypto from 'crypto';
import { prisma } from '@/lib/db';
import { getCustomerIdFromSession, hashPassword, setSessionCookie } from '@/lib/auth';
import { buildOrderTax, OrderTaxError } from '@/lib/order-tax';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function POST(req: NextRequest) {
  const { cartItems, discountCode } = await req.json();
  if (!Array.isArray(cartItems) || cartItems.length === 0) {
    return NextResponse.json({ error: 'Cart is empty' }, { status: 400 });
  }

  let customerId = await getCustomerIdFromSession();
  if (!customerId) {
    // No address/email yet — this placeholder customer gets re-pointed to
    // the real one (found-or-created from the email Razorpay hands back)
    // once payment is verified.
    const placeholderEmail = `guest-${crypto.randomUUID()}@pending.glamgalore.in`;
    const customer = await prisma.customer.create({
      data: { email: placeholderEmail, passwordHash: await hashPassword(crypto.randomBytes(32).toString('hex')) },
    });
    customerId = customer.id;
    await setSessionCookie(customerId);
  }

  let computation;
  let lineMeta;
  let discountAmount;
  let appliedDiscountCode;
  try {
    ({ computation, lineMeta, discountAmount, discountCode: appliedDiscountCode } = await buildOrderTax(
      cartItems,
      { state: '', country: 'India' },
      discountCode,
    ));
  } catch (err) {
    if (err instanceof OrderTaxError) {
      return NextResponse.json({ error: err.message }, { status: err.status });
    }
    throw err;
  }

  const products = await prisma.product.findMany({ where: { id: { in: lineMeta.map((m) => m.productId) } } });
  const productById = new Map(products.map((p) => [p.id, p]));

  const order = await prisma.order.create({
    data: {
      customerId,
      status: 'pending',
      subtotal: computation.subtotal,
      shippingCost: computation.shippingCost,
      total: computation.grandTotal,
      shippingAddress: {},
      currency: 'INR',
      discountCode: appliedDiscountCode,
      discountAmount,
      taxableValue: computation.taxableValue,
      cgstAmount: computation.cgstTotal,
      sgstAmount: computation.sgstTotal,
      igstAmount: computation.igstTotal,
      totalTax: computation.totalTax,
      taxType: computation.taxType,
      gstRatesUsed: computation.lines,

      items: {
        create: lineMeta.map((meta, i) => {
          const line = computation.lines[i];
          return {
            productId: meta.productId,
            variantId: meta.variantId,
            quantity: meta.quantity,
            unitPrice: meta.unitPrice,
            hsnCode: line.hsnCode,
            gstRate: line.gstRate,
            taxableValue: line.taxableValue,
            cgstAmount: line.cgstAmount,
            sgstAmount: line.sgstAmount,
            igstAmount: line.igstAmount,
          };
        }),
      },
    },
  });

  const lineItems = lineMeta.map((meta) => {
    const product = productById.get(meta.productId);
    const unitPricePaise = Math.round(meta.unitPrice * 100);
    return {
      sku: product?.handle || meta.productId,
      variant_id: meta.variantId || undefined,
      price: unitPricePaise,
      offer_price: unitPricePaise,
      quantity: meta.quantity,
      name: product?.title || 'Product',
    };
  });

  const amountPaise = Math.round(computation.grandTotal * 100);

  const razorpayOrder = await razorpay.orders.create({
    amount: amountPaise,
    currency: 'INR',
    receipt: order.id,
    line_items_total: amountPaise,
    line_items: lineItems,
  });

  await prisma.order.update({
    where: { id: order.id },
    data: { razorpayOrderId: razorpayOrder.id },
  });

  return NextResponse.json({
    orderId: order.id,
    razorpayOrderId: razorpayOrder.id,
    amount: razorpayOrder.amount,
    currency: razorpayOrder.currency,
    keyId: process.env.RAZORPAY_KEY_ID,
  });
}
