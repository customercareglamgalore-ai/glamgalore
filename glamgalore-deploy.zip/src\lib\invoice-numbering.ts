import { prisma } from '@/lib/db';
import { getStoreSettings } from '@/lib/settings';

// Atomically allocates the next invoice number. A single UPDATE...RETURNING
// is serialized by Postgres row-level locking, so concurrent callers can't
// hand out the same sequence number — no explicit transaction needed.
export async function allocateInvoiceNumber(): Promise<{ invoiceNumber: string; sequence: number }> {
  await getStoreSettings(); // ensure the singleton row exists before we increment it

  const rows = await prisma.$queryRaw<{ seq: number }[]>`
    UPDATE "StoreSettings"
    SET "nextInvoiceSequence" = "nextInvoiceSequence" + 1
    WHERE id = 'singleton'
    RETURNING "nextInvoiceSequence" - 1 AS seq
  `;
  const seq = rows[0].seq;

  const settings = await getStoreSettings();
  const invoiceNumber = `${settings.invoicePrefix}${String(seq).padStart(settings.invoiceNumberPadding, '0')}`;

  return { invoiceNumber, sequence: seq };
}
