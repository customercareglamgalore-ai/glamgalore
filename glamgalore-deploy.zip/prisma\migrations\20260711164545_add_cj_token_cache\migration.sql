-- AlterTable
ALTER TABLE "StoreSettings" ADD COLUMN     "cjAccessToken" TEXT,
ADD COLUMN     "cjAccessTokenExpiresAt" TIMESTAMP(3),
ADD COLUMN     "cjRefreshToken" TEXT,
ADD COLUMN     "cjRefreshTokenExpiresAt" TIMESTAMP(3);
