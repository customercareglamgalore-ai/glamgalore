import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { createTracking } from '@/lib/parcelwill';
import { sendMail } from '@/lib/email';
import { buildShippingConfirmationEmail } from '@/lib/email-templates/shipping-confirmation';

// Manual tracking entry — for orders with no cjOrderId (e.g. historical
// imports) or whenever a tracking number needs to be set/corrected by hand.
// Saves it locally and pushes it to ParcelWILL, same as the automated sync.
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ orderId: string }> }) {
  const { orderId } = await params;
  const { trackingNumber, trackingCarrier } = await req.json();

  if (!trackingNumber) {
    return NextResponse.json({ error: 'trackingNumber is required' }, { status: 400 });
  }

  const order = await prisma.order.update({
    where: { id: orderId },
    data: { trackingNumber, trackingCarrier: trackingCarrier || null, status: 'shipped' },
    include: {
      items: {
        include: {
          product: { include: { images: { take: 1, orderBy: { position: 'asc' } } } },
          variant: true,
        },
      },
    },
  });

  const pushed = await createTracking({ orderId: order.id, trackingNumber, courierCode: trackingCarrier });

  // Best-effort — no-ops silently if SMTP isn't configured yet, never fails the request.
  try {
    const address = order.shippingAddress as unknown as { email?: string };
    if (address.email) {
      const { subject, html, text } = buildShippingConfirmationEmail(order, trackingNumber);
      await sendMail({ to: address.email, subject, html, text });
    }
  } catch (err) {
    console.error('Shipping confirmation email failed:', order.id, err);
  }

  return NextResponse.json({ ok: true, orderId: order.id, trackingNumber, pushedToParcelWill: pushed });
}
