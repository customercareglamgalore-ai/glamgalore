// Manually completes an order that Razorpay actually charged but that never
// got marked paid on our side (e.g. the client browser left the page for a
// UPI/bank redirect before the JS handler could fire, and this happened
// before the webhook safety net existed). Protected by the same admin Basic
// Auth as everything else under /api/admin — see src/middleware.ts.
import { NextRequest, NextResponse } from 'next/server';
import Razorpay from 'razorpay';
import { completeMagicOrder } from '@/lib/complete-magic-order';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function POST(req: NextRequest) {
  const { razorpayOrderId } = await req.json();
  if (!razorpayOrderId) {
    return NextResponse.json({ error: 'razorpayOrderId is required' }, { status: 400 });
  }

  const { items: payments } = await razorpay.orders.fetchPayments(razorpayOrderId);
  const captured = payments.find((p) => p.status === 'captured');
  if (!captured) {
    return NextResponse.json({
      error: 'No captured payment found for this order on Razorpay — nothing to reconcile.',
      payments: payments.map((p) => ({ id: p.id, status: p.status })),
    }, { status: 400 });
  }

  const result = await completeMagicOrder(razorpayOrderId, captured.id);
  return NextResponse.json(result);
}
