// Imports historical orders from a Shopify/Matrixify "Orders" export (.xlsx)
// into our own Order/OrderItem/Customer tables. The GST breakdown is NOT
// trusted from the source file (Shopify's historical tax setup was
// inconsistent) -- it's recomputed fresh through our own tax engine, exactly
// like a live checkout would, so reports/invoices reflect correct GST.
import ExcelJS from 'exceljs';
import crypto from 'crypto';
import { prisma } from '@/lib/db';
import { getStoreSettings } from '@/lib/settings';
import { computeOrderTax, resolveLineRate, type TaxLineInput } from '@/lib/tax';
import { allocateInvoiceNumber } from '@/lib/invoice-numbering';
import { generateInvoicePdf } from '@/lib/invoice-pdf';
import { hashPassword } from '@/lib/auth';

const FALLBACK_HSN = '6109';

export type ImportResult = {
  imported: number;
  skipped: number;
  errors: string[];
};

function cell(row: unknown[], idx: Record<string, number>, name: string): unknown {
  return row[idx[name]];
}

function str(v: unknown): string {
  if (v === null || v === undefined) return '';
  return String(v).replace(/^'/, '').trim(); // strip Excel's text-format leading apostrophe
}

function num(v: unknown): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

export async function importShopifyOrdersXlsx(buffer: Buffer): Promise<ImportResult> {
  const workbook = new ExcelJS.Workbook();
  // exceljs's bundled types predate newer Node Buffer generics; the value is a real Buffer at runtime.
  await workbook.xlsx.load(buffer as unknown as Parameters<typeof workbook.xlsx.load>[0]);
  const sheet = workbook.getWorksheet('Orders');
  if (!sheet) {
    throw new Error('No "Orders" sheet found in this file — expected a Shopify/Matrixify orders export.');
  }

  const header = sheet.getRow(1).values as unknown[];
  const idx: Record<string, number> = {};
  header.forEach((h, i) => {
    if (typeof h === 'string') idx[h] = i;
  });

  const required = ['ID', 'Name', 'Top Row', 'Line: Type', 'Line: Product Handle', 'Customer: Email'];
  const missingCols = required.filter((c) => idx[c] === undefined);
  if (missingCols.length) {
    throw new Error(`Missing expected columns: ${missingCols.join(', ')}`);
  }

  const groups = new Map<string, unknown[][]>();
  sheet.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return;
    const values = row.values as unknown[];
    const id = str(cell(values, idx, 'ID'));
    if (!id) return;
    if (!groups.has(id)) groups.set(id, []);
    groups.get(id)!.push(values);
  });

  const settings = await getStoreSettings();
  type CachedProduct = { id: string; type: string | null; hsnCode: string | null; gstRateOverride: unknown };
  const productCache = new Map<string, CachedProduct | null>();
  const titleCache = new Map<string, CachedProduct | null>();
  const ruleCache = new Map<string, { gstRate: number; hsnCode: string | null } | null>();

  const orderedGroups = [...groups.values()].sort((a, b) => {
    const top = (rows: unknown[][]) => rows.find((r) => cell(r, idx, 'Top Row')) ?? rows[0];
    const da = new Date(str(cell(top(a), idx, 'Created At'))).getTime();
    const db = new Date(str(cell(top(b), idx, 'Created At'))).getTime();
    return da - db;
  });

  let imported = 0;
  let skipped = 0;
  const errors: string[] = [];

  for (const rows of orderedGroups) {
    const top = rows.find((r) => cell(r, idx, 'Top Row')) ?? rows[0];
    const orderName = str(cell(top, idx, 'Name')) || str(cell(top, idx, 'ID'));

    try {
      const email = str(cell(top, idx, 'Customer: Email')).toLowerCase();
      if (!email) {
        skipped++;
        errors.push(`${orderName}: no customer email, skipped`);
        continue;
      }

      const existing = await prisma.order.findFirst({
        where: { shippingAddress: { path: ['shopifyOrderName'], equals: orderName } },
      });
      if (existing) {
        skipped++;
        continue;
      }

      const lineItemRows = rows.filter(
        (r) =>
          cell(r, idx, 'Line: Type') === 'Line Item' &&
          (str(cell(r, idx, 'Line: Product Handle')) || str(cell(r, idx, 'Line: Title'))),
      );
      if (lineItemRows.length === 0) {
        skipped++;
        errors.push(`${orderName}: no product line items, skipped`);
        continue;
      }

      // Some export rows have a blank Line: Product Handle but a populated Line: Title
      // (seen on several real orders in this file) -- fall back to matching by title.
      const handles = [...new Set(lineItemRows.map((r) => str(cell(r, idx, 'Line: Product Handle'))).filter(Boolean))];
      const missingHandles = handles.filter((h) => !productCache.has(h));
      if (missingHandles.length) {
        const products = await prisma.product.findMany({
          where: { handle: { in: missingHandles } },
          select: { id: true, handle: true, type: true, hsnCode: true, gstRateOverride: true },
        });
        const found = new Set(products.map((p) => p.handle));
        products.forEach((p) => productCache.set(p.handle, p));
        missingHandles.forEach((h) => {
          if (!found.has(h)) productCache.set(h, null);
        });
      }

      const titles = [...new Set(lineItemRows.map((r) => str(cell(r, idx, 'Line: Title'))).filter(Boolean))];
      const missingTitles = titles.filter((t) => !titleCache.has(t.toLowerCase()));
      if (missingTitles.length) {
        const products = await prisma.product.findMany({
          where: { title: { in: missingTitles, mode: 'insensitive' } },
          select: { id: true, title: true, type: true, hsnCode: true, gstRateOverride: true },
        });
        const found = new Set(products.map((p) => p.title.toLowerCase()));
        products.forEach((p) => titleCache.set(p.title.toLowerCase(), p));
        missingTitles.forEach((t) => {
          if (!found.has(t.toLowerCase())) titleCache.set(t.toLowerCase(), null);
        });
      }

      const taxLines: TaxLineInput[] = [];
      const lineMeta: { productId: string; quantity: number; unitPrice: number }[] = [];

      for (const r of lineItemRows) {
        const handle = str(cell(r, idx, 'Line: Product Handle'));
        const title = str(cell(r, idx, 'Line: Title'));
        const product = (handle && productCache.get(handle)) || (title && titleCache.get(title.toLowerCase()));
        if (!product) {
          errors.push(`${orderName}: product "${handle || title}" not found — line skipped`);
          continue;
        }

        const quantity = num(cell(r, idx, 'Line: Quantity')) || 1;
        const unitPrice = num(cell(r, idx, 'Line: Price'));

        let categoryRule: { gstRate: number; hsnCode: string | null } | null = null;
        if (product.type) {
          if (!ruleCache.has(product.type)) {
            const rule = await prisma.taxRule.findUnique({ where: { category: product.type } });
            ruleCache.set(product.type, rule ? { gstRate: Number(rule.gstRate), hsnCode: rule.hsnCode } : null);
          }
          categoryRule = ruleCache.get(product.type) ?? null;
        }

        const { gstRate, hsnCode } = resolveLineRate({
          unitPrice,
          productGstRateOverride: product.gstRateOverride ? Number(product.gstRateOverride) : null,
          productHsnCode: product.hsnCode,
          categoryRule,
          useApparelPriceSlabs: settings.useApparelPriceSlabs,
          apparelSlabThreshold: Number(settings.apparelSlabThreshold),
          apparelSlabRateBelow: Number(settings.apparelSlabRateBelow),
          apparelSlabRateAbove: Number(settings.apparelSlabRateAbove),
          defaultGstRate: Number(settings.defaultGstRate),
          fallbackHsnCode: FALLBACK_HSN,
        });

        taxLines.push({ productId: product.id, quantity, unitPrice, hsnCode, gstRate });
        lineMeta.push({ productId: product.id, quantity, unitPrice });
      }

      if (taxLines.length === 0) {
        skipped++;
        errors.push(`${orderName}: no matching products, skipped`);
        continue;
      }

      const firstName = str(cell(top, idx, 'Customer: First Name')) || str(cell(top, idx, 'Shipping: First Name'));
      const lastName = str(cell(top, idx, 'Customer: Last Name')) || str(cell(top, idx, 'Shipping: Last Name'));
      const fullName = `${firstName} ${lastName}`.trim() || str(cell(top, idx, 'Shipping: Name')) || 'Customer';
      const phone = str(cell(top, idx, 'Phone')) || str(cell(top, idx, 'Customer: Phone'));

      let customer = await prisma.customer.findUnique({ where: { email } });
      if (!customer) {
        const placeholderHash = await hashPassword(crypto.randomUUID());
        customer = await prisma.customer.create({ data: { email, name: fullName, phone, passwordHash: placeholderHash } });
      }

      const country = str(cell(top, idx, 'Shipping: Country')) || str(cell(top, idx, 'Billing: Country')) || 'India';
      const state = str(cell(top, idx, 'Shipping: Province')) || str(cell(top, idx, 'Billing: Province'));

      const shippingAddress = {
        name: fullName,
        line1: str(cell(top, idx, 'Shipping: Address 1')) || str(cell(top, idx, 'Billing: Address 1')),
        line2: str(cell(top, idx, 'Shipping: Address 2')) || str(cell(top, idx, 'Billing: Address 2')),
        city: str(cell(top, idx, 'Shipping: City')) || str(cell(top, idx, 'Billing: City')),
        state,
        pincode: str(cell(top, idx, 'Shipping: Zip')) || str(cell(top, idx, 'Billing: Zip')),
        country,
        gstin: null,
        shopifyOrderName: orderName,
      };

      const shippingCost = num(cell(top, idx, 'Price: Total Shipping'));
      const discountAmount = num(cell(top, idx, 'Price: Total Discount'));

      const computation = computeOrderTax(taxLines, shippingCost, {
        customerState: state,
        customerCountry: country,
        businessState: settings.businessState,
        pricesIncludeTax: settings.pricesIncludeTax,
        chargeTaxOnInternational: settings.chargeTaxOnInternational,
        discountAmount,
      });

      const shopifyPaymentStatus = str(cell(top, idx, 'Payment: Status'));
      const refundedAmount = num(cell(top, idx, 'Price: Total Refund'));
      const refundRatio = computation.grandTotal > 0 ? refundedAmount / computation.grandTotal : 0;
      const refundedTax = refundRatio * computation.totalTax;
      const refundStatus = refundedAmount <= 0 ? 'none' : refundedAmount >= computation.grandTotal ? 'full' : 'partial';
      const paymentStatus = shopifyPaymentStatus === 'refunded' ? 'refunded' : 'paid';

      const fulfillment = str(cell(top, idx, 'Order Fulfillment Status'));
      const status = fulfillment === 'fulfilled' ? 'shipped' : fulfillment === 'partial' ? 'fulfilling' : 'paid';

      const createdAt = new Date(str(cell(top, idx, 'Created At')));

      const order = await prisma.order.create({
        data: {
          customerId: customer.id,
          status,
          paymentStatus,
          subtotal: computation.subtotal,
          shippingCost: computation.shippingCost,
          total: computation.grandTotal,
          shippingAddress,
          currency: 'INR',
          fxRateApplied: 1,
          discountAmount,
          taxableValue: computation.taxableValue,
          cgstAmount: computation.cgstTotal,
          sgstAmount: computation.sgstTotal,
          igstAmount: computation.igstTotal,
          totalTax: computation.totalTax,
          taxType: computation.taxType,
          gstRatesUsed: computation.lines,
          customerState: state,
          customerCountry: country,
          customerGSTIN: null,
          refundedAmount,
          refundedTax,
          refundStatus,
          createdAt,
          items: {
            create: lineMeta.map((meta, i) => {
              const line = computation.lines[i];
              return {
                productId: meta.productId,
                quantity: meta.quantity,
                unitPrice: meta.unitPrice,
                hsnCode: line.hsnCode,
                gstRate: line.gstRate,
                taxableValue: line.taxableValue,
                cgstAmount: line.cgstAmount,
                sgstAmount: line.sgstAmount,
                igstAmount: line.igstAmount,
              };
            }),
          },
        },
      });

      // Real invoice number + backdated PDF, same as a live checkout would generate on payment.
      const { invoiceNumber } = await allocateInvoiceNumber();
      await prisma.order.update({ where: { id: order.id }, data: { invoiceNumber, invoiceDate: createdAt } });
      await generateInvoicePdf(order.id);

      imported++;
    } catch (err) {
      skipped++;
      errors.push(`${orderName}: ${err instanceof Error ? err.message : String(err)}`);
    }
  }

  return { imported, skipped, errors };
}
