import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

// Meta/Google-compatible product feed (RSS 2.0 + Google Shopping namespace),
// used to feed Meta's "New Catalog" for catalog/dynamic ads. Kept as a
// separate route (not tied into sitemap.ts) since it has a different
// consumer and schema entirely.
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://glamgalore.in';

function escapeXml(value: string) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function absoluteImageUrl(url?: string | null): string | null {
  if (!url) return null;
  return url.startsWith('http') ? url : `${SITE_URL}${url}`;
}

export async function GET() {
  const products = await prisma.product.findMany({
    where: { status: 'active' },
    include: { images: { orderBy: { position: 'asc' }, take: 1 } },
  });

  const items = products
    .filter((p) => p.price)
    .map((p) => {
      const price = Number(p.price).toFixed(2);
      const availability = p.isOutOfStock ? 'out of stock' : 'in stock';
      const image = absoluteImageUrl(p.images[0]?.url);
      const link = `${SITE_URL}/products/${p.handle}`;
      const description = p.description || p.title;

      return `
  <item>
    <g:id>${escapeXml(p.id)}</g:id>
    <title>${escapeXml(p.title)}</title>
    <description>${escapeXml(description)}</description>
    <link>${escapeXml(link)}</link>
    ${image ? `<g:image_link>${escapeXml(image)}</g:image_link>` : ''}
    <g:availability>${availability}</g:availability>
    <g:condition>new</g:condition>
    <g:price>${price} INR</g:price>
    <g:brand>Glam Galore</g:brand>
    <g:product_type>Apparel</g:product_type>
  </item>`;
    })
    .join('');

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">
<channel>
  <title>Glam Galore Product Feed</title>
  <link>${SITE_URL}</link>
  <description>Glam Galore product catalog feed</description>${items}
</channel>
</rss>`;

  return new NextResponse(xml, {
    headers: { 'Content-Type': 'application/xml; charset=utf-8' },
  });
}
