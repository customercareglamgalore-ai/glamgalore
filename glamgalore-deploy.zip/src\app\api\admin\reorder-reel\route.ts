import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(req: NextRequest) {
  const { reelId, direction } = await req.json();
  if (!reelId || (direction !== 'up' && direction !== 'down')) {
    return NextResponse.json({ error: 'reelId and direction ("up" | "down") are required' }, { status: 400 });
  }

  const all = await prisma.reel.findMany({ orderBy: { position: 'asc' }, select: { id: true, position: true } });
  const index = all.findIndex((r) => r.id === reelId);
  if (index === -1) return NextResponse.json({ error: 'Reel not found' }, { status: 404 });

  const swapIndex = direction === 'up' ? index - 1 : index + 1;
  if (swapIndex < 0 || swapIndex >= all.length) {
    return NextResponse.json({ ok: true }); // already at the boundary, nothing to do
  }

  const current = all[index];
  const neighbor = all[swapIndex];

  await prisma.$transaction([
    prisma.reel.update({ where: { id: current.id }, data: { position: neighbor.position } }),
    prisma.reel.update({ where: { id: neighbor.id }, data: { position: current.position } }),
  ]);

  return NextResponse.json({ ok: true });
}
