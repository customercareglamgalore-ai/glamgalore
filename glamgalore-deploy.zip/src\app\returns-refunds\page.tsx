import Reveal from '@/components/Reveal';

export const metadata = {
  title: 'Returns & Refunds — Glam Galore',
  description: 'Our return, exchange, cancellation, and refund policy.',
};

export default function ReturnsRefundsPage() {
  return (
    <main className="blog-post-page">
      <Reveal className="container blog-post-container">
        <h1>Returns &amp; Refunds</h1>
        <div className="blog-post-body">
          <h2>Return Policy</h2>
          <p>To be eligible for a return/exchange:</p>
          <ul>
            <li>
              A query must be raised with our customer care executives within 72 hours from the date of
              delivery by mailing us at <a href="mailto:support@glamgalore.in">support@glamgalore.in</a>.
            </li>
            <li>Kindly upload clear images of the products with the labels/tags intact.</li>
            <li>The items must have all their labels/tags intact.</li>
            <li>The items must be in perfect condition, the same as they were when shipped by us.</li>
            <li>
              The items must be returned in the same packaging material that they were sent in, along with
              the invoice of the same.
            </li>
            <li>
              You are more than welcome to try on a product but please take all suitable measures to
              preserve its original condition, tags, labels and packaging.
            </li>
            <li>
              Keeping the strict hygiene standards of our products, we do not accept returns/replacement on
              several product categories like playsuits, swimwear, bags &amp; accessories, embellished
              dresses and denim since they are made on demand.
            </li>
            <li>
              We reserve the right not to accept return of products which (i) we believe are being returned
              after use, washed or soiled, or (ii) are damaged (except where the return is on account of
              damaged goods having been delivered to you).
            </li>
          </ul>

          <h2>To Do a Return</h2>
          <p>
            To initiate the return process, please mail us at{' '}
            <a href="mailto:support@glamgalore.in">support@glamgalore.in</a> stating the reason along with
            images of the item you wish to return, to ensure that the tags are intact.
          </p>
          <p>
            All queries will be resolved between Monday–Friday, 10am–6pm. Any pending queries will be
            resolved on priority the next day.
          </p>
          <p>Any return request via Instagram DMs or WhatsApp is not valid.</p>
          <p>
            If the return is eligible, we will schedule a return pickup for the same. Kindly note that a
            return pickup can only be scheduled and attempted once.
          </p>

          <h2>Order Cancellation</h2>
          <p>Orders can be cancelled only if they have not yet been processed, subject to cancellation charges.</p>

          <h2>Delivery Delay</h2>
          <p>
            Delivery times and dates mentioned are approximate estimates. We will make every reasonable
            effort to deliver the products within the specified time, but we cannot accept liability for any
            delays.
          </p>

          <h2>Refunds</h2>
          <p>
            It takes us 2–3 business days to process your return once it reaches our warehouse. You will
            receive a refund confirmation email once your refund is issued by us.
          </p>
          <p>
            Refunds can take several business days to reflect. A return pickup cost of ₹249 will be deducted
            from your refund. Normally, it takes about 5–7 business days to process a refund.
          </p>
          <p>You may not be eligible for a refund if any of the following apply:</p>
          <ul>
            <li>Failure to provide adequate information about the case.</li>
            <li>Failure to provide snapshots of the packet and box (if any).</li>
            <li>If a pilferage delivery was received, the claim must be made the same day.</li>
            <li>
              The packaging must not be disposed of — we might need to pick it up for investigation on our
              end.
            </li>
            <li>If the products are returned in poor condition or have clearly been worn, a refund would not be provided.</li>
          </ul>
          <p>
            Refunds cannot be initiated if the issue arises from your actions, such as typos, incorrect or
            incomplete address details, or an incorrect recipient contact number. However, we will resend the
            package to you at an additional reshipment fee.
          </p>
        </div>
      </Reveal>
    </main>
  );
}
