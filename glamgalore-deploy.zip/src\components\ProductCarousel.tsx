'use client';

import { useRef, useState } from 'react';
import ProductCard from './ProductCard';

type CarouselProduct = {
  handle: string;
  title: string;
  price: number | string;
  compareAtPrice?: number | string | null;
  images: string[];
  isOutOfStock?: boolean;
};

export default function ProductCarousel({ products }: { products: CarouselProduct[] }) {
  const trackRef = useRef<HTMLDivElement>(null);
  const [index, setIndex] = useState(0);

  function scrollByCard(direction: 1 | -1) {
    const track = trackRef.current;
    if (!track) return;
    const card = track.querySelector('.product-carousel-item') as HTMLElement | null;
    const amount = card ? card.offsetWidth + 24 : 260;
    track.scrollBy({ left: amount * direction, behavior: 'smooth' });
  }

  function handleScroll() {
    const track = trackRef.current;
    if (!track) return;
    const card = track.querySelector('.product-carousel-item') as HTMLElement | null;
    if (!card) return;
    const cardWidth = card.offsetWidth + 24;
    const newIndex = Math.round(track.scrollLeft / cardWidth);
    setIndex(Math.max(0, Math.min(newIndex, products.length - 1)));
  }

  return (
    <div className="product-carousel">
      <div className="product-carousel-track" ref={trackRef} onScroll={handleScroll}>
        {products.map((p) => (
          <div className="product-carousel-item" key={p.handle}>
            <ProductCard product={p} />
          </div>
        ))}
      </div>
      <div className="product-carousel-nav">
        <button type="button" aria-label="Previous product" onClick={() => scrollByCard(-1)}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
            <polyline points="15 6 9 12 15 18" />
          </svg>
        </button>
        <span className="product-carousel-counter">{index + 1}/{products.length}</span>
        <button type="button" aria-label="Next product" onClick={() => scrollByCard(1)}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
            <polyline points="9 6 15 12 9 18" />
          </svg>
        </button>
      </div>
    </div>
  );
}
