import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const INBOX_DIR = path.join(process.cwd(), 'public', 'reels-inbox');

export async function GET() {
  if (!fs.existsSync(INBOX_DIR)) return NextResponse.json({ files: [] });

  const files = fs
    .readdirSync(INBOX_DIR)
    .filter((f) => /\.(mp4|mov|webm)$/i.test(f))
    .sort();

  return NextResponse.json({ files });
}
