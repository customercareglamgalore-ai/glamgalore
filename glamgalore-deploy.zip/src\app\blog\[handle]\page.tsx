import { prisma } from '@/lib/db';
import { notFound } from 'next/navigation';
import Reveal from '@/components/Reveal';

export async function generateMetadata({ params }: { params: Promise<{ handle: string }> }) {
  const { handle } = await params;
  const post = await prisma.blogPost.findUnique({ where: { handle } });
  return { title: post ? `${post.title} — Glam Galore` : 'Glam Galore' };
}

export default async function BlogPostPage({ params }: { params: Promise<{ handle: string }> }) {
  const { handle } = await params;
  const post = await prisma.blogPost.findUnique({ where: { handle } });

  if (!post) notFound();

  return (
    <main className="blog-post-page">
      <Reveal className="container blog-post-container">
        {post.imageUrl && (
          <div className="blog-post-hero">
            <img src={post.imageUrl} alt={post.title} />
          </div>
        )}
        <h1>{post.title}</h1>
        {post.author && <p className="blog-post-author">By {post.author}</p>}
        <div className="blog-post-body" dangerouslySetInnerHTML={{ __html: post.bodyHtml }} />
      </Reveal>
    </main>
  );
}
