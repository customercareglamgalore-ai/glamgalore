'use client';

import { useEffect, useState } from 'react';

type Settings = {
  businessLegalName: string;
  businessGSTIN: string | null;
  businessAddressLine1: string | null;
  businessAddressLine2: string | null;
  businessCity: string | null;
  businessState: string;
  businessPincode: string | null;
  defaultGstRate: string;
  pricesIncludeTax: boolean;
  chargeTaxOnInternational: boolean;
  useApparelPriceSlabs: boolean;
  apparelSlabThreshold: string;
  apparelSlabRateBelow: string;
  apparelSlabRateAbove: string;
  invoicePrefix: string;
  invoiceNumberPadding: number;
  nextInvoiceSequence: number;
  currencyRates: Record<string, string | number>;
  siteLocked: boolean;
  sitePassword: string | null;
};

type TaxRule = { id: string; category: string; gstRate: string; hsnCode: string | null };

type ProductRow = {
  id: string;
  handle: string;
  title: string;
  type: string | null;
  price: string | null;
  hsnCode: string | null;
  gstRateOverride: string | null;
};

const inputStyle: React.CSSProperties = { padding: 8, border: '1px solid #ccc', fontSize: 13, width: '100%' };
const labelStyle: React.CSSProperties = { display: 'block', fontSize: 12, color: '#666', marginBottom: 4, marginTop: 12 };
const sectionStyle: React.CSSProperties = { marginTop: 40, borderTop: '1px solid #eee', paddingTop: 20 };
const btnStyle: React.CSSProperties = { padding: '8px 16px', background: '#000', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 13 };

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const [rules, setRules] = useState<TaxRule[]>([]);
  const [newRule, setNewRule] = useState({ category: '', gstRate: '', hsnCode: '' });

  const [query, setQuery] = useState('');
  const [products, setProducts] = useState<ProductRow[]>([]);

  function refreshSettings() {
    fetch('/api/admin/settings')
      .then((r) => r.json())
      .then((data) => setSettings(data.settings));
  }

  function refreshRules() {
    fetch('/api/admin/tax-rules')
      .then((r) => r.json())
      .then((data) => setRules(data.rules));
  }

  function refreshProducts(q: string) {
    fetch(`/api/admin/products/search?q=${encodeURIComponent(q)}`)
      .then((r) => r.json())
      .then((data) => setProducts(data.products));
  }

  useEffect(() => {
    refreshSettings();
    refreshRules();
    refreshProducts('');
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => refreshProducts(query), 250);
    return () => clearTimeout(timer);
  }, [query]);

  async function saveSettings() {
    if (!settings) return;
    setSaving(true);
    const res = await fetch('/api/admin/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    setSaving(false);
    setMessage(res.ok ? 'Settings saved' : 'Error saving settings');
  }

  async function addRule() {
    if (!newRule.category || !newRule.gstRate) return;
    await fetch('/api/admin/tax-rules', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newRule),
    });
    setNewRule({ category: '', gstRate: '', hsnCode: '' });
    refreshRules();
  }

  async function deleteRule(id: string) {
    await fetch('/api/admin/tax-rules', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    refreshRules();
  }

  async function updateProductTax(id: string, hsnCode: string, gstRateOverride: string) {
    setProducts((rows) => rows.map((p) => (p.id === id ? { ...p, hsnCode, gstRateOverride } : p)));
    await fetch(`/api/admin/products/${id}/tax`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ hsnCode, gstRateOverride: gstRateOverride === '' ? null : Number(gstRateOverride) }),
    });
  }

  function setRates(currency: string, value: string) {
    setSettings((s) => (s ? { ...s, currencyRates: { ...s.currencyRates, [currency]: value } } : s));
  }

  if (!settings) return <main style={{ padding: 40 }}>Loading...</main>;

  return (
    <main style={{ padding: 40, maxWidth: 720, margin: '0 auto', fontFamily: 'system-ui' }}>
      <h1 style={{ fontSize: 20 }}>Tax &amp; Invoicing Settings</h1>

      <h2 style={{ fontSize: 15, marginTop: 24 }}>Business info</h2>
      <label style={labelStyle}>Legal business name</label>
      <input style={inputStyle} value={settings.businessLegalName} onChange={(e) => setSettings({ ...settings, businessLegalName: e.target.value })} />
      <label style={labelStyle}>GSTIN</label>
      <input style={inputStyle} value={settings.businessGSTIN || ''} onChange={(e) => setSettings({ ...settings, businessGSTIN: e.target.value })} />
      <label style={labelStyle}>Address line 1</label>
      <input style={inputStyle} value={settings.businessAddressLine1 || ''} onChange={(e) => setSettings({ ...settings, businessAddressLine1: e.target.value })} />
      <label style={labelStyle}>Address line 2</label>
      <input style={inputStyle} value={settings.businessAddressLine2 || ''} onChange={(e) => setSettings({ ...settings, businessAddressLine2: e.target.value })} />
      <div style={{ display: 'flex', gap: 12 }}>
        <div style={{ flex: 1 }}>
          <label style={labelStyle}>City</label>
          <input style={inputStyle} value={settings.businessCity || ''} onChange={(e) => setSettings({ ...settings, businessCity: e.target.value })} />
        </div>
        <div style={{ flex: 1 }}>
          <label style={labelStyle}>Home state (for CGST/SGST vs IGST)</label>
          <input style={inputStyle} value={settings.businessState} onChange={(e) => setSettings({ ...settings, businessState: e.target.value })} />
        </div>
        <div style={{ flex: 1 }}>
          <label style={labelStyle}>Pincode</label>
          <input style={inputStyle} value={settings.businessPincode || ''} onChange={(e) => setSettings({ ...settings, businessPincode: e.target.value })} />
        </div>
      </div>

      <h2 style={{ fontSize: 15, marginTop: 24 }}>GST configuration</h2>
      <label style={labelStyle}>Default GST rate % (fallback when no category/apparel rule applies)</label>
      <input style={inputStyle} type="number" step="0.01" value={settings.defaultGstRate} onChange={(e) => setSettings({ ...settings, defaultGstRate: e.target.value })} />

      <label style={{ ...labelStyle, display: 'flex', alignItems: 'center', gap: 6 }}>
        <input type="checkbox" checked={settings.pricesIncludeTax} onChange={(e) => setSettings({ ...settings, pricesIncludeTax: e.target.checked })} />
        Product prices are tax-inclusive (back-calculate GST from the sticker price)
      </label>

      <label style={{ ...labelStyle, display: 'flex', alignItems: 'center', gap: 6 }}>
        <input type="checkbox" checked={settings.chargeTaxOnInternational} onChange={(e) => setSettings({ ...settings, chargeTaxOnInternational: e.target.checked })} />
        Charge tax on international orders (off = zero-rated export, no GST)
      </label>

      <label style={{ ...labelStyle, display: 'flex', alignItems: 'center', gap: 6 }}>
        <input type="checkbox" checked={settings.useApparelPriceSlabs} onChange={(e) => setSettings({ ...settings, useApparelPriceSlabs: e.target.checked })} />
        Use apparel price-slab GST (current Indian rule: lower rate below a price threshold, higher above)
      </label>

      {settings.useApparelPriceSlabs && (
        <div style={{ display: 'flex', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <label style={labelStyle}>Threshold (₹ per item)</label>
            <input style={inputStyle} type="number" value={settings.apparelSlabThreshold} onChange={(e) => setSettings({ ...settings, apparelSlabThreshold: e.target.value })} />
          </div>
          <div style={{ flex: 1 }}>
            <label style={labelStyle}>Rate % at/below threshold</label>
            <input style={inputStyle} type="number" step="0.01" value={settings.apparelSlabRateBelow} onChange={(e) => setSettings({ ...settings, apparelSlabRateBelow: e.target.value })} />
          </div>
          <div style={{ flex: 1 }}>
            <label style={labelStyle}>Rate % above threshold</label>
            <input style={inputStyle} type="number" step="0.01" value={settings.apparelSlabRateAbove} onChange={(e) => setSettings({ ...settings, apparelSlabRateAbove: e.target.value })} />
          </div>
        </div>
      )}
      <p style={{ fontSize: 11, color: '#999', marginTop: 4 }}>Confirm exact GST slab figures with your CA — these are defaults, not tax advice.</p>

      <h2 style={{ fontSize: 15, marginTop: 24 }}>Invoice numbering</h2>
      <div style={{ display: 'flex', gap: 12 }}>
        <div style={{ flex: 1 }}>
          <label style={labelStyle}>Prefix</label>
          <input style={inputStyle} value={settings.invoicePrefix} onChange={(e) => setSettings({ ...settings, invoicePrefix: e.target.value })} />
        </div>
        <div style={{ flex: 1 }}>
          <label style={labelStyle}>Zero-padding digits</label>
          <input style={inputStyle} type="number" value={settings.invoiceNumberPadding} onChange={(e) => setSettings({ ...settings, invoiceNumberPadding: Number(e.target.value) })} />
        </div>
        <div style={{ flex: 1 }}>
          <label style={labelStyle}>Next sequence number</label>
          <input style={{ ...inputStyle, background: '#f5f5f5' }} value={settings.nextInvoiceSequence} disabled />
        </div>
      </div>
      <p style={{ fontSize: 11, color: '#999', marginTop: 4 }}>
        Preview: {settings.invoicePrefix}{String(settings.nextInvoiceSequence).padStart(settings.invoiceNumberPadding, '0')}
      </p>

      <h2 style={{ fontSize: 15, marginTop: 24 }}>Currency rates (INR → foreign currency, for international checkout)</h2>
      {['USD', 'GBP', 'EUR', 'AUD', 'CAD'].map((c) => (
        <div key={c} style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
          <span style={{ width: 50, fontSize: 13 }}>{c}</span>
          <input
            style={inputStyle}
            type="number"
            step="0.0001"
            placeholder={`1 INR = ? ${c}`}
            value={settings.currencyRates[c] ?? ''}
            onChange={(e) => setRates(c, e.target.value)}
          />
        </div>
      ))}

      <h2 style={{ fontSize: 15, marginTop: 24 }}>Site access</h2>
      <label style={{ ...labelStyle, display: 'flex', alignItems: 'center', gap: 6 }}>
        <input type="checkbox" checked={settings.siteLocked} onChange={(e) => setSettings({ ...settings, siteLocked: e.target.checked })} />
        Password-protect the site from visitors (search/social crawlers still get through)
      </label>
      {settings.siteLocked && (
        <>
          <label style={labelStyle}>Site password</label>
          <input style={inputStyle} value={settings.sitePassword || ''} onChange={(e) => setSettings({ ...settings, sitePassword: e.target.value })} placeholder="Set a password" />
        </>
      )}

      <div style={{ marginTop: 24 }}>
        <button style={btnStyle} onClick={saveSettings} disabled={saving}>
          {saving ? 'Saving...' : 'Save settings'}
        </button>
        {message && <span style={{ marginLeft: 12, fontSize: 13, color: '#666' }}>{message}</span>}
      </div>

      <div style={sectionStyle}>
        <h2 style={{ fontSize: 15 }}>Tax rules by category</h2>
        <p style={{ fontSize: 12, color: '#999' }}>Category matches a product&apos;s Type field. Overrides the apparel slab / default rate.</p>
        {rules.map((r) => (
          <div key={r.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', borderBottom: '1px solid #f3f3f3', fontSize: 13 }}>
            <span style={{ flex: 1 }}>{r.category}</span>
            <span style={{ width: 60 }}>{r.gstRate}%</span>
            <span style={{ width: 80, color: '#999' }}>{r.hsnCode || '—'}</span>
            <button onClick={() => deleteRule(r.id)} style={{ border: 'none', background: '#eee', padding: '4px 10px', cursor: 'pointer', fontSize: 12 }}>
              Delete
            </button>
          </div>
        ))}
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <input style={inputStyle} placeholder="Category (Product Type)" value={newRule.category} onChange={(e) => setNewRule({ ...newRule, category: e.target.value })} />
          <input style={inputStyle} placeholder="GST %" type="number" value={newRule.gstRate} onChange={(e) => setNewRule({ ...newRule, gstRate: e.target.value })} />
          <input style={inputStyle} placeholder="HSN code" value={newRule.hsnCode} onChange={(e) => setNewRule({ ...newRule, hsnCode: e.target.value })} />
          <button style={btnStyle} onClick={addRule}>Add</button>
        </div>
      </div>

      <div style={sectionStyle}>
        <h2 style={{ fontSize: 15 }}>Per-product HSN / GST rate override</h2>
        <input
          style={{ ...inputStyle, marginTop: 8 }}
          placeholder="Search products by title..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        {products.map((p) => (
          <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', borderBottom: '1px solid #f3f3f3', fontSize: 13 }}>
            <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.title}</span>
            <span style={{ width: 60, color: '#999' }}>₹{p.price}</span>
            <input
              style={{ ...inputStyle, width: 90 }}
              placeholder="HSN"
              defaultValue={p.hsnCode || ''}
              onBlur={(e) => updateProductTax(p.id, e.target.value, p.gstRateOverride || '')}
            />
            <input
              style={{ ...inputStyle, width: 70 }}
              placeholder="GST %"
              type="number"
              defaultValue={p.gstRateOverride || ''}
              onBlur={(e) => updateProductTax(p.id, p.hsnCode || '', e.target.value)}
            />
          </div>
        ))}
      </div>
    </main>
  );
}
