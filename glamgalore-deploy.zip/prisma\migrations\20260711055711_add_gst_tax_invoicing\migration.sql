-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "cgstAmount" DECIMAL(10,2) NOT NULL DEFAULT 0,
ADD COLUMN     "currency" TEXT NOT NULL DEFAULT 'INR',
ADD COLUMN     "customerCountry" TEXT NOT NULL DEFAULT 'India',
ADD COLUMN     "customerGSTIN" TEXT,
ADD COLUMN     "customerState" TEXT,
ADD COLUMN     "discountAmount" DECIMAL(10,2) NOT NULL DEFAULT 0,
ADD COLUMN     "fxRateApplied" DECIMAL(12,6),
ADD COLUMN     "gstRatesUsed" JSONB,
ADD COLUMN     "igstAmount" DECIMAL(10,2) NOT NULL DEFAULT 0,
ADD COLUMN     "invoiceDate" TIMESTAMP(3),
ADD COLUMN     "invoiceNumber" TEXT,
ADD COLUMN     "invoicePdfPath" TEXT,
ADD COLUMN     "refundStatus" TEXT NOT NULL DEFAULT 'none',
ADD COLUMN     "refundedAmount" DECIMAL(10,2) NOT NULL DEFAULT 0,
ADD COLUMN     "refundedTax" DECIMAL(10,2) NOT NULL DEFAULT 0,
ADD COLUMN     "sgstAmount" DECIMAL(10,2) NOT NULL DEFAULT 0,
ADD COLUMN     "taxType" TEXT NOT NULL DEFAULT 'none',
ADD COLUMN     "taxableValue" DECIMAL(10,2) NOT NULL DEFAULT 0,
ADD COLUMN     "totalTax" DECIMAL(10,2) NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "OrderItem" ADD COLUMN     "cgstAmount" DECIMAL(10,2),
ADD COLUMN     "gstRate" DECIMAL(5,2),
ADD COLUMN     "hsnCode" TEXT,
ADD COLUMN     "igstAmount" DECIMAL(10,2),
ADD COLUMN     "sgstAmount" DECIMAL(10,2),
ADD COLUMN     "taxableValue" DECIMAL(10,2);

-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "gstRateOverride" DECIMAL(5,2),
ADD COLUMN     "hsnCode" TEXT;

-- CreateTable
CREATE TABLE "StoreSettings" (
    "id" TEXT NOT NULL DEFAULT 'singleton',
    "businessLegalName" TEXT NOT NULL DEFAULT 'Glam Galore',
    "businessGSTIN" TEXT,
    "businessAddressLine1" TEXT,
    "businessAddressLine2" TEXT,
    "businessCity" TEXT,
    "businessState" TEXT NOT NULL DEFAULT 'Delhi',
    "businessPincode" TEXT,
    "defaultGstRate" DECIMAL(5,2) NOT NULL DEFAULT 12.00,
    "pricesIncludeTax" BOOLEAN NOT NULL DEFAULT false,
    "chargeTaxOnInternational" BOOLEAN NOT NULL DEFAULT false,
    "useApparelPriceSlabs" BOOLEAN NOT NULL DEFAULT true,
    "apparelSlabThreshold" DECIMAL(10,2) NOT NULL DEFAULT 2500,
    "apparelSlabRateBelow" DECIMAL(5,2) NOT NULL DEFAULT 5,
    "apparelSlabRateAbove" DECIMAL(5,2) NOT NULL DEFAULT 18,
    "invoicePrefix" TEXT NOT NULL DEFAULT 'GG-',
    "invoiceNumberPadding" INTEGER NOT NULL DEFAULT 6,
    "nextInvoiceSequence" INTEGER NOT NULL DEFAULT 1,
    "currencyRates" JSONB NOT NULL DEFAULT '{}',
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "StoreSettings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TaxRule" (
    "id" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "gstRate" DECIMAL(5,2) NOT NULL,
    "hsnCode" TEXT,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TaxRule_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "TaxRule_category_key" ON "TaxRule"("category");

-- CreateIndex
CREATE UNIQUE INDEX "Order_invoiceNumber_key" ON "Order"("invoiceNumber");

