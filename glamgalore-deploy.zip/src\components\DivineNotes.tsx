'use client';

import { useEffect, useRef, useState } from 'react';
import { DIVINE_NOTE_AFFIRMATIONS, FLOAT_PLACEMENTS } from '@/lib/divine-notes';
import { spotlight } from '@/lib/spotlight';

type Note = { key: number; text: string; style: React.CSSProperties };

function pickNext<T>(pool: T[], lastIndex: number): [T, number] {
  if (pool.length === 1) return [pool[0], 0];
  let index = Math.floor(Math.random() * pool.length);
  if (index === lastIndex) index = (index + 1) % pool.length;
  return [pool[index], index];
}

export default function DivineNotes() {
  const [note, setNote] = useState<Note | null>(null);
  const lastTextIndex = useRef(-1);
  const lastPlacementIndex = useRef(-1);
  const counterRef = useRef(0);

  useEffect(() => {
    return spotlight.subscribe((active) => {
      if (active !== 'affirmation') {
        setNote(null);
        return;
      }
      const [text, textIndex] = pickNext(DIVINE_NOTE_AFFIRMATIONS, lastTextIndex.current);
      const [style, placementIndex] = pickNext(FLOAT_PLACEMENTS, lastPlacementIndex.current);
      lastTextIndex.current = textIndex;
      lastPlacementIndex.current = placementIndex;
      counterRef.current += 1;
      setNote({ key: counterRef.current, text, style });
    });
  }, []);

  if (!note) return null;

  return (
    <p aria-hidden="true" className="divine-note" style={note.style} key={note.key}>
      {note.text}
    </p>
  );
}
