// Static country -> currency mapping, used by the checkout country selector
// and (in a later phase) real multi-currency charging for international orders.
export const COUNTRY_TO_CURRENCY: Record<string, string> = {
  India: 'INR',
  'United States': 'USD',
  'United Kingdom': 'GBP',
  Canada: 'CAD',
  Australia: 'AUD',
  Germany: 'EUR',
  France: 'EUR',
  Ireland: 'EUR',
  Netherlands: 'EUR',
  Spain: 'EUR',
  Italy: 'EUR',
  Singapore: 'SGD',
  'United Arab Emirates': 'AED',
};

export const CHECKOUT_COUNTRIES = Object.keys(COUNTRY_TO_CURRENCY);

// ISO 3166-1 alpha-2 codes, used for CJ Dropshipping order submission.
export const COUNTRY_TO_ISO_CODE: Record<string, string> = {
  India: 'IN',
  'United States': 'US',
  'United Kingdom': 'GB',
  Canada: 'CA',
  Australia: 'AU',
  Germany: 'DE',
  France: 'FR',
  Ireland: 'IE',
  Netherlands: 'NL',
  Spain: 'ES',
  Italy: 'IT',
  Singapore: 'SG',
  'United Arab Emirates': 'AE',
};

export const CURRENCY_DECIMALS: Record<string, number> = {
  INR: 2, USD: 2, GBP: 2, EUR: 2, CAD: 2, AUD: 2, SGD: 2, AED: 2, JPY: 0,
};

export function currencyForCountry(country: string): string {
  return COUNTRY_TO_CURRENCY[country] ?? 'USD';
}
