import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q')?.trim() || '';
  if (!q) return NextResponse.json({ products: [] });

  const products = await prisma.product.findMany({
    where: { status: 'active', title: { contains: q, mode: 'insensitive' } },
    include: { images: { take: 4, orderBy: { position: 'asc' } } },
    orderBy: { createdAt: 'desc' },
    take: 40,
  });

  return NextResponse.json({
    products: products.map((p) => ({
      handle: p.handle,
      title: p.title,
      price: p.price?.toString() || '',
      compareAtPrice: p.compareAtPrice?.toString(),
      images: p.images.map((img) => img.url),
      isOutOfStock: p.isOutOfStock,
    })),
  });
}
