// Imports data/reviews.json into Postgres, linking each review to its
// product by handle. Run this AFTER scripts/import-products.js so the
// products already exist to link against.
//
// Usage: DATABASE_URL=postgres://... node scripts/import-reviews.js

const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();

async function main() {
  const raw = fs.readFileSync(path.join(__dirname, '../data/reviews.json'), 'utf-8');
  const reviews = JSON.parse(raw);

  console.log(`Importing ${reviews.length} reviews...`);

  let created = 0;
  let skipped = 0;

  for (const r of reviews) {
    const product = await prisma.product.findUnique({ where: { handle: r.product_handle } });
    if (!product) {
      skipped++;
      continue;
    }

    await prisma.review.create({
      data: {
        productId: product.id,
        authorName: r.author_name || 'Anonymous',
        rating: Math.round(r.rating) || 5,
        title: r.title,
        body: r.body || '',
        imageUrls: r.image_urls || [],
        verified: r.verified || false,
        source: r.source,
        createdAt: r.created_at ? new Date(r.created_at) : new Date(),
      },
    });
    created++;
  }

  console.log(`Done. Created: ${created}. Skipped (product not found): ${skipped}.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
