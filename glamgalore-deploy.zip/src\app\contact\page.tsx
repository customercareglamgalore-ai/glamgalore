import Reveal from '@/components/Reveal';
import ContactForm from '@/components/ContactForm';

export const metadata = {
  title: 'Contact — Glam Galore',
  description: 'Get in touch with Glam Galore over email or WhatsApp for order queries and support.',
};

export default function ContactPage() {
  return (
    <main className="container" style={{ maxWidth: 560, margin: '0 auto' }}>
      <Reveal>
        <h1 className="section-heading">Contact</h1>

        <p>
          For any queries or support, please reach out to us only through <strong>Email</strong> or{' '}
          <strong>WhatsApp</strong>.
        </p>
        <p>We kindly request you not to send messages via Instagram DMs, as they may get missed.</p>
        <p>Thank you for understanding!</p>

        <h2 style={{ marginTop: 32 }}>Connect to Us:</h2>
        <ul>
          <li>
            Email: <a href="mailto:Support@glamgalore.in">Support@glamgalore.in</a>
          </li>
          <li>WhatsApp: <a href="https://wa.me/919769708781">9769708781</a></li>
        </ul>

        <div style={{ marginTop: 32 }}>
          <ContactForm />
        </div>
      </Reveal>
    </main>
  );
}
