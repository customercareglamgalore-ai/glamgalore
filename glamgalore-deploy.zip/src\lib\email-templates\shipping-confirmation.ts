import type { Order, OrderItem, Product, ProductImage, ProductVariant } from '@prisma/client';

type OrderWithItems = Order & {
  items: (OrderItem & { product: Product & { images: ProductImage[] }; variant: ProductVariant | null })[];
};

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://glamgalore.in';
const FONT = "-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif";

function absoluteImageUrl(url?: string | null): string | null {
  if (!url) return null;
  return url.startsWith('http') ? url : `${SITE_URL}${url}`;
}

export function buildShippingConfirmationEmail(
  order: OrderWithItems,
  trackingNumber: string,
): { subject: string; html: string; text: string } {
  const orderNumber = order.invoiceNumber ?? order.id;
  const subject = `A shipment from order #${orderNumber} is on the way`;

  const itemRows = order.items
    .map((item) => {
      const variantLabel = item.variant
        ? [item.variant.optionValue, item.variant.option2Value].filter(Boolean).join(' / ')
        : '';
      const imageUrl = absoluteImageUrl(item.product.images[0]?.url);
      return `
        <tr>
          <td style="padding:12px 0;border-bottom:1px solid #f0ede9;width:64px;">
            ${imageUrl ? `<img src="${imageUrl}" width="56" height="70" style="object-fit:cover;border-radius:6px;display:block;" alt="">` : ''}
          </td>
          <td style="padding:12px 0 12px 14px;border-bottom:1px solid #f0ede9;vertical-align:top;">
            <div style="font-size:14px;font-weight:600;color:#201a16;">${item.product.title} &times; ${item.quantity}</div>
            ${variantLabel ? `<div style="font-size:12px;color:#888;margin-top:2px;">${variantLabel}</div>` : ''}
          </td>
        </tr>`;
    })
    .join('');

  const html = `
  <div style="max-width:560px;margin:0 auto;font-family:${FONT};color:#201a16;">
    <div style="display:flex;justify-content:space-between;align-items:center;padding:28px 0;border-bottom:1px solid #f0ede9;">
      <div style="font-family:Georgia,'Times New Roman',serif;font-size:24px;letter-spacing:0.03em;">Glam Galore</div>
      <div style="font-size:12px;color:#999;letter-spacing:0.03em;">ORDER #${orderNumber}</div>
    </div>

    <div style="padding:28px 0 20px;">
      <h1 style="font-size:21px;margin:0 0 10px;font-weight:600;">Happiness is on its way!</h1>
      <p style="font-size:14px;color:#555;margin:0 0 16px;line-height:1.5;">
        Good news, we've just shipped your order. You can copy your tracking number below and enter it on our order tracking page to view your delivery status.
      </p>
      <p style="font-size:14px;font-weight:600;color:#201a16;margin:0 0 16px;">Tracking number: ${trackingNumber}</p>
      <p style="font-size:12px;color:#999;margin:0 0 20px;line-height:1.5;">
        If your tracking number isn't working yet, please wait 2–3 days and try again — in most cases your order is on the way, but the system information is delayed.
      </p>
      <a href="${SITE_URL}/track-order" style="display:inline-block;background:#201a16;color:#fff;padding:13px 28px;text-decoration:none;font-size:13px;letter-spacing:0.03em;text-transform:uppercase;">Track your order</a>
      <p style="font-size:13px;margin-top:14px;"><a href="${SITE_URL}" style="color:#777;">or Visit our store</a></p>
    </div>

    <h2 style="font-size:13px;text-transform:uppercase;letter-spacing:0.04em;color:#999;margin:0 0 4px;padding-bottom:10px;border-bottom:1px solid #f0ede9;">What's in this shipment</h2>
    <table style="width:100%;border-collapse:collapse;">
      ${itemRows}
    </table>

    <div style="text-align:center;padding:24px 0;margin-top:20px;border-top:1px solid #f0ede9;font-size:12px;color:#999;">
      If you have any questions, reply to this email or contact us at <a href="mailto:support@glamgalore.in" style="color:#c4322a;">support@glamgalore.in</a>
    </div>
  </div>`;

  const text = [
    `Happiness is on its way! Order #${orderNumber} has shipped.`,
    `Tracking number: ${trackingNumber}`,
    `Track your order: ${SITE_URL}/track-order`,
    '',
    ...order.items.map((i) => `${i.product.title} x${i.quantity}`),
    '',
    'If you have any questions, reply to this email or contact us at support@glamgalore.in',
  ].join('\n');

  return { subject, html, text };
}
