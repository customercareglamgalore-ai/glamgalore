type AccordionItem = { title: string; content: React.ReactNode };

export default function ProductAccordion({ items }: { items: AccordionItem[] }) {
  return (
    <div className="product-accordion">
      {items.map((item) => (
        <details key={item.title}>
          <summary>{item.title}</summary>
          <div className="accordion-content">{item.content}</div>
        </details>
      ))}
    </div>
  );
}
