'use client';

import { useEffect, useRef } from 'react';
import { trackMetaEvent } from './MetaPixel';

export default function PurchasePixel({
  orderId,
  value,
  currency,
  contentIds,
}: {
  orderId: string;
  value: number;
  currency: string;
  contentIds: string[];
}) {
  const fired = useRef(false);

  useEffect(() => {
    if (fired.current) return;
    fired.current = true;
    // eventId matches the one used server-side (src/lib/meta-capi.ts) so Meta
    // dedupes the browser pixel event against the Conversions API event.
    trackMetaEvent(
      'Purchase',
      { value, currency, content_ids: contentIds, content_type: 'product' },
      `purchase-${orderId}`
    );
  }, [orderId, value, currency, contentIds]);

  return null;
}
