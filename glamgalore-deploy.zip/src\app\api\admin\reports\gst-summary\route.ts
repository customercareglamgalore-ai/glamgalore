import { NextRequest, NextResponse } from 'next/server';
import { getGstSummary } from '@/lib/reports/gst-summary';

export async function GET(req: NextRequest) {
  const params = req.nextUrl.searchParams;
  const from = params.get('from') ? new Date(params.get('from')!) : new Date(0);
  const to = params.get('to') ? new Date(params.get('to')!) : new Date();

  const summary = await getGstSummary(from, to);
  return NextResponse.json(summary);
}
