export const metadata = {
  title: 'Checkout — Glam Galore',
  robots: { index: false, follow: false },
};

export default function CheckoutLayout({ children }: { children: React.ReactNode }) {
  return children;
}
