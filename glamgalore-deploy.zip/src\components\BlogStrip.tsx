'use client';

import Link from 'next/link';
import { useRef } from 'react';

type BlogPostCard = {
  handle: string;
  title: string;
  summary: string | null;
  imageUrl: string | null;
};

export default function BlogStrip({ posts }: { posts: BlogPostCard[] }) {
  const trackRef = useRef<HTMLDivElement>(null);

  function scrollByCard(direction: 1 | -1) {
    const track = trackRef.current;
    if (!track) return;
    const card = track.querySelector('.blog-card') as HTMLElement | null;
    const amount = card ? card.offsetWidth + 24 : 320;
    track.scrollBy({ left: amount * direction, behavior: 'smooth' });
  }

  return (
    <div className="blog-strip">
      <div className="blog-strip-track" ref={trackRef}>
        {posts.map((post) => (
          <Link key={post.handle} href={`/blog/${post.handle}`} className="blog-card">
            <div className="blog-card-image">
              {post.imageUrl && <img src={post.imageUrl} alt={post.title} loading="lazy" />}
            </div>
            <p className="blog-card-title">{post.title}</p>
            {post.summary && <p className="blog-card-summary">{post.summary}</p>}
          </Link>
        ))}
      </div>
      <div className="blog-strip-nav">
        <button type="button" aria-label="Previous post" onClick={() => scrollByCard(-1)}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
            <polyline points="15 6 9 12 15 18" />
          </svg>
        </button>
        <button type="button" aria-label="Next post" onClick={() => scrollByCard(1)}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
            <polyline points="9 6 15 12 9 18" />
          </svg>
        </button>
      </div>
    </div>
  );
}
