type Review = {
  id: string;
  authorName: string;
  rating: number;
  title?: string | null;
  body: string;
  imageUrls: string[];
  verified: boolean;
};

export default function ReviewList({ reviews }: { reviews: Review[] }) {
  if (reviews.length === 0) {
    return <p className="empty-state">No reviews yet — be the first to share yours.</p>;
  }

  return (
    <ul className="review-list">
      {reviews.map((r) => (
        <li key={r.id} className="review-card">
          <div className="review-header">
            <span className="stars">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</span>
            <strong>{r.authorName}</strong>
            {r.verified && <span className="verified-badge">Verified purchase</span>}
          </div>
          {r.title && <h4>{r.title}</h4>}
          <p>{r.body}</p>
          {r.imageUrls.length > 0 && (
            <div className="review-images">
              {r.imageUrls.map((url, i) => (
                <img key={i} src={url} alt="Customer photo" />
              ))}
            </div>
          )}
        </li>
      ))}
    </ul>
  );
}
