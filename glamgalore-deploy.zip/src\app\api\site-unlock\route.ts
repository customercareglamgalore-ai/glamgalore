import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { prisma } from '@/lib/db';

function unlockCookieValue(password: string): string {
  return crypto.createHash('sha256').update(`site-unlock:${password}`).digest('hex');
}

export async function POST(req: NextRequest) {
  const { password } = await req.json();
  const settings = await prisma.storeSettings.findUnique({
    where: { id: 'singleton' },
    select: { sitePassword: true },
  });

  if (!settings?.sitePassword || password !== settings.sitePassword) {
    return NextResponse.json({ error: 'Incorrect password' }, { status: 401 });
  }

  const res = NextResponse.json({ ok: true });
  res.cookies.set('site_unlock', unlockCookieValue(settings.sitePassword), {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 24 * 30, // 30 days
  });
  return res;
}
