export const metadata = {
  title: 'Your Account — Glam Galore',
  robots: { index: false, follow: false },
};

export default function AccountLayout({ children }: { children: React.ReactNode }) {
  return children;
}
