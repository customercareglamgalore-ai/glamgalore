// One-off: import the legacy Shopify discount-code export into the new
// DiscountCode table. Imported inactive by default — several of these are
// 100%-off or large fixed-amount codes that look like one-time
// influencer/personal codes, not codes meant to stay redeemable forever.
// Toggle individual codes on from /admin/discounts.
const { PrismaClient } = require('@prisma/client');
const discounts = require('../data/discounts.json');

const prisma = new PrismaClient();

async function main() {
  let created = 0;
  let skipped = 0;
  for (const d of discounts) {
    const code = String(d.code).trim().toUpperCase();
    const valueType = d.value_type === 'Percentage' ? 'percentage' : 'fixed';
    const existing = await prisma.discountCode.findUnique({ where: { code } });
    if (existing) {
      skipped++;
      continue;
    }
    await prisma.discountCode.create({
      data: { code, valueType, value: d.value, active: false },
    });
    created++;
  }
  console.log(`Imported ${created} legacy codes (inactive), skipped ${skipped} already present.`);
}

main().finally(() => prisma.$disconnect());
