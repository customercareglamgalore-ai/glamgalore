import { Suspense } from 'react';
import { prisma } from '@/lib/db';
import ProductCard from '@/components/ProductCard';
import { notFound } from 'next/navigation';
import { COLLECTION_TITLES } from '@/lib/collections';
import Reveal from '@/components/Reveal';
import CollectionControls from '@/components/CollectionControls';
import Pagination from '@/components/Pagination';
import ReelBubbles from '@/components/ReelBubbles';
import { getCuratedReelBubbles } from '@/lib/curated-reel-bubbles';
import type { Prisma } from '@prisma/client';

const PAGE_SIZE = 12;

export async function generateMetadata({ params }: { params: Promise<{ handle: string }> }) {
  const { handle } = await params;
  const title = COLLECTION_TITLES[handle] || handle.replace(/-/g, ' ');
  return { title: `${title} — Glam Galore` };
}

const SORT_ORDER_BY: Record<string, Prisma.ProductOrderByWithRelationInput> = {
  newest: { createdAt: 'desc' },
  oldest: { createdAt: 'asc' },
  az: { title: 'asc' },
  za: { title: 'desc' },
  'price-low': { price: 'asc' },
  'price-high': { price: 'desc' },
};

export default async function CollectionPage({
  params,
  searchParams,
}: {
  params: Promise<{ handle: string }>;
  searchParams: Promise<{ sort?: string; page?: string }>;
}) {
  const { handle } = await params;
  const { sort = 'newest', page: pageParam } = await searchParams;
  const page = Math.max(1, Number(pageParam) || 1);

  const where: Prisma.ProductWhereInput =
    handle === 'all'
      ? { status: 'active' }
      : { status: 'active', collections: { has: handle } };

  const [products, totalCount, curatedReelBubbles] = await Promise.all([
    prisma.product.findMany({
      where,
      include: { images: { orderBy: { position: 'asc' }, take: 4 } },
      orderBy: SORT_ORDER_BY[sort] || SORT_ORDER_BY.newest,
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
    }),
    prisma.product.count({ where }),
    getCuratedReelBubbles(),
  ]);

  if (totalCount === 0) notFound();

  const totalPages = Math.ceil(totalCount / PAGE_SIZE);

  return (
    <main className="container">
      <ReelBubbles reels={curatedReelBubbles} />
      <Suspense fallback={null}>
        <CollectionControls />
      </Suspense>
      <Reveal className="product-grid collection-grid">
        {products.map((p) => (
          <ProductCard
            key={p.id}
            product={{
              handle: p.handle,
              title: p.title,
              price: p.price?.toString() || '',
              compareAtPrice: p.compareAtPrice?.toString(),
              images: p.images.map((img) => img.url),
              isOutOfStock: p.isOutOfStock,
            }}
          />
        ))}
      </Reveal>
      <Suspense fallback={null}>
        <Pagination totalPages={totalPages} />
      </Suspense>
    </main>
  );
}
