import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(req: NextRequest) {
  const { reelId, featuredHome } = await req.json();
  if (!reelId || typeof featuredHome !== 'boolean') {
    return NextResponse.json({ error: 'reelId and featuredHome are required' }, { status: 400 });
  }

  await prisma.reel.update({ where: { id: reelId }, data: { featuredHome } });

  return NextResponse.json({ ok: true });
}
