// Razorpay webhook — the reliable order-completion path. Configure this URL
// in Razorpay Dashboard → Account & Settings → Webhooks, subscribed to the
// "payment.captured" event, and set RAZORPAY_WEBHOOK_SECRET in .env to
// whatever secret you set there. This fires from Razorpay's own servers
// the moment a payment is captured, regardless of what happens in the
// customer's browser (UPI app switches, netbanking redirects, and 3D-secure
// OTP pages all routinely prevent the client-side handler from ever firing —
// this webhook is what actually guarantees an order gets completed).
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { completeMagicOrder } from '@/lib/complete-magic-order';

export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get('x-razorpay-signature') || '';

  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET || '')
    .update(rawBody)
    .digest('hex');

  if (!process.env.RAZORPAY_WEBHOOK_SECRET || expectedSignature !== signature) {
    return NextResponse.json({ error: 'Invalid webhook signature' }, { status: 400 });
  }

  const event = JSON.parse(rawBody);

  if (event.event === 'payment.captured') {
    const payment = event.payload?.payment?.entity;
    if (payment?.order_id && payment?.id) {
      try {
        await completeMagicOrder(payment.order_id, payment.id, {
          clientIp: req.headers.get('x-forwarded-for'),
          userAgent: req.headers.get('user-agent'),
        });
      } catch (err) {
        // Log and still return 200 — Razorpay retries on non-2xx, and we
        // don't want retries piling up over an error that a human needs to
        // look at anyway (visible in pm2 logs).
        console.error('Webhook order completion failed:', payment.order_id, err);
      }
    }
  }

  // Always 200 once the signature checks out, so Razorpay doesn't keep
  // retrying — we've either handled it or logged why we couldn't.
  return NextResponse.json({ received: true });
}
