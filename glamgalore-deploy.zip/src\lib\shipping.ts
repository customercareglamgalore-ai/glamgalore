// Extracted from the original inline rule in create-order/route.ts so both the
// checkout quote preview and the real order creation share one source of truth.
export function computeShippingCost(subtotalINR: number, country: string): number {
  if (country.trim().toLowerCase() !== 'india') return 0; // free international shipping
  return subtotalINR > 2000 ? 0 : 99;
}
