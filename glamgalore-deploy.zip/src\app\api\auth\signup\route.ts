import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/db';
import { hashPassword, setSessionCookie } from '@/lib/auth';

const signupSchema = z.object({
  name: z.string().min(1).max(200),
  email: z.string().email(),
  phone: z.string().min(1).max(20).optional(),
  password: z.string().min(8).max(200),
});

export async function POST(req: NextRequest) {
  const parsed = signupSchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid signup details' }, { status: 400 });
  }
  const { name, email, phone, password } = parsed.data;

  const existing = await prisma.customer.findUnique({ where: { email } });
  if (existing) {
    return NextResponse.json({ error: 'An account with this email already exists' }, { status: 409 });
  }

  const customer = await prisma.customer.create({
    data: { name, email, phone, passwordHash: await hashPassword(password) },
  });

  await setSessionCookie(customer.id);

  return NextResponse.json({ customer: { id: customer.id, name: customer.name, email: customer.email } });
}
