import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getCustomerIdFromSession } from '@/lib/auth';

export async function GET() {
  const customerId = await getCustomerIdFromSession();
  if (!customerId) return NextResponse.json({ customer: null });

  const customer = await prisma.customer.findUnique({ where: { id: customerId } });
  if (!customer) return NextResponse.json({ customer: null });

  return NextResponse.json({ customer: { id: customer.id, name: customer.name, email: customer.email } });
}
