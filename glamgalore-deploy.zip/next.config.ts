import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  // pdfkit reads its own font-metric (.afm) data files relative to its package
  // directory at runtime; letting webpack bundle it breaks that resolution.
  serverExternalPackages: ['pdfkit'],
  // Hides the built-in Next.js dev-mode indicator (the circular "N" button,
  // bottom-left) -- it's dev-only tooling, not part of the site, and never
  // appears in production, but it was confusing during local testing.
  devIndicators: false,
};

export default nextConfig;
