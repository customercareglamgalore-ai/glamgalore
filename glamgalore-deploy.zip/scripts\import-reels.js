// Imports real reel videos once you've downloaded them from ReelUp/Shopify.
//
// data/reel_references.json maps product handles to their ReelUp video IDs,
// e.g. { "one-piece-bikini": [157930] }. To wire a video in:
//
//   1. Name the downloaded file after its ReelUp ID, e.g. 157930.mp4
//   2. Drop it in data/reels-raw/
//   3. Run: node scripts/import-reels.js
//
// The script copies each matched file into public/reels/ and creates a Reel
// row linking it to the right product. Products with no matching file yet
// are reported and skipped -- safe to re-run as you add more videos.

const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();

const RAW_DIR = path.join(__dirname, '../data/reels-raw');
const PUBLIC_DIR = path.join(__dirname, '../public/reels');
const VIDEO_EXTENSIONS = ['.mp4', '.mov', '.webm'];

function findRawFile(reelId) {
  for (const ext of VIDEO_EXTENSIONS) {
    const candidate = path.join(RAW_DIR, `${reelId}${ext}`);
    if (fs.existsSync(candidate)) return candidate;
  }
  return null;
}

async function main() {
  const references = JSON.parse(
    fs.readFileSync(path.join(__dirname, '../data/reel_references.json'), 'utf-8')
  );

  if (!fs.existsSync(RAW_DIR)) fs.mkdirSync(RAW_DIR, { recursive: true });
  if (!fs.existsSync(PUBLIC_DIR)) fs.mkdirSync(PUBLIC_DIR, { recursive: true });

  let imported = 0;
  let missing = 0;
  const missingHandles = [];

  for (const [handle, reelIds] of Object.entries(references)) {
    if (!reelIds.length) continue;

    const product = await prisma.product.findUnique({ where: { handle } });
    if (!product) continue;

    for (let position = 0; position < reelIds.length; position++) {
      const reelId = reelIds[position];
      const rawFile = findRawFile(reelId);

      if (!rawFile) {
        missing++;
        missingHandles.push(`${handle} (${reelId})`);
        continue;
      }

      const ext = path.extname(rawFile);
      const publicFile = path.join(PUBLIC_DIR, `${reelId}${ext}`);
      fs.copyFileSync(rawFile, publicFile);

      await prisma.reel.upsert({
        where: { id: `reelup-${reelId}` },
        update: { videoUrl: `/reels/${reelId}${ext}`, position },
        create: {
          id: `reelup-${reelId}`,
          productId: product.id,
          videoUrl: `/reels/${reelId}${ext}`,
          position,
        },
      });
      imported++;
    }
  }

  console.log(`Imported ${imported} reel(s).`);
  if (missing > 0) {
    console.log(`${missing} reel(s) still need a video file in data/reels-raw/:`);
    missingHandles.forEach((h) => console.log(`  - ${h}`));
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
