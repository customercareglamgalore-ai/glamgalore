import Link from 'next/link';
import Reveal from '@/components/Reveal';

export const metadata = {
  title: 'Help Center — Glam Galore',
  description: 'Answers to common questions about orders, shipping, and returns at Glam Galore.',
};

const FAQS = [
  {
    q: 'Where is my order?',
    a: (
      <>
        Track it any time on our <Link href="/track-order">Track Your Order</Link> page using your order
        number and the email used at checkout.
      </>
    ),
  },
  {
    q: 'How long does delivery take?',
    a: 'Orders are processed within 2–3 business days and typically delivered within 15–18 days, which can extend up to 21 days in some circumstances.',
  },
  {
    q: 'Do you ship outside India?',
    a: 'Yes — we offer free shipping worldwide. Delivery time is 18–21 days.',
  },
  {
    q: 'How do I return or exchange an item?',
    a: (
      <>
        Email us at <a href="mailto:support@glamgalore.in">support@glamgalore.in</a> within 72 hours of
        delivery with photos of the item and its tags. See our full{' '}
        <Link href="/returns-refunds">Returns &amp; Refunds</Link> policy for eligibility details.
      </>
    ),
  },
  {
    q: 'Can I cancel my order?',
    a: 'Orders can be cancelled only if they have not yet been processed, subject to cancellation charges.',
  },
  {
    q: "I received the wrong or a damaged item — what now?",
    a: 'Please contact us within 48 hours of delivery with photos of the packet and item, and we will investigate and assist you.',
  },
];

export default function HelpCenterPage() {
  return (
    <main className="blog-post-page">
      <Reveal className="container blog-post-container">
        <h1>Help Center</h1>
        <div className="blog-post-body">
          <p>
            Can&apos;t find what you&apos;re looking for here? Reach out to us at{' '}
            <a href="mailto:support@glamgalore.in">support@glamgalore.in</a> or on{' '}
            <a href="https://wa.me/919769708781">WhatsApp</a> — we&apos;re happy to help.
          </p>

          {FAQS.map((item) => (
            <div key={item.q} style={{ marginTop: 28 }}>
              <h2 style={{ marginBottom: 6 }}>{item.q}</h2>
              <p>{item.a}</p>
            </div>
          ))}

          <div style={{ marginTop: 40, paddingTop: 24, borderTop: '1px solid #eee' }}>
            <p>You may also find these useful:</p>
            <ul>
              <li><Link href="/shipping-policy">Shipping Policy</Link></li>
              <li><Link href="/returns-refunds">Returns &amp; Refunds</Link></li>
              <li><Link href="/terms-of-service">Terms of Service</Link></li>
              <li><Link href="/privacy-policy">Privacy Policy</Link></li>
              <li><Link href="/contact">Contact Us</Link></li>
            </ul>
          </div>
        </div>
      </Reveal>
    </main>
  );
}
