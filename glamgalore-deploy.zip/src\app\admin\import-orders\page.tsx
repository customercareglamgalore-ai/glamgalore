'use client';

import { useRef, useState } from 'react';

type ImportResult = { imported: number; skipped: number; errors: string[] };

const btnStyle: React.CSSProperties = { padding: '8px 16px', background: '#000', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 13 };

export default function ImportOrdersPage() {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleUpload() {
    const file = fileRef.current?.files?.[0];
    if (!file) return;

    setUploading(true);
    setError(null);
    setResult(null);

    const formData = new FormData();
    formData.append('file', file);

    const res = await fetch('/api/admin/import-orders', { method: 'POST', body: formData });
    const data = await res.json();
    setUploading(false);

    if (!res.ok) {
      setError(data.error || 'Import failed');
    } else {
      setResult(data);
    }
  }

  return (
    <main style={{ padding: 40, maxWidth: 720, margin: '0 auto', fontFamily: 'system-ui' }}>
      <h1 style={{ fontSize: 20 }}>Import Historical Orders</h1>
      <p style={{ fontSize: 13, color: '#666', marginTop: 8 }}>
        Upload a Shopify/Matrixify orders export (.xlsx). Each order&apos;s GST is recomputed fresh
        through the current tax rules (not trusted from the source file), and a real invoice number +
        PDF is generated for each, backdated to the order&apos;s original date. Orders already imported
        (matched by Shopify order name) are skipped automatically, so re-uploading the same file is safe.
      </p>

      <div style={{ marginTop: 20 }}>
        <input ref={fileRef} type="file" accept=".xlsx" />
        <button style={{ ...btnStyle, marginLeft: 12 }} onClick={handleUpload} disabled={uploading}>
          {uploading ? 'Importing...' : 'Import'}
        </button>
      </div>

      {error && <p style={{ color: '#e22120', marginTop: 16 }}>{error}</p>}

      {result && (
        <div style={{ marginTop: 24, borderTop: '1px solid #eee', paddingTop: 16 }}>
          <p style={{ fontSize: 14 }}>
            <strong>{result.imported}</strong> orders imported, <strong>{result.skipped}</strong> skipped.
          </p>
          {result.errors.length > 0 && (
            <>
              <p style={{ fontSize: 13, color: '#666', marginTop: 12 }}>Details:</p>
              <ul style={{ fontSize: 12, color: '#999', maxHeight: 300, overflowY: 'auto' }}>
                {result.errors.map((e, i) => (
                  <li key={i}>{e}</li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}
    </main>
  );
}
