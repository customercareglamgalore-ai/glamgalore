import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET() {
  const products = await prisma.product.findMany({
    where: { status: 'active', collections: { has: 'top-selling' } },
    include: { images: { take: 4, orderBy: { position: 'asc' } } },
    take: 8,
    orderBy: { createdAt: 'desc' },
  });

  return NextResponse.json({
    products: products.map((p) => ({
      handle: p.handle,
      title: p.title,
      price: p.price?.toString() || '',
      compareAtPrice: p.compareAtPrice?.toString(),
      images: p.images.map((img) => img.url),
      isOutOfStock: p.isOutOfStock,
    })),
  });
}
