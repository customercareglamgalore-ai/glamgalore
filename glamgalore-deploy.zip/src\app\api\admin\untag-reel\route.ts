import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import fs from 'fs';
import path from 'path';

const REELS_DIR = path.join(process.cwd(), 'public', 'reels');
const INBOX_DIR = path.join(process.cwd(), 'public', 'reels-inbox');

export async function POST(req: NextRequest) {
  const { reelId } = await req.json();
  if (!reelId) return NextResponse.json({ error: 'reelId is required' }, { status: 400 });

  const reel = await prisma.reel.findUnique({ where: { id: reelId } });
  if (!reel) return NextResponse.json({ error: 'Reel not found' }, { status: 404 });

  const filename = path.basename(reel.videoUrl);
  const filePath = path.join(REELS_DIR, filename);
  if (fs.existsSync(filePath)) {
    if (!fs.existsSync(INBOX_DIR)) fs.mkdirSync(INBOX_DIR, { recursive: true });
    fs.renameSync(filePath, path.join(INBOX_DIR, filename));
  }

  await prisma.reel.delete({ where: { id: reelId } });

  return NextResponse.json({ ok: true });
}
