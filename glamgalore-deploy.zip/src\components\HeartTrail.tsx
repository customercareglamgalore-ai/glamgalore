'use client';

import { useEffect, useRef } from 'react';

// Floating white heart trail — follows mouse drag on desktop, finger drag on
// mobile (touch has no hover, so it's drag-triggered, not hover-triggered).
// Drop this into any section as an absolutely-positioned overlay:
//
//   <div style={{ position: 'relative' }}>
//     <img src="..." />
//     <HeartTrail />
//   </div>

const MAX_HEARTS = 15; // cap so it stays smooth on lower-end phones
const SPAWN_INTERVAL_MS = 70;

export default function HeartTrail() {
  const zoneRef = useRef<HTMLDivElement>(null);
  const lastSpawnRef = useRef(0);
  const heartCountRef = useRef(0);

  useEffect(() => {
    const zone = zoneRef.current;
    if (!zone) return;
    // Listen on the parent (the hero link), not the zone div itself -- the
    // zone is pointer-events:none so hearts never block clicks on anything
    // stacked above it (like the transparent header overlaying the hero).
    const target = zone.parentElement ?? zone;

    function spawnHeart(x: number, y: number) {
      if (heartCountRef.current >= MAX_HEARTS) return;
      heartCountRef.current++;

      const size = 14 + Math.random() * 10;
      const heart = document.createElement('div');
      heart.innerHTML = `<svg width="${size}" height="${size}" viewBox="0 0 24 24"><path d="M12 21s-7.5-4.7-10-9.3C.3 8.4 2 5 5.5 5c2 0 3.3 1 4.5 2.5C11.2 6 12.5 5 14.5 5 18 5 19.7 8.4 22 11.7 19.5 16.3 12 21 12 21z" fill="white"/></svg>`;
      heart.style.position = 'absolute';
      heart.style.left = `${x}px`;
      heart.style.top = `${y}px`;
      heart.style.pointerEvents = 'none';
      heart.style.opacity = '0.95';
      heart.style.transition = 'transform 1.3s ease-out, opacity 1.3s ease-out, top 1.3s ease-out';
      heart.style.transform = `scale(1) rotate(${Math.random() * 30 - 15}deg)`;
      zone!.appendChild(heart);

      requestAnimationFrame(() => {
        heart.style.top = `${y - 50 - Math.random() * 20}px`;
        heart.style.opacity = '0';
        heart.style.transform = `scale(0.5) rotate(${Math.random() * 30 - 15}deg)`;
      });

      setTimeout(() => {
        heart.remove();
        heartCountRef.current--;
      }, 1400);
    }

    function handleMove(clientX: number, clientY: number) {
      const now = Date.now();
      if (now - lastSpawnRef.current < SPAWN_INTERVAL_MS) return;
      lastSpawnRef.current = now;
      const rect = zone!.getBoundingClientRect();
      spawnHeart(clientX - rect.left, clientY - rect.top);
    }

    function onPointerMove(e: PointerEvent) {
      handleMove(e.clientX, e.clientY);
    }
    function onTouchMove(e: TouchEvent) {
      const t = e.touches[0];
      if (t) handleMove(t.clientX, t.clientY);
    }

    target.addEventListener('pointermove', onPointerMove as EventListener);
    target.addEventListener('touchmove', onTouchMove as EventListener);
    return () => {
      target.removeEventListener('pointermove', onPointerMove as EventListener);
      target.removeEventListener('touchmove', onTouchMove as EventListener);
    };
  }, []);

  return (
    <div
      ref={zoneRef}
      style={{
        position: 'absolute',
        inset: 0,
        overflow: 'hidden',
        touchAction: 'none',
        pointerEvents: 'none',
        zIndex: 5,
      }}
    />
  );
}
