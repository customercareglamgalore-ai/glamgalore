'use client';

import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import ProductCard from '@/components/ProductCard';
import ProductCarousel from '@/components/ProductCarousel';
import Reveal from '@/components/Reveal';

type Product = { handle: string; title: string; price: string; compareAtPrice?: string; images: string[]; isOutOfStock?: boolean };

export default function SearchClient({ trendingProducts }: { trendingProducts: Product[] }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const activeQuery = searchParams.get('q') || '';

  const [query, setQuery] = useState(activeQuery);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setQuery(activeQuery);
    if (!activeQuery) {
      setProducts([]);
      return;
    }
    setLoading(true);
    fetch(`/api/search?q=${encodeURIComponent(activeQuery)}`)
      .then((res) => res.json())
      .then((data) => setProducts(data.products))
      .finally(() => setLoading(false));
  }, [activeQuery]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    router.push(`/search?q=${encodeURIComponent(query)}`);
  }

  return (
    <main className="container">
      <h1 className="section-heading">Search</h1>
      <form onSubmit={handleSubmit} style={{ maxWidth: 480, margin: '0 auto 32px' }}>
        <input
          placeholder="Search products..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
          style={{ display: 'block', width: '100%', padding: 10 }}
        />
      </form>

      {loading && <p style={{ textAlign: 'center' }}>Searching...</p>}
      {!loading && activeQuery && products.length === 0 && (
        <p style={{ textAlign: 'center' }}>No products found for &quot;{activeQuery}&quot;.</p>
      )}

      {activeQuery ? (
        <Reveal className="product-grid">
          {products.map((p) => (
            <ProductCard key={p.handle} product={p} />
          ))}
        </Reveal>
      ) : (
        trendingProducts.length > 0 && (
          <Reveal>
            <h2 className="section-heading">Trending Products</h2>
            <ProductCarousel products={trendingProducts} />
          </Reveal>
        )
      )}
    </main>
  );
}
