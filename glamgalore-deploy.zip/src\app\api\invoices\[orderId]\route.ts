import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import { prisma } from '@/lib/db';
import { getCustomerIdFromSession } from '@/lib/auth';
import { generateInvoicePdf, invoicePdfPath } from '@/lib/invoice-pdf';

function isAdminRequest(req: NextRequest): boolean {
  const expectedUser = process.env.ADMIN_USER;
  const expectedPassword = process.env.ADMIN_PASSWORD;
  if (!expectedUser || !expectedPassword) return false;
  const expected = 'Basic ' + Buffer.from(`${expectedUser}:${expectedPassword}`).toString('base64');
  return req.headers.get('authorization') === expected;
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ orderId: string }> }) {
  const { orderId } = await params;

  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 });
  }

  const customerId = await getCustomerIdFromSession();
  const isOwner = customerId && customerId === order.customerId;
  if (!isOwner && !isAdminRequest(req)) {
    return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
  }

  if (!order.invoiceNumber) {
    return NextResponse.json({ error: 'Invoice not generated yet for this order' }, { status: 404 });
  }

  let filePath = invoicePdfPath(order.invoiceNumber);
  if (!fs.existsSync(filePath)) {
    // Regenerate on demand — the invoice number is already allocated, so this is safe/idempotent.
    ({ filePath } = await generateInvoicePdf(order.id));
  }

  const buffer = fs.readFileSync(filePath);
  return new NextResponse(buffer, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="${order.invoiceNumber}.pdf"`,
    },
  });
}
