import { Suspense } from 'react';
import { prisma } from '@/lib/db';
import SearchClient from './SearchClient';

async function getTrendingProducts() {
  const products = await prisma.product.findMany({
    where: { status: 'active', collections: { has: 'top-selling' } },
    include: { images: { orderBy: { position: 'asc' }, take: 4 } },
    take: 8,
    orderBy: { createdAt: 'desc' },
  });
  return products.map((p) => ({
    handle: p.handle,
    title: p.title,
    price: p.price?.toString() || '',
    compareAtPrice: p.compareAtPrice ? p.compareAtPrice.toString() : undefined,
    images: p.images.map((img) => img.url),
    isOutOfStock: p.isOutOfStock,
  }));
}

export default async function SearchPage() {
  const trendingProducts = await getTrendingProducts();

  return (
    <Suspense fallback={<main className="container"><p>Loading...</p></main>}>
      <SearchClient trendingProducts={trendingProducts} />
    </Suspense>
  );
}
