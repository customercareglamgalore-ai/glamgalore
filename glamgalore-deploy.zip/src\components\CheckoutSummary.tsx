'use client';

import { useEffect, useState } from 'react';

type CartItem = { productId: string; variantId?: string | null; quantity: number };

type Quote = {
  taxType: 'intra_state' | 'inter_state' | 'export_zero_rated' | 'export_taxed';
  subtotal: number;
  shippingCost: number;
  grandTotal: number;
  currency: string;
  discountAmount: number;
  discountCode: string | null;
  discountError: string | null;
};

export default function CheckoutSummary({
  cartItems,
  country,
  state,
  discountCode,
  onDiscountCodeChange,
}: {
  cartItems: CartItem[];
  country: string;
  state: string;
  discountCode: string;
  onDiscountCodeChange: (code: string) => void;
}) {
  const [quote, setQuote] = useState<Quote | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [codeInput, setCodeInput] = useState(discountCode);

  useEffect(() => {
    if (cartItems.length === 0) return;
    const timer = setTimeout(() => {
      fetch('/api/checkout/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cartItems, country, state, discountCode }),
      })
        .then((r) => r.json())
        .then((data) => {
          if (data.error) {
            setError(data.error);
            setQuote(null);
          } else {
            setError(null);
            setQuote(data);
          }
        })
        .catch(() => setError('Could not calculate tax right now.'));
    }, 250);
    return () => clearTimeout(timer);
  }, [JSON.stringify(cartItems), country, state, discountCode]);

  if (error) return <p style={{ color: '#e22120', fontSize: 13 }}>{error}</p>;
  if (!quote) return <p style={{ fontSize: 13, color: '#999' }}>Calculating total...</p>;

  const rowStyle: React.CSSProperties = { display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: 14 };
  const isZeroTax = quote.taxType === 'export_zero_rated';

  return (
    <div style={{ border: '1px solid #eee', padding: 16, margin: '16px 0' }}>
      <div style={rowStyle}>
        <span>Product Subtotal</span>
        <span>₹{quote.subtotal.toFixed(2)}</span>
      </div>
      {quote.discountAmount > 0 && (
        <div style={{ ...rowStyle, color: '#e22120' }}>
          <span>Discount ({quote.discountCode})</span>
          <span>-₹{quote.discountAmount.toFixed(2)}</span>
        </div>
      )}
      <div style={rowStyle}>
        <span>Shipping</span>
        <span>{quote.shippingCost === 0 ? 'Free' : `₹${quote.shippingCost.toFixed(2)}`}</span>
      </div>
      <div style={{ ...rowStyle, borderTop: '1px solid #eee', marginTop: 8, paddingTop: 12, fontWeight: 600 }}>
        <span>Grand Total</span>
        <span>₹{quote.grandTotal.toFixed(2)}</span>
      </div>
      <p style={{ fontSize: 12, color: '#999', margin: '6px 0 0', textAlign: 'right' }}>
        {isZeroTax ? 'No taxes charged on international orders' : 'Inclusive of all taxes'}
      </p>

      <div style={{ display: 'flex', gap: 8, marginTop: 12, paddingTop: 12, borderTop: '1px solid #eee' }}>
        <input
          placeholder="Discount code"
          value={codeInput}
          onChange={(e) => setCodeInput(e.target.value)}
          style={{ flex: 1, padding: 8, border: '1px solid #ccc', fontSize: 13 }}
        />
        <button
          type="button"
          onClick={() => onDiscountCodeChange(codeInput)}
          style={{ padding: '8px 14px', background: '#000', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 13 }}
        >
          Apply
        </button>
      </div>
      {quote.discountError && <p style={{ color: '#e22120', fontSize: 12, marginTop: 6 }}>{quote.discountError}</p>}
    </div>
  );
}
