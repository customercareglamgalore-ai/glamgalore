'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import Script from 'next/script';
import Reveal from '@/components/Reveal';
import { notifyCartUpdated } from '@/lib/cart-count';

type CartItem = {
  productId: string;
  variantId?: string;
  quantity: number;
  title?: string;
  variantLabel?: string;
  price?: string;
  imageUrl?: string;
};

export default function CartPage() {
  const [items, setItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [discountCode, setDiscountCode] = useState('');

  useEffect(() => {
    const raw = JSON.parse(localStorage.getItem('cart') || '[]') as CartItem[];
    // Fetch display details for each cart line from the API so prices are
    // always current, not whatever was cached when the item was added.
    fetch('/api/cart/hydrate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: raw }),
    })
      .then((res) => res.json())
      .then((data) => setItems(data.items))
      .finally(() => setLoading(false));
  }, []);

  const total = items.reduce((sum, i) => sum + Number(i.price || 0) * i.quantity, 0);

  async function handleCheckout() {
    setSubmitting(true);
    setError(null);

    try {
      if (typeof window === 'undefined' || !(window as any).Razorpay) {
        setError('Payment gateway is still loading — please wait a moment and try again.');
        return;
      }

      const cartItems = JSON.parse(localStorage.getItem('cart') || '[]');
      const res = await fetch('/api/checkout/create-magic-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cartItems, discountCode }),
      });
      if (!res.ok) {
        const { error: message } = await res.json();
        setError(message || 'Something went wrong. Please try again.');
        return;
      }
      const order = await res.json();

      const options = {
        key: order.keyId,
        amount: order.amount,
        currency: order.currency,
        name: 'Glam Galore',
        order_id: order.razorpayOrderId,
        one_click_checkout: true,
        show_coupons: false,
        handler: async function (response: any) {
          try {
            const verifyRes = await fetch('/api/checkout/verify-magic', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(response),
            });
            const result = await verifyRes.json();
            if (result.success) {
              localStorage.removeItem('cart');
              notifyCartUpdated();
              window.location.href = `/order-confirmed?orderId=${result.orderId}`;
            } else {
              setError('Payment received, but confirming your order failed. Please contact support with your payment ID.');
            }
          } catch {
            setError('Payment received, but confirming your order failed. Please contact support with your payment ID.');
          }
        },
        modal: {
          ondismiss: () => setSubmitting(false),
        },
        theme: { color: '#000000' },
      };

      const rzp = new (window as any).Razorpay(options);
      rzp.open();
    } catch (err) {
      console.error('Checkout failed:', err);
      setError('Something went wrong starting checkout. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) return <main className="container"><p>Loading your cart...</p></main>;

  if (items.length === 0) {
    return (
      <main className="container">
        <h1 className="section-heading">Your cart is empty</h1>
        <p style={{ textAlign: 'center' }}><Link href="/" className="btn">Continue shopping</Link></p>
      </main>
    );
  }

  return (
    <main className="container">
      <Script src="https://checkout.razorpay.com/v1/magic-checkout.js" strategy="afterInteractive" />
      <Reveal>
        <h1 className="section-heading">Your Cart</h1>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {items.map((item) => (
            <li
              key={`${item.productId}-${item.variantId || 'default'}`}
              style={{ display: 'flex', gap: 16, borderTop: '1px solid #eee', padding: '16px 0' }}
            >
              {item.imageUrl && <img src={item.imageUrl} alt={item.title} style={{ width: 80, height: 100, objectFit: 'cover' }} />}
              <div>
                <p>{item.title}</p>
                {item.variantLabel && <p style={{ color: '#777', fontSize: '0.85rem' }}>{item.variantLabel}</p>}
                <p>Qty: {item.quantity}</p>
                <p>₹{item.price}</p>
              </div>
            </li>
          ))}
        </ul>
        <p style={{ textAlign: 'right', fontSize: '1.1rem' }}>Total: ₹{total.toFixed(2)}</p>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, margin: '12px 0' }}>
          <input
            placeholder="Discount code"
            value={discountCode}
            onChange={(e) => setDiscountCode(e.target.value)}
            style={{ padding: 8, border: '1px solid #ccc', fontSize: 13, maxWidth: 200 }}
          />
        </div>
        {error && <p style={{ color: '#e22120', textAlign: 'right' }}>{error}</p>}
        <p style={{ textAlign: 'right' }}>
          <button type="button" className="btn" onClick={handleCheckout} disabled={submitting}>
            {submitting ? 'Processing...' : 'Checkout'}
          </button>
        </p>
      </Reveal>
    </main>
  );
}
