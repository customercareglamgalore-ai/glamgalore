'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import Reveal from '@/components/Reveal';

type CartItem = {
  productId: string;
  variantId?: string;
  quantity: number;
  title?: string;
  variantLabel?: string;
  price?: string;
  imageUrl?: string;
};

export default function CartPage() {
  const [items, setItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const raw = JSON.parse(localStorage.getItem('cart') || '[]') as CartItem[];
    // Fetch display details for each cart line from the API so prices are
    // always current, not whatever was cached when the item was added.
    fetch('/api/cart/hydrate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: raw }),
    })
      .then((res) => res.json())
      .then((data) => setItems(data.items))
      .finally(() => setLoading(false));
  }, []);

  const total = items.reduce((sum, i) => sum + Number(i.price || 0) * i.quantity, 0);

  if (loading) return <main className="container"><p>Loading your cart...</p></main>;

  if (items.length === 0) {
    return (
      <main className="container">
        <h1 className="section-heading">Your cart is empty</h1>
        <p style={{ textAlign: 'center' }}><Link href="/" className="btn">Continue shopping</Link></p>
      </main>
    );
  }

  return (
    <main className="container">
      <Reveal>
        <h1 className="section-heading">Your Cart</h1>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {items.map((item) => (
            <li
              key={`${item.productId}-${item.variantId || 'default'}`}
              style={{ display: 'flex', gap: 16, borderTop: '1px solid #eee', padding: '16px 0' }}
            >
              {item.imageUrl && <img src={item.imageUrl} alt={item.title} style={{ width: 80, height: 100, objectFit: 'cover' }} />}
              <div>
                <p>{item.title}</p>
                {item.variantLabel && <p style={{ color: '#777', fontSize: '0.85rem' }}>{item.variantLabel}</p>}
                <p>Qty: {item.quantity}</p>
                <p>₹{item.price}</p>
              </div>
            </li>
          ))}
        </ul>
        <p style={{ textAlign: 'right', fontSize: '1.1rem' }}>Total: ₹{total.toFixed(2)}</p>
        <p style={{ textAlign: 'right' }}>
          <Link href="/checkout" className="btn">Checkout</Link>
        </p>
      </Reveal>
    </main>
  );
}
