// CJ Dropshipping API client.
// Docs: https://developers.cjdropshipping.com/
//
// Auth: CJ_EMAIL + CJ_API_KEY (in .env) are the durable credentials, used to
// bootstrap a session via /authentication/getAccessToken. The resulting
// accessToken/refreshToken are cached on StoreSettings (mutable runtime
// state, not .env) and refreshed automatically before they expire. A fresh
// email+apiKey login is only needed again if the refresh token itself
// expires (much longer-lived than the access token).

import { prisma } from './db';
import { COUNTRY_TO_ISO_CODE } from './currency';

const CJ_BASE_URL = 'https://developers.cjdropshipping.com/api2.0/v1';
const REFRESH_MARGIN_MS = 24 * 60 * 60 * 1000; // refresh a day before expiry, not right at the wire

async function loginWithCredentials() {
  const email = process.env.CJ_EMAIL;
  const apiKey = process.env.CJ_API_KEY;
  if (!email || !apiKey) throw new Error('CJ_EMAIL / CJ_API_KEY not configured');

  const res = await fetch(`${CJ_BASE_URL}/authentication/getAccessToken`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: apiKey }),
  });
  const data = await res.json();
  if (!data.result || !data.data?.accessToken) {
    throw new Error(`CJ login failed: ${data.code} ${data.message}`);
  }
  return data.data as {
    accessToken: string;
    accessTokenExpiryDate: string;
    refreshToken: string;
    refreshTokenExpiryDate: string;
  };
}

async function refreshWithToken(refreshToken: string) {
  const res = await fetch(`${CJ_BASE_URL}/authentication/refreshAccessToken`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refreshToken }),
  });
  const data = await res.json();
  if (!data.result || !data.data?.accessToken) {
    throw new Error(`CJ refresh failed: ${data.code} ${data.message}`);
  }
  return data.data as {
    accessToken: string;
    accessTokenExpiryDate: string;
    refreshToken: string;
    refreshTokenExpiryDate: string;
  };
}

async function getValidAccessToken(): Promise<string> {
  const settings = await prisma.storeSettings.findUnique({ where: { id: 'singleton' } });

  const stillValid =
    settings?.cjAccessToken &&
    settings.cjAccessTokenExpiresAt &&
    settings.cjAccessTokenExpiresAt.getTime() - Date.now() > REFRESH_MARGIN_MS;
  if (stillValid) return settings!.cjAccessToken!;

  const refreshStillValid =
    settings?.cjRefreshToken &&
    settings.cjRefreshTokenExpiresAt &&
    settings.cjRefreshTokenExpiresAt.getTime() - Date.now() > REFRESH_MARGIN_MS;

  const result = refreshStillValid
    ? await refreshWithToken(settings!.cjRefreshToken!)
    : await loginWithCredentials();

  await prisma.storeSettings.upsert({
    where: { id: 'singleton' },
    create: {
      id: 'singleton',
      cjAccessToken: result.accessToken,
      cjRefreshToken: result.refreshToken,
      cjAccessTokenExpiresAt: new Date(result.accessTokenExpiryDate),
      cjRefreshTokenExpiresAt: new Date(result.refreshTokenExpiryDate),
    },
    update: {
      cjAccessToken: result.accessToken,
      cjRefreshToken: result.refreshToken,
      cjAccessTokenExpiresAt: new Date(result.accessTokenExpiryDate),
      cjRefreshTokenExpiresAt: new Date(result.refreshTokenExpiryDate),
    },
  });

  return result.accessToken;
}

async function cjHeaders() {
  return {
    'CJ-Access-Token': await getValidAccessToken(),
    'Content-Type': 'application/json',
  };
}

// Pulls current price + stock for a CJ product. Call this on a schedule
// (e.g. hourly cron) rather than on every page load — CJ's rate limits are
// modest, and your DB should be the source of truth the storefront reads from.
export async function fetchCJProduct(cjProductId: string) {
  const res = await fetch(`${CJ_BASE_URL}/product/query?pid=${cjProductId}`, {
    headers: await cjHeaders(),
  });
  if (!res.ok) throw new Error(`CJ product fetch failed: ${res.status}`);
  const data = await res.json();
  return data.data; // { productName, sellPrice, variants: [...], ... } — shape per CJ docs
}

// Submits a paid order to CJ for fulfillment. Called from the Razorpay
// verify webhook once payment is confirmed.
//
// Product identification: CJ's createOrderV2 accepts a variant `sku` in lieu
// of their internal `vid` ("vid and sku cannot both be null. When vid is
// missing, sku will be used to query the CJ variant" — CJ API docs). Every
// CJ-sourced product in our catalog already carries that CJ SKU (format
// "CJ..."), imported alongside the product itself — no separate vid lookup
// or product-mapping step is needed. Line items whose SKU doesn't start
// with "CJ" are non-CJ products (locally fulfilled) and are left out of the
// CJ order entirely.
export async function submitOrderToCJ(order: any): Promise<string | null> {
  const products = order.items
    .filter((item: any) => /^cj/i.test(item.variant?.sku || ''))
    .map((item: any) => ({
      sku: item.variant.sku,
      quantity: item.quantity,
      storeLineItemId: item.id,
    }));

  if (products.length === 0) return null; // nothing in this order is CJ-fulfilled

  const address = order.shippingAddress as {
    name?: string; email?: string; phone?: string;
    line1?: string; line2?: string; city?: string; state?: string; pincode?: string; country?: string;
  };

  const payload = {
    orderNumber: order.id,
    shippingCustomerName: address.name || '',
    shippingAddress: address.line1 || '',
    shippingAddress2: address.line2 || '',
    shippingCity: address.city || '',
    shippingProvince: address.state || '',
    shippingCountry: address.country || '',
    shippingCountryCode: COUNTRY_TO_ISO_CODE[address.country || ''] || '',
    shippingZip: address.pincode || '',
    shippingPhone: address.phone || '',
    email: address.email || '',
    products,
  };

  const res = await fetch(`${CJ_BASE_URL}/shopping/order/createOrderV2`, {
    method: 'POST',
    headers: await cjHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`CJ order submission failed: ${res.status} ${body}`);
  }
  const data = await res.json();
  if (!data.result) throw new Error(`CJ order submission failed: ${data.code} ${data.message}`);
  return data.data.orderId;
}

// Polls tracking status for an order already submitted to CJ. CJ has no
// dedicated tracking-lookup endpoint — trackNumber/trackingProvider are
// fields on the order detail response, null until CJ marks it shipped.
// Wire this into a scheduled job that updates Order.trackingNumber and
// notifies the customer once tracking is available.
export async function fetchCJTracking(cjOrderId: string) {
  const res = await fetch(`${CJ_BASE_URL}/shopping/order/getOrderDetail?orderId=${cjOrderId}`, {
    headers: await cjHeaders(),
  });
  if (!res.ok) throw new Error(`CJ tracking fetch failed: ${res.status}`);
  const data = await res.json();
  if (!data.result) throw new Error(`CJ tracking fetch failed: ${data.code} ${data.message}`);
  return data.data; // { trackNumber, trackingProvider, trackingUrl, ... }
}
