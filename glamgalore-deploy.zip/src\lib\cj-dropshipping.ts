// CJ Dropshipping API client.
// Docs: https://developers.cjdropshipping.com/
//
// Auth: CJ_EMAIL + CJ_API_KEY (in .env) are the durable credentials, used to
// bootstrap a session via /authentication/getAccessToken. The resulting
// accessToken/refreshToken are cached on StoreSettings (mutable runtime
// state, not .env) and refreshed automatically before they expire. A fresh
// email+apiKey login is only needed again if the refresh token itself
// expires (much longer-lived than the access token).

import { prisma } from './db';

const CJ_BASE_URL = 'https://developers.cjdropshipping.com/api2.0/v1';
const REFRESH_MARGIN_MS = 24 * 60 * 60 * 1000; // refresh a day before expiry, not right at the wire

async function loginWithCredentials() {
  const email = process.env.CJ_EMAIL;
  const apiKey = process.env.CJ_API_KEY;
  if (!email || !apiKey) throw new Error('CJ_EMAIL / CJ_API_KEY not configured');

  const res = await fetch(`${CJ_BASE_URL}/authentication/getAccessToken`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: apiKey }),
  });
  const data = await res.json();
  if (!data.result || !data.data?.accessToken) {
    throw new Error(`CJ login failed: ${data.code} ${data.message}`);
  }
  return data.data as {
    accessToken: string;
    accessTokenExpiryDate: string;
    refreshToken: string;
    refreshTokenExpiryDate: string;
  };
}

async function refreshWithToken(refreshToken: string) {
  const res = await fetch(`${CJ_BASE_URL}/authentication/refreshAccessToken`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refreshToken }),
  });
  const data = await res.json();
  if (!data.result || !data.data?.accessToken) {
    throw new Error(`CJ refresh failed: ${data.code} ${data.message}`);
  }
  return data.data as {
    accessToken: string;
    accessTokenExpiryDate: string;
    refreshToken: string;
    refreshTokenExpiryDate: string;
  };
}

async function getValidAccessToken(): Promise<string> {
  const settings = await prisma.storeSettings.findUnique({ where: { id: 'singleton' } });

  const stillValid =
    settings?.cjAccessToken &&
    settings.cjAccessTokenExpiresAt &&
    settings.cjAccessTokenExpiresAt.getTime() - Date.now() > REFRESH_MARGIN_MS;
  if (stillValid) return settings!.cjAccessToken!;

  const refreshStillValid =
    settings?.cjRefreshToken &&
    settings.cjRefreshTokenExpiresAt &&
    settings.cjRefreshTokenExpiresAt.getTime() - Date.now() > REFRESH_MARGIN_MS;

  const result = refreshStillValid
    ? await refreshWithToken(settings!.cjRefreshToken!)
    : await loginWithCredentials();

  await prisma.storeSettings.upsert({
    where: { id: 'singleton' },
    create: {
      id: 'singleton',
      cjAccessToken: result.accessToken,
      cjRefreshToken: result.refreshToken,
      cjAccessTokenExpiresAt: new Date(result.accessTokenExpiryDate),
      cjRefreshTokenExpiresAt: new Date(result.refreshTokenExpiryDate),
    },
    update: {
      cjAccessToken: result.accessToken,
      cjRefreshToken: result.refreshToken,
      cjAccessTokenExpiresAt: new Date(result.accessTokenExpiryDate),
      cjRefreshTokenExpiresAt: new Date(result.refreshTokenExpiryDate),
    },
  });

  return result.accessToken;
}

async function cjHeaders() {
  return {
    'CJ-Access-Token': await getValidAccessToken(),
    'Content-Type': 'application/json',
  };
}

// Pulls current price + stock for a CJ product. Call this on a schedule
// (e.g. hourly cron) rather than on every page load — CJ's rate limits are
// modest, and your DB should be the source of truth the storefront reads from.
export async function fetchCJProduct(cjProductId: string) {
  const res = await fetch(`${CJ_BASE_URL}/product/query?pid=${cjProductId}`, {
    headers: await cjHeaders(),
  });
  if (!res.ok) throw new Error(`CJ product fetch failed: ${res.status}`);
  const data = await res.json();
  return data.data; // { productName, sellPrice, variants: [...], ... } — shape per CJ docs
}

// Submits a paid order to CJ for fulfillment. Called from the Razorpay
// verify webhook once payment is confirmed.
export async function submitOrderToCJ(order: any): Promise<string> {
  const payload = {
    orderNumber: order.id,
    shippingAddress: order.shippingAddress,
    products: order.items
      .filter((item: any) => item.product.isDropshipped && item.product.cjProductId)
      .map((item: any) => ({
        vid: item.variant?.cjVariantId,
        quantity: item.quantity,
      })),
  };

  const res = await fetch(`${CJ_BASE_URL}/shopping/order/createOrder`, {
    method: 'POST',
    headers: await cjHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) throw new Error(`CJ order submission failed: ${res.status}`);
  const data = await res.json();
  return data.data.orderId;
}

// Polls tracking status for an order already submitted to CJ.
// Wire this into a scheduled job that updates Order.trackingNumber and
// notifies the customer once tracking is available.
export async function fetchCJTracking(cjOrderId: string) {
  const res = await fetch(`${CJ_BASE_URL}/shopping/order/getTrackInfo?orderId=${cjOrderId}`, {
    headers: await cjHeaders(),
  });
  if (!res.ok) throw new Error(`CJ tracking fetch failed: ${res.status}`);
  const data = await res.json();
  return data.data; // { trackNumber, logisticName, ... }
}
