import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { hsnCode, gstRateOverride } = await req.json();

  const product = await prisma.product.update({
    where: { id },
    data: {
      hsnCode: hsnCode === '' ? null : hsnCode,
      gstRateOverride: gstRateOverride === '' || gstRateOverride === null ? null : gstRateOverride,
    },
    select: { id: true, hsnCode: true, gstRateOverride: true },
  });

  return NextResponse.json({ ok: true, product });
}
