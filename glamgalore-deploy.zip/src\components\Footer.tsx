import Link from 'next/link';
import { CATEGORY_LINKS } from '@/lib/collections';

const INFO_LINKS = [
  { href: '/about', title: 'About us' },
  { href: '/privacy-policy', title: 'Privacy policy' },
  { href: '/terms-of-service', title: 'Terms of service' },
  { href: '/help-center', title: 'Help Center' },
  { href: '/shipping-policy', title: 'Shipping' },
  { href: '/returns-refunds', title: 'Returns & Refunds' },
];

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container footer-columns">
        <div className="footer-col">
          <h3>Info</h3>
          <nav>
            {INFO_LINKS.map((link) => (
              <Link key={link.href} href={link.href}>{link.title}</Link>
            ))}
          </nav>
        </div>

        <div className="footer-col">
          <h3>Shop</h3>
          <nav>
            {CATEGORY_LINKS.map((link) => (
              <Link key={link.href} href={link.href}>{link.title}</Link>
            ))}
          </nav>
        </div>

        <div className="footer-col">
          <h3>Contact</h3>
          <a href="https://wa.me/919769708781">WhatsApp: 9769708781</a>
          <a href="mailto:support@glamgalore.in">support@glamgalore.in</a>
        </div>
      </div>

      <div className="footer-bottom">
        <p>&copy; {new Date().getFullYear()} Glam Galore</p>
      </div>
    </footer>
  );
}
