import { NextRequest, NextResponse } from 'next/server';
import { syncOrderTracking } from '@/lib/tracking-sync';

export async function POST(req: NextRequest, { params }: { params: Promise<{ orderId: string }> }) {
  const { orderId } = await params;
  const result = await syncOrderTracking(orderId);
  return NextResponse.json(result);
}
