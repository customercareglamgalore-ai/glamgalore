// Fires the "product flies to cart" motion on Add to Cart. Grabs whatever
// product photo is currently on screen (product gallery or reel purchase
// panel) and animates a clone of it toward the header's cart icon, then
// bumps the icon and pops a "+1" above it. Falls back to a plain dot if no
// product image is found (e.g. gallery hasn't mounted yet).

const FLY_DURATION_MS = 650;

function findSourceImage(): HTMLImageElement | null {
  return document.querySelector<HTMLImageElement>(
    '.product-gallery .slide img, .reel-viewer-product-header img'
  );
}

export function flyProductToCart() {
  const cartIcon = document.querySelector<HTMLElement>('[data-cart-icon]');
  if (!cartIcon) return;

  const sourceImg = findSourceImage();
  const cartRect = cartIcon.getBoundingClientRect();

  const width = 64;
  const height = 80;
  const sourceRect = sourceImg?.getBoundingClientRect();
  const startX = sourceRect ? sourceRect.left + sourceRect.width / 2 - width / 2 : cartRect.left;
  const startY = sourceRect ? sourceRect.top + sourceRect.height / 2 - height / 2 : cartRect.top;

  const flyer = document.createElement(sourceImg ? 'img' : 'div');
  if (sourceImg) (flyer as HTMLImageElement).src = sourceImg.src;
  flyer.className = 'cart-fly-item';
  flyer.style.left = `${startX}px`;
  flyer.style.top = `${startY}px`;
  flyer.style.width = `${width}px`;
  flyer.style.height = `${height}px`;
  document.body.appendChild(flyer);

  const endX = cartRect.left + cartRect.width / 2 - width / 2;
  const endY = cartRect.top + cartRect.height / 2 - height / 2;

  requestAnimationFrame(() => {
    flyer.style.transform = `translate(${endX - startX}px, ${endY - startY}px) scale(0.15)`;
    flyer.style.opacity = '0.2';
  });

  setTimeout(() => {
    flyer.remove();
    bumpCartIcon(cartIcon);
  }, FLY_DURATION_MS);
}

function bumpCartIcon(cartIcon: HTMLElement) {
  cartIcon.classList.remove('cart-icon-bump');
  // eslint-disable-next-line no-unused-expressions
  void cartIcon.offsetWidth; // restart the animation if it's still running from a rapid double-click
  cartIcon.classList.add('cart-icon-bump');
  setTimeout(() => cartIcon.classList.remove('cart-icon-bump'), 400);

  const rect = cartIcon.getBoundingClientRect();
  const badge = document.createElement('span');
  badge.className = 'cart-plus-one';
  badge.textContent = '+1';
  badge.style.left = `${rect.left + rect.width / 2}px`;
  badge.style.top = `${rect.top}px`;
  document.body.appendChild(badge);
  setTimeout(() => badge.remove(), 900);
}
