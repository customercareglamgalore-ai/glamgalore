import { NextRequest, NextResponse } from 'next/server';
import { COUNTRY_TO_CURRENCY, CHECKOUT_COUNTRIES } from '@/lib/currency';

const COOKIE_NAME = 'geo_currency';
const COOKIE_MAX_AGE = 60 * 60 * 24; // 24h

function matchKnownCountry(name: string | undefined): string {
  if (!name) return 'India';
  const match = CHECKOUT_COUNTRIES.find((c) => c.toLowerCase() === name.toLowerCase());
  return match ?? 'India'; // default to India for anything we don't have a rate/option for
}

export async function GET(req: NextRequest) {
  const cached = req.cookies.get(COOKIE_NAME)?.value;
  if (cached) {
    const [country, currency] = cached.split(':');
    if (country && currency) return NextResponse.json({ country, currency });
  }

  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim();
  let country = 'India';

  if (ip && ip !== '127.0.0.1' && ip !== '::1') {
    try {
      const geoRes = await fetch(`https://ipapi.co/${ip}/json/`, { signal: AbortSignal.timeout(2000) });
      if (geoRes.ok) {
        const data = await geoRes.json();
        country = matchKnownCountry(data.country_name);
      }
    } catch {
      // Geolocation is a best-effort UX nicety, not required — fall back to India silently.
    }
  }

  const currency = COUNTRY_TO_CURRENCY[country] ?? 'USD';

  const res = NextResponse.json({ country, currency });
  res.cookies.set(COOKIE_NAME, `${country}:${currency}`, {
    maxAge: COOKIE_MAX_AGE,
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
  });
  return res;
}
