'use client';

import { useEffect, useRef, useState } from 'react';
import ReelViewer, { type ReelViewerItem } from './ReelViewer';
import { spotlight } from '@/lib/spotlight';

type PopupItem = ReelViewerItem & { label: string };

// Shuffles once per mount so the same reel doesn't always open the sequence.
function shuffledOrder(length: number) {
  const order = [...Array(length).keys()];
  for (let i = order.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  return order;
}

export default function ReelBubbles({ reels }: { reels: PopupItem[] }) {
  const [visibleIndex, setVisibleIndex] = useState<number | null>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const cursorRef = useRef(0);
  const orderRef = useRef<number[]>([]);

  useEffect(() => {
    if (reels.length === 0) return;
    orderRef.current = shuffledOrder(reels.length);
    cursorRef.current = 0;
    spotlight.setReelAvailable(true);

    const unsubscribe = spotlight.subscribe((active) => {
      if (active !== 'reel') {
        setVisibleIndex(null);
        return;
      }
      const order = orderRef.current;
      setVisibleIndex(order[cursorRef.current % order.length]);
      cursorRef.current++;
    });

    return () => {
      spotlight.setReelAvailable(false);
      unsubscribe();
    };
  }, [reels.length]);

  if (reels.length === 0) return null;

  const reel = visibleIndex !== null ? reels[visibleIndex] : null;

  return (
    <>
      {reel && (
        <button
          type="button"
          key={reel.id}
          className="reel-popup-toast"
          aria-label={`Play reel: ${reel.label}`}
          onClick={() => {
            setOpenIndex(visibleIndex);
            setVisibleIndex(null);
          }}
        >
          <span className="reel-popup-media">
            {reel.thumbnailUrl ? (
              <img src={reel.thumbnailUrl} alt="" draggable={false} />
            ) : (
              <video src={reel.videoUrl} muted playsInline autoPlay loop />
            )}
          </span>
        </button>
      )}

      {openIndex !== null && (
        <ReelViewer reels={reels} initialIndex={openIndex} onClose={() => setOpenIndex(null)} />
      )}
    </>
  );
}
