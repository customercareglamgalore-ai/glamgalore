import Reveal from '@/components/Reveal';

export const metadata = {
  title: 'About Us — Glam Galore',
  description: 'Dressing the modern goddess — the story behind Glam Galore.',
};

export default function AboutPage() {
  return (
    <main className="blog-post-page">
      <Reveal className="container blog-post-container">
        <h1>About Us</h1>
        <div className="blog-post-body">
          <p>Thank you, Queen, for visiting Glam Galore.</p>
          <p>
            We&apos;ve started this brand for women to take back their divine feminine power on their own
            terms. We want to use this brand as an opportunity to build community, and use our medium to
            teach and take prowess on your own energy. This is dressing the modern goddess.
          </p>
          <p>
            Besides enjoying the beauty of fashion, our goal is to inspire women to find and cater to their
            higher selves and god complex. A woman&apos;s best accessory is confidence, and we are committed
            to making sure our clothing makes you feel it, and create your own powerful aura. So get dressed
            in Glam Galore, you deserve it!
          </p>
        </div>
      </Reveal>
    </main>
  );
}
