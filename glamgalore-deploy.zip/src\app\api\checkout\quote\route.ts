// Unauthenticated live preview of the tax/shipping/grand-total breakdown, shown
// in the checkout summary before payment. Never persists anything — create-order
// recomputes the same way and is the only route that writes an Order.
import { NextRequest, NextResponse } from 'next/server';
import { buildOrderTax, OrderTaxError } from '@/lib/order-tax';

export async function POST(req: NextRequest) {
  const { cartItems, country, state, discountCode } = await req.json();

  if (!Array.isArray(cartItems) || cartItems.length === 0) {
    return NextResponse.json({ error: 'Cart is empty' }, { status: 400 });
  }

  try {
    const { computation, discountAmount, discountCode: appliedCode, discountError } = await buildOrderTax(
      cartItems,
      { state: state || '', country: country || 'India' },
      discountCode,
    );
    return NextResponse.json({
      ...computation,
      currency: 'INR',
      discountAmount,
      discountCode: appliedCode,
      discountError,
    });
  } catch (err) {
    if (err instanceof OrderTaxError) {
      return NextResponse.json({ error: err.message }, { status: err.status });
    }
    throw err;
  }
}
