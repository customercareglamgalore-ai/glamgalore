import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET() {
  const discounts = await prisma.discountCode.findMany({ orderBy: { createdAt: 'desc' } });
  return NextResponse.json({ discounts });
}

export async function POST(req: NextRequest) {
  const { code, valueType, value, usageLimit } = await req.json();
  if (!code || !valueType || value === undefined || value === null) {
    return NextResponse.json({ error: 'code, valueType and value are required' }, { status: 400 });
  }
  if (valueType !== 'percentage' && valueType !== 'fixed') {
    return NextResponse.json({ error: 'valueType must be "percentage" or "fixed"' }, { status: 400 });
  }

  try {
    const discount = await prisma.discountCode.create({
      data: {
        code: String(code).trim().toUpperCase(),
        valueType,
        value,
        usageLimit: usageLimit === '' || usageLimit === null || usageLimit === undefined ? null : Number(usageLimit),
      },
    });
    return NextResponse.json({ ok: true, discount });
  } catch {
    return NextResponse.json({ error: 'That code already exists' }, { status: 409 });
  }
}

export async function PATCH(req: NextRequest) {
  const { id, active } = await req.json();
  if (!id || typeof active !== 'boolean') {
    return NextResponse.json({ error: 'id and active are required' }, { status: 400 });
  }
  const discount = await prisma.discountCode.update({ where: { id }, data: { active } });
  return NextResponse.json({ ok: true, discount });
}

export async function DELETE(req: NextRequest) {
  const { id } = await req.json();
  if (!id) {
    return NextResponse.json({ error: 'id is required' }, { status: 400 });
  }
  await prisma.discountCode.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
