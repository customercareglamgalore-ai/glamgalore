import './globals.css';
import { Suspense } from 'react';
import { Cormorant_Garamond, EB_Garamond } from 'next/font/google';
import AnnouncementBar from '@/components/AnnouncementBar';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import MetaPixel from '@/components/MetaPixel';
import DivineNotes from '@/components/DivineNotes';

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-cormorant',
  display: 'swap',
});

const ebGaramond = EB_Garamond({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  style: ['normal', 'italic'],
  variable: '--font-eb-garamond',
  display: 'swap',
});

export const metadata = {
  metadataBase: new URL('https://glamgalore.in'),
  title: 'Glam Galore | The Divine Feminine Fashion',
  description:
    'Curated styles to empower and embody the divine feminine energy, and elevate the confidence of every woman. Dress like the goddess that you are with Glam Galore — the new luxury at affordable prices. Free shipping worldwide.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${cormorant.variable} ${ebGaramond.variable}`}>
      <body>
        <Suspense fallback={null}>
          <MetaPixel />
        </Suspense>
        <AnnouncementBar />
        <Header />
        {children}
        <Footer />
        <WhatsAppButton />
        <DivineNotes />
      </body>
    </html>
  );
}
