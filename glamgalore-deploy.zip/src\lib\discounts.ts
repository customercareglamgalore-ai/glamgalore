// Resolves a checkout discount code against the order subtotal. Percentage
// codes are a % of subtotal; fixed codes are capped at subtotal so a
// discount can never make the pre-shipping total negative. Called from both
// the quote preview and order creation so the two stay consistent — usage
// is only ever incremented from checkout/verify, after payment succeeds.
import { prisma } from '@/lib/db';

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export type DiscountResolution = { code: string; amount: number } | { error: string };

export async function resolveDiscount(
  rawCode: string | null | undefined,
  subtotal: number,
): Promise<DiscountResolution | null> {
  const code = (rawCode || '').trim().toUpperCase();
  if (!code) return null;

  const discount = await prisma.discountCode.findUnique({ where: { code } });
  if (!discount || !discount.active) {
    return { error: 'That discount code is invalid or has expired.' };
  }
  if (discount.usageLimit !== null && discount.usageCount >= discount.usageLimit) {
    return { error: 'That discount code has already been used up.' };
  }

  const amount =
    discount.valueType === 'percentage'
      ? round2(subtotal * (Number(discount.value) / 100))
      : Math.min(round2(Number(discount.value)), subtotal);

  return { code: discount.code, amount: Math.max(0, amount) };
}

export async function recordDiscountUsage(code: string | null | undefined) {
  if (!code) return;
  await prisma.discountCode.updateMany({ where: { code }, data: { usageCount: { increment: 1 } } });
}
