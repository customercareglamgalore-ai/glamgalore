'use client';

import { useEffect, useRef, useState } from 'react';

const MESSAGES = [
  'Free shipping worldwide \u{1F30D}',
  'Hassle-free returns',
];

export default function AnnouncementBar() {
  const [index, setIndex] = useState(0);
  const [slideWidth, setSlideWidth] = useState(0);
  const barRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function measure() {
      if (barRef.current) setSlideWidth(barRef.current.offsetWidth);
    }
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((i) => (i + 1) % MESSAGES.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="announcement-bar" ref={barRef}>
      <div
        className="announcement-track"
        style={{ transform: `translateX(-${index * slideWidth}px)` }}
      >
        {MESSAGES.map((msg) => (
          <div className="announcement-slide" key={msg} style={{ width: slideWidth || undefined }}>
            {msg}
          </div>
        ))}
      </div>
    </div>
  );
}
