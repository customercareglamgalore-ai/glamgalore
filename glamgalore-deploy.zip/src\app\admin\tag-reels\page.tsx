'use client';

import { useEffect, useState } from 'react';

type Product = { handle: string; title: string; price: string; images: string[] };
type TaggedReel = {
  id: string;
  videoUrl: string;
  thumbnailUrl: string | null;
  position: number;
  productHandle: string;
  productTitle: string;
  featuredHome: boolean;
};

export default function TagReelsPage() {
  const [files, setFiles] = useState<string[] | null>(null);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Product[]>([]);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [taggedReels, setTaggedReels] = useState<TaggedReel[]>([]);

  function refreshFiles() {
    fetch('/api/admin/reels-inbox')
      .then((r) => r.json())
      .then((data) => setFiles(data.files));
  }

  function refreshTagged() {
    fetch('/api/admin/tagged-reels')
      .then((r) => r.json())
      .then((data) => setTaggedReels(data.reels));
  }

  useEffect(() => {
    refreshFiles();
    refreshTagged();
  }, []);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    const timer = setTimeout(() => {
      fetch(`/api/search?q=${encodeURIComponent(query)}`)
        .then((r) => r.json())
        .then((data) => setResults(data.products));
    }, 250);
    return () => clearTimeout(timer);
  }, [query]);

  const currentFile = files && files.length > 0 ? files[0] : null;

  async function tagCurrent(productHandle: string) {
    if (!currentFile) return;
    setSaving(true);
    const res = await fetch('/api/admin/tag-reel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename: currentFile, productHandle }),
    });
    setSaving(false);
    if (res.ok) {
      setMessage(`Tagged to ${productHandle}`);
      setFiles((f) => (f ? f.slice(1) : f));
      setQuery('');
      setResults([]);
      refreshTagged();
    } else {
      const data = await res.json();
      setMessage(`Error: ${data.error}`);
    }
  }

  async function skipCurrent() {
    if (!currentFile) return;
    setSaving(true);
    await fetch('/api/admin/tag-reel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename: currentFile, skip: true }),
    });
    setSaving(false);
    setFiles((f) => (f ? f.slice(1) : f));
    setQuery('');
    setResults([]);
    setMessage('Skipped');
  }

  async function undoTag(reelId: string) {
    setSaving(true);
    await fetch('/api/admin/untag-reel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reelId }),
    });
    setSaving(false);
    setMessage('Undone — video moved back to the queue');
    refreshFiles();
    refreshTagged();
  }

  async function toggleFeatured(reelId: string, featuredHome: boolean) {
    setTaggedReels((reels) => reels.map((r) => (r.id === reelId ? { ...r, featuredHome } : r)));
    await fetch('/api/admin/toggle-featured', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reelId, featuredHome }),
    });
  }

  async function reorder(reelId: string, direction: 'up' | 'down') {
    setTaggedReels((reels) => {
      const index = reels.findIndex((r) => r.id === reelId);
      const swapIndex = direction === 'up' ? index - 1 : index + 1;
      if (index === -1 || swapIndex < 0 || swapIndex >= reels.length) return reels;
      const next = [...reels];
      [next[index], next[swapIndex]] = [next[swapIndex], next[index]];
      return next;
    });
    await fetch('/api/admin/reorder-reel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reelId, direction }),
    });
  }

  if (files === null) {
    return <main style={{ padding: 40 }}>Loading...</main>;
  }

  return (
    <main style={{ padding: 40, maxWidth: 480, margin: '0 auto', fontFamily: 'system-ui' }}>
      <h1 style={{ fontSize: 20 }}>Tag reels to products</h1>

      {files.length === 0 ? (
        <p>All done — no untagged videos left in public/reels-inbox.</p>
      ) : (
        <>
          <p style={{ color: '#666', marginBottom: 20 }}>{files.length} remaining</p>

          <video
            key={currentFile}
            src={`/reels-inbox/${currentFile}`}
            controls
            autoPlay
            muted
            loop
            playsInline
            style={{ width: '100%', maxWidth: 300, aspectRatio: '9/16', background: '#000', display: 'block', margin: '0 auto 16px' }}
          />

          <p style={{ fontSize: 12, color: '#999', wordBreak: 'break-all', textAlign: 'center' }}>{currentFile}</p>

          <input
            placeholder="Search product title..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            disabled={saving}
            style={{ width: '100%', padding: 10, margin: '16px 0 8px', border: '1px solid #ccc', fontSize: 14 }}
          />

          <div>
            {results.map((p) => (
              <button
                key={p.handle}
                onClick={() => tagCurrent(p.handle)}
                disabled={saving}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                  width: '100%',
                  padding: 8,
                  marginBottom: 6,
                  border: '1px solid #eee',
                  background: '#fff',
                  cursor: 'pointer',
                  textAlign: 'left',
                }}
              >
                {p.images[0] && <img src={p.images[0]} alt={p.title} style={{ width: 36, height: 45, objectFit: 'cover' }} />}
                <span>
                  <span style={{ display: 'block', fontSize: 13 }}>{p.title}</span>
                  <span style={{ display: 'block', fontSize: 12, color: '#777' }}>₹{p.price}</span>
                </span>
              </button>
            ))}
          </div>

          <button
            onClick={skipCurrent}
            disabled={saving}
            style={{ width: '100%', padding: 10, marginTop: 12, background: '#eee', border: 'none', cursor: 'pointer' }}
          >
            Skip (not a product reel)
          </button>
        </>
      )}

      {message && <p style={{ marginTop: 12, fontSize: 13, color: '#666' }}>{message}</p>}

      {taggedReels.length > 0 && (
        <div style={{ marginTop: 40, borderTop: '1px solid #eee', paddingTop: 20 }}>
          <h2 style={{ fontSize: 15, marginBottom: 4 }}>Tagged so far ({taggedReels.length})</h2>
          <p style={{ fontSize: 12, color: '#999', marginBottom: 12 }}>
            This is the order they play in on the homepage. Use the arrows to reorder, and uncheck
            &quot;Home&quot; to keep a reel on its product page only.
          </p>
          {taggedReels.map((r, i) => (
            <div
              key={r.id}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: '8px 0',
                borderBottom: '1px solid #f3f3f3',
                fontSize: 13,
              }}
            >
              <video
                src={r.thumbnailUrl || `${r.videoUrl}#t=0.1`}
                muted
                playsInline
                preload="metadata"
                style={{ width: 34, height: 42, objectFit: 'cover', background: '#000', flexShrink: 0 }}
              />
              <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {r.productTitle}
                <span style={{ color: '#999' }}> — {r.videoUrl.split('/').pop()}</span>
              </span>
              <div style={{ display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
                <button
                  onClick={() => reorder(r.id, 'up')}
                  disabled={i === 0}
                  aria-label="Move up"
                  style={{ border: 'none', background: 'none', cursor: i === 0 ? 'default' : 'pointer', opacity: i === 0 ? 0.3 : 1, lineHeight: 1, padding: '0 4px' }}
                >
                  ▲
                </button>
                <button
                  onClick={() => reorder(r.id, 'down')}
                  disabled={i === taggedReels.length - 1}
                  aria-label="Move down"
                  style={{ border: 'none', background: 'none', cursor: i === taggedReels.length - 1 ? 'default' : 'pointer', opacity: i === taggedReels.length - 1 ? 0.3 : 1, lineHeight: 1, padding: '0 4px' }}
                >
                  ▼
                </button>
              </div>
              <label style={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={r.featuredHome}
                  onChange={(e) => toggleFeatured(r.id, e.target.checked)}
                />
                Home
              </label>
              <button
                onClick={() => undoTag(r.id)}
                disabled={saving}
                style={{ flexShrink: 0, padding: '4px 10px', background: '#eee', border: 'none', cursor: 'pointer', fontSize: 12 }}
              >
                Undo
              </button>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
