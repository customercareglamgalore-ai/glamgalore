import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { ORDER_REPORT_COLUMNS, buildOrderReportRows, ordersToXlsxBuffer } from '@/lib/reports/orders-report';
import { toCsv } from '@/lib/reports/csv';

export async function GET(req: NextRequest) {
  const params = req.nextUrl.searchParams;
  const from = params.get('from') ? new Date(params.get('from')!) : new Date(0);
  const to = params.get('to') ? new Date(params.get('to')!) : new Date();
  const format = params.get('format') === 'xlsx' ? 'xlsx' : 'csv';

  const orders = await prisma.order.findMany({
    where: { createdAt: { gte: from, lte: to } },
    include: { items: { include: { product: true } }, customer: true },
    orderBy: { createdAt: 'desc' },
  });

  const rows = buildOrderReportRows(orders);
  const filename = `orders-report-${from.toISOString().slice(0, 10)}-to-${to.toISOString().slice(0, 10)}`;

  if (format === 'xlsx') {
    const buffer = await ordersToXlsxBuffer(rows);
    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="${filename}.xlsx"`,
      },
    });
  }

  const csv = toCsv(ORDER_REPORT_COLUMNS, rows);
  return new NextResponse(csv, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment; filename="${filename}.csv"`,
    },
  });
}
