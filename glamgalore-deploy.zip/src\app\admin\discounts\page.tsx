'use client';

import { useEffect, useState } from 'react';

type Discount = {
  id: string;
  code: string;
  valueType: 'percentage' | 'fixed';
  value: string;
  active: boolean;
  usageLimit: number | null;
  usageCount: number;
};

const inputStyle: React.CSSProperties = { padding: 8, border: '1px solid #ccc', fontSize: 13, width: '100%' };
const btnStyle: React.CSSProperties = { padding: '8px 16px', background: '#000', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 13 };

export default function AdminDiscountsPage() {
  const [discounts, setDiscounts] = useState<Discount[]>([]);
  const [newCode, setNewCode] = useState({ code: '', valueType: 'percentage' as 'percentage' | 'fixed', value: '', usageLimit: '' });
  const [error, setError] = useState<string | null>(null);

  function refresh() {
    fetch('/api/admin/discounts')
      .then((r) => r.json())
      .then((data) => setDiscounts(data.discounts));
  }

  useEffect(() => {
    refresh();
  }, []);

  async function addDiscount() {
    if (!newCode.code || !newCode.value) return;
    setError(null);
    const res = await fetch('/api/admin/discounts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newCode),
    });
    if (!res.ok) {
      const { error: message } = await res.json();
      setError(message || 'Could not create code');
      return;
    }
    setNewCode({ code: '', valueType: 'percentage', value: '', usageLimit: '' });
    refresh();
  }

  async function toggleActive(id: string, active: boolean) {
    setDiscounts((rows) => rows.map((d) => (d.id === id ? { ...d, active } : d)));
    await fetch('/api/admin/discounts', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, active }),
    });
  }

  async function deleteDiscount(id: string) {
    await fetch('/api/admin/discounts', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    refresh();
  }

  return (
    <main style={{ padding: 40, maxWidth: 720, margin: '0 auto', fontFamily: 'system-ui' }}>
      <h1 style={{ fontSize: 20 }}>Discount Codes</h1>
      <p style={{ fontSize: 12, color: '#999' }}>
        Applied to the order subtotal at checkout, before shipping. Percentage and fixed-amount codes are both
        supported; fixed amounts are capped at the subtotal.
      </p>

      {discounts.map((d) => (
        <div key={d.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 0', borderBottom: '1px solid #f3f3f3', fontSize: 13 }}>
          <span style={{ flex: 1, fontWeight: 600 }}>{d.code}</span>
          <span style={{ width: 100 }}>{d.valueType === 'percentage' ? `${d.value}%` : `₹${d.value}`}</span>
          <span style={{ width: 90, color: '#999' }}>
            {d.usageCount}{d.usageLimit !== null ? ` / ${d.usageLimit}` : ' uses'}
          </span>
          <label style={{ display: 'flex', alignItems: 'center', gap: 4, width: 70 }}>
            <input type="checkbox" checked={d.active} onChange={(e) => toggleActive(d.id, e.target.checked)} />
            Active
          </label>
          <button onClick={() => deleteDiscount(d.id)} style={{ border: 'none', background: '#eee', padding: '4px 10px', cursor: 'pointer', fontSize: 12 }}>
            Delete
          </button>
        </div>
      ))}

      <div style={{ marginTop: 20, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
        <input style={inputStyle} placeholder="CODE" value={newCode.code} onChange={(e) => setNewCode({ ...newCode, code: e.target.value })} />
        <select style={inputStyle} value={newCode.valueType} onChange={(e) => setNewCode({ ...newCode, valueType: e.target.value as 'percentage' | 'fixed' })}>
          <option value="percentage">% off</option>
          <option value="fixed">₹ off</option>
        </select>
        <input style={inputStyle} placeholder="Value" type="number" value={newCode.value} onChange={(e) => setNewCode({ ...newCode, value: e.target.value })} />
        <input style={inputStyle} placeholder="Usage limit (blank = unlimited)" type="number" value={newCode.usageLimit} onChange={(e) => setNewCode({ ...newCode, usageLimit: e.target.value })} />
        <button style={btnStyle} onClick={addDiscount}>Add</button>
      </div>
      {error && <p style={{ color: '#e22120', fontSize: 13, marginTop: 8 }}>{error}</p>}
    </main>
  );
}
