// Shared cart-count state, synced across components via a custom event since
// cart mutations happen in localStorage (no server state) and the native
// `storage` event only fires across tabs, not within the same one.

export const CART_UPDATED_EVENT = 'cart:updated';

type CartItem = { quantity: number };

export function getCartCount(): number {
  if (typeof window === 'undefined') return 0;
  const items = JSON.parse(localStorage.getItem('cart') || '[]') as CartItem[];
  return items.reduce((sum, item) => sum + (item.quantity || 0), 0);
}

export function notifyCartUpdated() {
  window.dispatchEvent(new Event(CART_UPDATED_EVENT));
}
