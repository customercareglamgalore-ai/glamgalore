import { prisma } from '@/lib/db';
import Link from 'next/link';
import Reveal from '@/components/Reveal';

export const metadata = { title: 'Blog — Glam Galore' };
export const dynamic = 'force-dynamic';

export default async function BlogIndexPage() {
  const posts = await prisma.blogPost.findMany({ orderBy: { publishedAt: 'desc' } });

  return (
    <main className="container blog-index-page">
      <Reveal className="blog-grid">
        {posts.map((post) => (
          <Link key={post.handle} href={`/blog/${post.handle}`} className="blog-card">
            <div className="blog-card-image">
              {post.imageUrl && <img src={post.imageUrl} alt={post.title} loading="lazy" />}
            </div>
            <p className="blog-card-title">{post.title}</p>
            {post.summary && <p className="blog-card-summary">{post.summary}</p>}
          </Link>
        ))}
      </Reveal>
    </main>
  );
}
