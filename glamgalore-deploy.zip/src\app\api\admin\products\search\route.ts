import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

// Lists products for the admin tax editor, optionally filtered by a title/handle search term.
export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q')?.trim();

  const products = await prisma.product.findMany({
    where: q
      ? {
          OR: [
            { title: { contains: q, mode: 'insensitive' } },
            { handle: { contains: q, mode: 'insensitive' } },
          ],
        }
      : undefined,
    select: { id: true, handle: true, title: true, type: true, price: true, hsnCode: true, gstRateOverride: true },
    orderBy: { title: 'asc' },
    take: 50,
  });

  return NextResponse.json({
    products: products.map((p) => ({
      ...p,
      price: p.price?.toString() ?? null,
      gstRateOverride: p.gstRateOverride?.toString() ?? null,
    })),
  });
}
