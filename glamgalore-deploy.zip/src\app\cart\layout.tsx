export const metadata = {
  title: 'Your Cart — Glam Galore',
  robots: { index: false, follow: false },
};

export default function CartLayout({ children }: { children: React.ReactNode }) {
  return children;
}
