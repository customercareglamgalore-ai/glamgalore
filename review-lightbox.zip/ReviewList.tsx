'use client';

import { useState } from 'react';
import { createPortal } from 'react-dom';

type Review = {
  id: string;
  authorName: string;
  rating: number;
  title?: string | null;
  body: string;
  imageUrls: string[];
  verified: boolean;
};

export default function ReviewList({ reviews }: { reviews: Review[] }) {
  const [openImage, setOpenImage] = useState<string | null>(null);

  if (reviews.length === 0) {
    return <p className="empty-state">No reviews yet — be the first to share yours.</p>;
  }

  return (
    <>
      <ul className="review-list">
        {reviews.map((r) => (
          <li key={r.id} className="review-card">
            <div className="review-header">
              <span className="stars">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</span>
              <strong>{r.authorName}</strong>
              {r.verified && <span className="verified-badge">Verified purchase</span>}
            </div>
            {r.title && <h4>{r.title}</h4>}
            <p>{r.body}</p>
            {r.imageUrls.length > 0 && (
              <div className="review-images">
                {r.imageUrls.map((url, i) => (
                  <img
                    key={i}
                    src={url}
                    alt="Customer photo"
                    onClick={() => setOpenImage(url)}
                    style={{ cursor: 'zoom-in' }}
                  />
                ))}
              </div>
            )}
          </li>
        ))}
      </ul>

      {openImage &&
        createPortal(
          <div
            role="dialog"
            aria-modal="true"
            onClick={() => setOpenImage(null)}
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 1000,
              background: 'rgba(0, 0, 0, 0.85)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 24,
            }}
          >
            <button
              type="button"
              aria-label="Close"
              onClick={() => setOpenImage(null)}
              style={{
                position: 'absolute',
                top: 20,
                right: 20,
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                color: '#fff',
              }}
            >
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                <line x1="5" y1="5" x2="19" y2="19" />
                <line x1="19" y1="5" x2="5" y2="19" />
              </svg>
            </button>
            <img
              src={openImage}
              alt="Customer photo, enlarged"
              onClick={(e) => e.stopPropagation()}
              style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
            />
          </div>,
          document.body
        )}
    </>
  );
}
