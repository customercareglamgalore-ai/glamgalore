'use client';

import { useEffect, useRef, useState } from 'react';
import ReelViewer, { type ReelViewerItem } from './ReelViewer';

function discountPercent(price: string, compareAtPrice?: string | null) {
  if (!compareAtPrice) return null;
  const p = Number(price);
  const c = Number(compareAtPrice);
  if (!p || !c || c <= p) return null;
  return Math.round((1 - p / c) * 100);
}

function ReelThumbVideo({ src, title }: { src: string; title: string }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [shouldLoad, setShouldLoad] = useState(false);

  // With dozens of these on the homepage, loading every video's data upfront
  // would be heavy — only start fetching once a thumb is close to scrolling
  // into view.
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const loadObserver = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setShouldLoad(true);
          loadObserver.disconnect();
        }
      },
      { rootMargin: '400px' }
    );
    loadObserver.observe(video);
    return () => loadObserver.disconnect();
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const playObserver = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          video.play().catch(() => {});
        } else {
          video.pause();
        }
      },
      { threshold: 0.6 }
    );
    playObserver.observe(video);
    return () => playObserver.disconnect();
  }, []);

  // No thumbnail image exists for these reels, so the bare <video> is the
  // thumbnail — `preload="metadata"` alone doesn't reliably paint a visible
  // frame in every browser, leaving it solid black until playback starts.
  // Nudging currentTime once data is available forces a real frame to render.
  function handleLoadedData() {
    const video = videoRef.current;
    if (video && video.currentTime === 0) video.currentTime = 0.1;
  }

  return (
    <video
      ref={videoRef}
      src={shouldLoad ? src : undefined}
      muted
      loop
      playsInline
      preload={shouldLoad ? 'auto' : 'none'}
      onLoadedData={handleLoadedData}
      aria-label={title}
    />
  );
}

export default function ReelStrip({ reels, minimal = false }: { reels: ReelViewerItem[]; minimal?: boolean }) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const dragState = useRef({ dragging: false, startX: 0, startScrollLeft: 0, moved: 0 });

  function handlePointerDown(e: React.PointerEvent<HTMLDivElement>) {
    const track = trackRef.current;
    if (!track) return;
    dragState.current = { dragging: true, startX: e.clientX, startScrollLeft: track.scrollLeft, moved: 0 };
    track.setPointerCapture(e.pointerId);
    track.classList.add('reel-strip--dragging');
  }

  function handlePointerMove(e: React.PointerEvent<HTMLDivElement>) {
    const track = trackRef.current;
    const state = dragState.current;
    if (!track || !state.dragging) return;
    const delta = e.clientX - state.startX;
    track.scrollLeft = state.startScrollLeft - delta;
    state.moved = Math.abs(delta);
  }

  function handlePointerUp(e: React.PointerEvent<HTMLDivElement>) {
    const track = trackRef.current;
    if (!track) return;
    dragState.current.dragging = false;
    track.releasePointerCapture(e.pointerId);
    track.classList.remove('reel-strip--dragging');
  }

  function handleThumbClick(index: number, e: React.MouseEvent) {
    if (dragState.current.moved > 6) {
      e.preventDefault();
      return;
    }
    setOpenIndex(index);
  }

  return (
    <>
      <div
        className="reel-strip"
        ref={trackRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
      >
        {reels.map((reel, i) => {
          const discount = discountPercent(reel.product.price, reel.product.compareAtPrice);
          return (
            <button
              type="button"
              key={reel.id}
              className="reel-thumb"
              onClick={(e) => handleThumbClick(i, e)}
              aria-label={`Play reel: ${reel.product.title}`}
            >
              <span className="reel-thumb-media">
                {reel.thumbnailUrl ? (
                  <img src={reel.thumbnailUrl} alt={reel.product.title} loading="lazy" draggable={false} />
                ) : (
                  <ReelThumbVideo src={reel.videoUrl} title={reel.product.title} />
                )}
                {!minimal && discount && <span className="reel-thumb-badge">{discount}% OFF</span>}
                <span className="reel-thumb-play">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
                    <polygon points="6 4 20 12 6 20" />
                  </svg>
                </span>
                {!minimal && (
                  <span className="reel-thumb-photo-icon" aria-hidden="true">
                    {reel.product.imageUrl ? (
                      <img src={reel.product.imageUrl} alt="" draggable={false} />
                    ) : (
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="3" y="3" width="18" height="18" rx="2" />
                        <circle cx="8.5" cy="8.5" r="1.5" />
                        <polyline points="21 15 16 10 5 21" />
                      </svg>
                    )}
                  </span>
                )}
              </span>
              {!minimal && (
                <>
                  <span className="reel-thumb-title">{reel.product.title}</span>
                  <span className="reel-thumb-price">
                    {discount && <span className="reel-thumb-compare">₹{reel.product.compareAtPrice}</span>}
                    ₹{reel.product.price}
                  </span>
                </>
              )}
            </button>
          );
        })}
      </div>

      {openIndex !== null && (
        <ReelViewer reels={reels} initialIndex={openIndex} onClose={() => setOpenIndex(null)} />
      )}
    </>
  );
}
