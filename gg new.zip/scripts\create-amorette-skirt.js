// One-off: creates the "AMORETTE Skirt" product — a beaded embroidered
// sequin maxi skirt in 4 colors (Pink, Blue, Rose Red, Orange) x 4 sizes
// (S/M/L/XL), sourced from CJ Dropshipping. Description/features are
// placeholders — update once real copy is provided.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Pink: { S: 'CJQZ305283605EV', M: 'CJQZ305283606FU', L: 'CJQZ305283607GT', XL: 'CJQZ305283608HS' },
  Blue: { S: 'CJQZ305283601AZ', M: 'CJQZ305283602BY', L: 'CJQZ305283603CX', XL: 'CJQZ305283604DW' },
  'Rose Red': { S: 'CJQZ305283613MN', M: 'CJQZ305283614NM', L: 'CJQZ305283615OL', XL: 'CJQZ305283616PK' },
  Orange: { S: 'CJQZ305283617QJ', M: 'CJQZ305283618RI', L: 'CJQZ305283619SH', XL: 'CJQZ305283620TG' },
};

const HERO_IMAGE = {
  Pink: '/products/amorette-skirt/amorette-skirt-1.png',
  Blue: '/products/amorette-skirt/amorette-skirt-3.png',
  'Rose Red': '/products/amorette-skirt/amorette-skirt-5.png',
  Orange: '/products/amorette-skirt/amorette-skirt-7.png',
};

const GALLERY_IMAGES = [
  '/products/amorette-skirt/amorette-skirt-1.png', // Pink front
  '/products/amorette-skirt/amorette-skirt-2.png', // Pink back
  '/products/amorette-skirt/amorette-skirt-3.png', // Blue front
  '/products/amorette-skirt/amorette-skirt-4.png', // Blue back
  '/products/amorette-skirt/amorette-skirt-5.png', // Rose Red front
  '/products/amorette-skirt/amorette-skirt-6.png', // Rose Red back
  '/products/amorette-skirt/amorette-skirt-7.png', // Orange front
  '/products/amorette-skirt/amorette-skirt-8.png', // Orange back
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'amorette-skirt' } });
  if (existing) {
    console.error('A product with handle "amorette-skirt" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'amorette-skirt',
      title: 'AMORETTE Skirt',
      descriptionHtml: '<p>The Amorette Skirt features delicate floral embellishments, shimmering beadwork and a flattering maxi silhouette, perfect for vacations, parties and evening glamour.</p>',
      description: 'The Amorette Skirt features delicate floral embellishments, shimmering beadwork and a flattering maxi silhouette, perfect for vacations, parties and evening glamour.',
      features: [
        'Material: Polyester',
        'Hand-embellished floral sequin and bead embroidery',
        'Figure-skimming maxi silhouette with a flattering fit',
        'Lightweight mesh overlay with comfortable lining',
        'High-rise waistband for a sleek, sculpted look',
      ],
      type: 'Skirt',
      price: 4999,
      status: 'active',
      isDropshipped: true,
      collections: ['spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created AMORETTE Skirt:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
