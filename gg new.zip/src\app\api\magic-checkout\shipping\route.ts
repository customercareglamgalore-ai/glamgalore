import { NextRequest, NextResponse } from 'next/server';

// Fresh URL for the same shipping-info logic as
// /api/magic-checkout/shipping-info — that older path kept showing a ₹379
// "Standard" delivery fee in the live checkout on every address tested, even
// after the response was confirmed correct and Razorpay's own Dashboard
// preview showed free shipping. Registering a brand-new URL rules out
// anything cached server-side against the old path specifically. Called
// directly by Razorpay's servers — must stay publicly accessible with no
// auth. This store ships free worldwide with no COD, so every address is
// simply serviceable with zero shipping fee.
type ShippingInfoRequest = {
  order_id: string;
  razorpay_order_id: string;
  email?: string;
  contact: string;
  addresses: { id: string; zipcode: string; state_code?: string; country: string }[];
};

export async function POST(req: NextRequest) {
  const body: ShippingInfoRequest = await req.json();

  const addresses = (body.addresses || []).map((address) => ({
    id: address.id,
    serviceable: true,
    cod_serviceable: false,
    shipping_fee: 0,
    cod_fee: 0,
    shipping_methods: [
      { id: 'standard', name: 'Standard', shipping_fee: 0, cod_fee: 0 },
    ],
  }));

  return NextResponse.json({ addresses });
}
