import { NextRequest, NextResponse } from 'next/server';

// Called directly by Razorpay's servers — must stay publicly accessible with
// no auth. This store ships free worldwide with no COD, so every address
// gets a single, always-serviceable, zero-fee "Standard" shipping method.
//
// Response shape confirmed directly by Razorpay support (ticket #19996154)
// after comparing our actual response against their expected schema: the
// `serviceable`/`cod` flags belong on each entry inside `shipping_methods`,
// not on the address itself — our previous address-level placement of those
// fields is what was causing checkout to fall back to a default paid rate.
type ShippingInfoRequest = {
  order_id: string;
  razorpay_order_id: string;
  email?: string;
  contact: string;
  addresses: { id: string; zipcode: string; state_code?: string; country: string }[];
};

export async function POST(req: NextRequest) {
  const body: ShippingInfoRequest = await req.json();

  const addresses = (body.addresses || []).map((address) => ({
    id: address.id,
    zipcode: address.zipcode,
    state_code: address.state_code,
    country: address.country,
    shipping_methods: [
      {
        id: 'standard',
        description: 'Free shipping',
        name: 'Standard Delivery',
        serviceable: true,
        shipping_fee: 0,
        cod: false,
        cod_fee: 0,
      },
    ],
  }));

  return NextResponse.json({ addresses });
}
