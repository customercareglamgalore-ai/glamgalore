// One-off: tests each SKU individually against CJ's read-only freight
// calculation endpoint, to isolate which item in a bulk order is invalid
// (e.g. delisted) without ever calling the actual order-creation endpoint.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const CJ_BASE_URL = 'https://developers.cjdropshipping.com/api2.0/v1';
const REFRESH_MARGIN_MS = 24 * 60 * 60 * 1000;

async function loginWithCredentials() {
  const res = await fetch(`${CJ_BASE_URL}/authentication/getAccessToken`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: process.env.CJ_EMAIL, password: process.env.CJ_API_KEY }),
  });
  const data = await res.json();
  if (!data.result) throw new Error(`CJ login failed: ${data.code} ${data.message}`);
  return data.data;
}

async function refreshWithToken(refreshToken) {
  const res = await fetch(`${CJ_BASE_URL}/authentication/refreshAccessToken`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refreshToken }),
  });
  const data = await res.json();
  if (!data.result) throw new Error(`CJ refresh failed: ${data.code} ${data.message}`);
  return data.data;
}

async function getValidAccessToken() {
  const settings = await prisma.storeSettings.findUnique({ where: { id: 'singleton' } });
  const stillValid = settings?.cjAccessToken && settings.cjAccessTokenExpiresAt && settings.cjAccessTokenExpiresAt.getTime() - Date.now() > REFRESH_MARGIN_MS;
  if (stillValid) return settings.cjAccessToken;
  const refreshStillValid = settings?.cjRefreshToken && settings.cjRefreshTokenExpiresAt && settings.cjRefreshTokenExpiresAt.getTime() - Date.now() > REFRESH_MARGIN_MS;
  const result = refreshStillValid ? await refreshWithToken(settings.cjRefreshToken) : await loginWithCredentials();
  await prisma.storeSettings.upsert({
    where: { id: 'singleton' },
    create: { id: 'singleton', cjAccessToken: result.accessToken, cjRefreshToken: result.refreshToken, cjAccessTokenExpiresAt: new Date(result.accessTokenExpiryDate), cjRefreshTokenExpiresAt: new Date(result.refreshTokenExpiryDate) },
    update: { cjAccessToken: result.accessToken, cjRefreshToken: result.refreshToken, cjAccessTokenExpiresAt: new Date(result.accessTokenExpiryDate), cjRefreshTokenExpiresAt: new Date(result.refreshTokenExpiryDate) },
  });
  return result.accessToken;
}

async function main() {
  const orderId = process.argv[2];
  if (!orderId) { console.error('Usage: node scripts/diagnose-cj-skus.js <orderId>'); process.exit(1); }

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: { include: { product: true, variant: true } } } });
  const products = order.items.filter((i) => /^cj/i.test(i.variant?.sku || '')).map((i) => ({ handle: i.product.handle, sku: i.variant.sku }));

  const token = await getValidAccessToken();
  const headers = { 'CJ-Access-Token': token, 'Content-Type': 'application/json' };

  for (const p of products) {
    const res = await fetch(`${CJ_BASE_URL}/logistic/freightCalculate`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ startCountryCode: 'CN', endCountryCode: 'IN', products: [{ quantity: 1, variantSku: p.sku }] }),
    });
    const data = await res.json();
    const ok = data.result && data.data?.length > 0;
    console.log(`${ok ? 'OK  ' : 'FAIL'} ${p.handle} (${p.sku})${ok ? '' : ' -> ' + (data.message || JSON.stringify(data))}`);
  }
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
