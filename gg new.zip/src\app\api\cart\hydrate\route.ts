import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

// Takes the lightweight cart stored in localStorage (just productId + quantity)
// and returns it enriched with current title/price/image — so the cart page
// never shows stale prices from whenever the item was added.
export async function POST(req: NextRequest) {
  const { items } = await req.json();

  const hydrated = await Promise.all(
    items.map(async (item: { productId: string; variantId?: string; quantity: number }) => {
      const product = await prisma.product.findUnique({
        where: { id: item.productId },
        include: { images: { take: 1, orderBy: { position: 'asc' } } },
      });
      if (!product) return null;

      const variant = item.variantId
        ? await prisma.productVariant.findUnique({ where: { id: item.variantId } })
        : null;
      const variantLabel = variant
        ? [variant.optionValue, variant.option2Value].filter(Boolean).join(' / ')
        : undefined;

      return {
        productId: product.id,
        variantId: item.variantId,
        quantity: item.quantity,
        title: product.title,
        handle: product.handle,
        variantLabel,
        price: (variant?.price ?? product.price)?.toString(),
        imageUrl: product.images[0]?.url,
      };
    })
  );

  return NextResponse.json({ items: hydrated.filter(Boolean) });
}
