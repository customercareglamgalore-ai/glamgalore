// Two independent gates live here:
//  1. /admin/* and /api/admin/* — HTTP Basic Auth (only safe over HTTPS).
//  2. The rest of the site — an optional, admin-togglable "coming soon"
//     password wall (StoreSettings.siteLocked). Search/social crawlers are
//     explicitly let through so indexing and the Meta catalog feed can keep
//     working while human visitors see the gate. Toggle from /admin/settings.
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { prisma } from '@/lib/db';

export const runtime = 'nodejs';

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};

const CRAWLER_UA =
  /googlebot|bingbot|duckduckbot|slurp|yandexbot|baiduspider|facebookexternalhit|meta-externalagent|meta-externalfetcher|applebot|twitterbot|linkedinbot|pinterest/i;

const ALWAYS_ALLOWED_PATHS = new Set([
  '/sitemap.xml', '/robots.txt', '/feed.xml', '/site-locked', '/api/site-unlock',
  '/api/magic-checkout/shipping-info', // called directly by Razorpay's servers — must stay reachable regardless of site lock
  '/api/magic-checkout/shipping', // same — fresh URL replacing shipping-info above, to rule out server-side caching tied to the old path
  '/api/webhooks/razorpay', // same — Razorpay's servers call this directly, no unlock cookie involved
  '/api/checkout/promotions', // same — Magic Checkout's "Get Promotions" server-to-server call
  '/api/checkout/apply-promotion', // same — Magic Checkout's "Apply Promotions" server-to-server call
]);

function unlockCookieValue(password: string): string {
  return crypto.createHash('sha256').update(`site-unlock:${password}`).digest('hex');
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (pathname.startsWith('/admin') || pathname.startsWith('/api/admin')) {
    const expectedUser = process.env.ADMIN_USER;
    const expectedPassword = process.env.ADMIN_PASSWORD;

    if (!expectedUser || !expectedPassword) {
      return new NextResponse('Admin auth is not configured (set ADMIN_USER / ADMIN_PASSWORD)', { status: 500 });
    }

    const authHeader = req.headers.get('authorization');
    const expected = 'Basic ' + Buffer.from(`${expectedUser}:${expectedPassword}`).toString('base64');

    if (authHeader !== expected) {
      return new NextResponse('Authentication required', {
        status: 401,
        headers: { 'WWW-Authenticate': 'Basic realm="Admin"' },
      });
    }

    return NextResponse.next();
  }

  if (ALWAYS_ALLOWED_PATHS.has(pathname)) {
    return NextResponse.next();
  }

  const userAgent = req.headers.get('user-agent') || '';
  if (CRAWLER_UA.test(userAgent)) {
    return NextResponse.next();
  }

  let settings: { siteLocked: boolean; sitePassword: string | null } | null = null;
  try {
    settings = await prisma.storeSettings.findUnique({
      where: { id: 'singleton' },
      select: { siteLocked: true, sitePassword: true },
    });
  } catch {
    // Fail open — a DB hiccup shouldn't take the whole site down.
    return NextResponse.next();
  }

  if (!settings?.siteLocked) {
    return NextResponse.next();
  }

  const unlockCookie = req.cookies.get('site_unlock')?.value;
  if (settings.sitePassword && unlockCookie === unlockCookieValue(settings.sitePassword)) {
    return NextResponse.next();
  }

  const url = req.nextUrl.clone();
  url.pathname = '/site-locked';
  return NextResponse.rewrite(url);
}
