import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

// Takes the wishlist stored in localStorage (just product handles) and
// returns full product cards for them — so removed/unpublished products
// silently drop off the wishlist instead of erroring.
export async function POST(req: NextRequest) {
  const { handles } = await req.json();
  if (!Array.isArray(handles) || handles.length === 0) {
    return NextResponse.json({ products: [] });
  }

  const products = await prisma.product.findMany({
    where: { handle: { in: handles }, status: 'active' },
    include: { images: { take: 4, orderBy: { position: 'asc' } } },
  });

  const byHandle = new Map(products.map((p) => [p.handle, p]));
  const ordered = handles.map((h: string) => byHandle.get(h)).filter(Boolean);

  return NextResponse.json({
    products: ordered.map((p) => ({
      handle: p.handle,
      title: p.title,
      price: p.price?.toString() || '',
      compareAtPrice: p.compareAtPrice?.toString(),
      images: p.images.map((img) => img.url),
      isOutOfStock: p.isOutOfStock,
    })),
  });
}
