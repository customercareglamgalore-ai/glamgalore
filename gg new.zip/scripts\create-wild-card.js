// One-off: creates the WILD CARD product — a leopard-print sequin halter
// top with turquoise trim, single colorway (Leopard Print) x 3 sizes
// (S/M/L), sourced from CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = { S: 'CJCS298962901AZ', M: 'CJCS298962902BY', L: 'CJCS298962903CX' };
const HERO_IMAGE = '/products/wild-card/wild-card-1.png';
const GALLERY_IMAGES = ['/products/wild-card/wild-card-1.png', '/products/wild-card/wild-card-2.png'];

const DESCRIPTION_TEXT = 'Shine effortlessly in the Wild Card Sequin Halter Top featuring a leopard print, shimmering sequins, open-back halter design and flattering slim fit.';
const FEATURES = [
  'Material: Polyester',
  'Embellished',
  'Figure-hugging silhouette',
  'Turquoise contrast trim adds a bold Y2K-inspired statement.',
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'wild-card' } });
  if (existing) {
    console.error('A product with handle "wild-card" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'wild-card',
      title: 'WILD CARD',
      descriptionHtml: `<p>${DESCRIPTION_TEXT}</p>`,
      description: DESCRIPTION_TEXT,
      features: FEATURES,
      type: 'TOP',
      price: 1999,
      status: 'active',
      isDropshipped: true,
      collections: ['strictly-tops', 'spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).map(([size, sku]) => ({
          optionName: 'Color',
          optionValue: 'Leopard Print',
          option2Name: 'Size',
          option2Value: size,
          imageUrl: HERO_IMAGE,
          sku,
        })),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created WILD CARD:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
