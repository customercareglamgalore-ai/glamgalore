// Pure GST tax calculation — no I/O, no Prisma. Both the checkout quote preview
// and the real order-creation route call this so the numbers a customer sees
// before paying are guaranteed to match what gets persisted on the Order.

export type TaxLineInput = {
  productId: string;
  quantity: number;
  unitPrice: number; // INR, canonical price (interpreted as exclusive or inclusive per ctx.pricesIncludeTax)
  hsnCode: string;
  gstRate: number; // percent, e.g. 12
};

export type TaxContext = {
  customerState: string | null;
  customerCountry: string; // "India" or any other country name
  businessState: string;
  pricesIncludeTax: boolean;
  chargeTaxOnInternational: boolean;
  discountAmount: number; // INR, applied proportionally across lines by value
};

export type TaxType = 'intra_state' | 'inter_state' | 'export_zero_rated' | 'export_taxed';

export type TaxLineResult = {
  productId: string;
  hsnCode: string;
  gstRate: number; // rate actually applied (0 for zero-rated export lines)
  taxableValue: number;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
};

export type TaxComputation = {
  taxType: TaxType;
  lines: TaxLineResult[];
  subtotal: number;
  taxableValue: number;
  cgstTotal: number;
  sgstTotal: number;
  igstTotal: number;
  totalTax: number;
  shippingCost: number;
  grandTotal: number;
};

function normalize(s: string | null | undefined) {
  return (s || '').trim().toLowerCase();
}

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

function resolveTaxType(ctx: TaxContext): TaxType {
  if (normalize(ctx.customerCountry) !== 'india') {
    return ctx.chargeTaxOnInternational ? 'export_taxed' : 'export_zero_rated';
  }
  return normalize(ctx.customerState) === normalize(ctx.businessState) ? 'intra_state' : 'inter_state';
}

export function computeOrderTax(lines: TaxLineInput[], shippingCost: number, ctx: TaxContext): TaxComputation {
  const taxType = resolveTaxType(ctx);
  const isZeroRated = taxType === 'export_zero_rated';

  // Gross value per line, before tax back-calculation and discount proration.
  const grossByLine = lines.map((l) => l.unitPrice * l.quantity);
  const subtotal = grossByLine.reduce((sum, v) => sum + v, 0);

  // For inclusive pricing, work in "base" (pre-tax) terms per line so the
  // discount is prorated over taxable value, not sticker price.
  const baseByLine = lines.map((l, i) =>
    ctx.pricesIncludeTax ? grossByLine[i] / (1 + l.gstRate / 100) : grossByLine[i],
  );
  const totalBase = baseByLine.reduce((sum, v) => sum + v, 0);

  const results: TaxLineResult[] = [];
  let discountAllocated = 0;

  lines.forEach((line, i) => {
    const isLast = i === lines.length - 1;
    const base = baseByLine[i];

    // Prorate the order discount by each line's share of total base value;
    // the last line absorbs the rounding remainder so lines reconcile exactly.
    let discountShare: number;
    if (isLast) {
      discountShare = round2(ctx.discountAmount - discountAllocated);
    } else {
      discountShare = totalBase > 0 ? round2(ctx.discountAmount * (base / totalBase)) : 0;
      discountAllocated += discountShare;
    }

    // discountShare is a gross (tax-inclusive) rupee amount — resolveDiscount
    // computes it as a % of the gross subtotal. Subtracting it straight from
    // `base` (pre-tax) would double-count the tax portion and could clamp
    // taxableValue to 0 well before the discount is actually fully "spent"
    // (e.g. a 99%-off code would zero out taxableValue even though the
    // customer's post-discount price is still ~1% of the sticker price).
    // Convert it to base terms first so a 100%-off code reduces taxableValue
    // to exactly 0, not before.
    const discountShareBase = ctx.pricesIncludeTax ? discountShare / (1 + line.gstRate / 100) : discountShare;
    const taxableValue = Math.max(0, round2(base - discountShareBase));
    const rate = isZeroRated ? 0 : line.gstRate;

    let cgstAmount = 0;
    let sgstAmount = 0;
    let igstAmount = 0;

    if (taxType === 'intra_state') {
      cgstAmount = round2((taxableValue * rate) / 100 / 2);
      sgstAmount = cgstAmount;
    } else if (taxType === 'inter_state' || taxType === 'export_taxed') {
      igstAmount = round2((taxableValue * rate) / 100);
    }
    // export_zero_rated: all remain 0.

    results.push({
      productId: line.productId,
      hsnCode: line.hsnCode,
      gstRate: rate,
      taxableValue,
      cgstAmount,
      sgstAmount,
      igstAmount,
    });
  });

  const cgstTotal = round2(results.reduce((sum, r) => sum + r.cgstAmount, 0));
  const sgstTotal = round2(results.reduce((sum, r) => sum + r.sgstAmount, 0));
  const igstTotal = round2(results.reduce((sum, r) => sum + r.igstAmount, 0));
  const totalTax = round2(cgstTotal + sgstTotal + igstTotal);

  // The amount actually charged is always a clean subtotal-minus-discount —
  // never reconstructed by re-summing the independently-rounded base/tax
  // split above, which can drift a paisa or two off the sticker price
  // (e.g. ₹2999 base+tax rounding separately can reconstruct as ₹2999.01).
  // taxableValue is derived FROM the clean total instead, so the GST invoice
  // still reconciles exactly against what the customer was actually charged.
  const grandTotal = round2(subtotal - ctx.discountAmount + shippingCost);
  const taxableValue = round2(grandTotal - totalTax - shippingCost);

  return {
    taxType,
    lines: results,
    subtotal: round2(subtotal),
    taxableValue,
    cgstTotal,
    sgstTotal,
    igstTotal,
    totalTax,
    shippingCost: round2(shippingCost),
    grandTotal,
  };
}

// Resolves the GST rate + HSN code for a single product/line, in priority order:
// 1. Product-level override
// 2. Category (Product.type) TaxRule
// 3. Apparel price-slab (if enabled)
// 4. Flat StoreSettings default
export type RateResolutionInput = {
  unitPrice: number;
  productGstRateOverride: number | null;
  productHsnCode: string | null;
  categoryRule: { gstRate: number; hsnCode: string | null } | null;
  useApparelPriceSlabs: boolean;
  apparelSlabThreshold: number;
  apparelSlabRateBelow: number;
  apparelSlabRateAbove: number;
  defaultGstRate: number;
  fallbackHsnCode: string;
};

export function resolveLineRate(input: RateResolutionInput): { gstRate: number; hsnCode: string } {
  const hsnCode = input.productHsnCode || input.categoryRule?.hsnCode || input.fallbackHsnCode;

  if (input.productGstRateOverride !== null && input.productGstRateOverride !== undefined) {
    return { gstRate: input.productGstRateOverride, hsnCode };
  }
  if (input.categoryRule) {
    return { gstRate: input.categoryRule.gstRate, hsnCode };
  }
  if (input.useApparelPriceSlabs) {
    const rate = input.unitPrice <= input.apparelSlabThreshold ? input.apparelSlabRateBelow : input.apparelSlabRateAbove;
    return { gstRate: rate, hsnCode };
  }
  return { gstRate: input.defaultGstRate, hsnCode };
}
