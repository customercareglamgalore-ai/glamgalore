// One-off: creates the PEARLORA product — a white draped maxi dress with
// gold hardware, cutouts, and a sheer skirt, in 1 color (White) x 3 sizes
// (S/M/L), sourced from CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  White: { S: 'CJLY254303401AZ', M: 'CJLY254303402BY', L: 'CJLY254303403CX' },
};

const HERO_IMAGE = {
  White: '/products/pearlora/pearlora-1.png',
};

const GALLERY_IMAGES = [
  '/products/pearlora/pearlora-1.png', // front
  '/products/pearlora/pearlora-2.png', // back
  '/products/pearlora/pearlora-3.png', // gold hardware detail
];

const DESCRIPTION =
  'Pearlora is a dreamy white maxi dress with a sculpted ruched bodice, gold hardware, elegant cutouts and a flowing sheer skirt for a goddess-like finish.';
const DESCRIPTION_HTML = `<p>${DESCRIPTION}</p>`;
const FEATURES = [
  'Material: Polyester',
  'Sculpted ruched bodice',
  'Statement gold hardware',
  'Elegant waist cutouts',
  'Adjustable tie-back straps',
  'Flowing sheer maxi skirt with soft draping',
];
const SEO_TITLE = 'PEARLORA WHITE DRAPED MAXI DRESS | Glam Galore';

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'pearlora' } });
  if (existing) {
    console.error('A product with handle "pearlora" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'pearlora',
      title: 'PEARLORA',
      descriptionHtml: DESCRIPTION_HTML,
      description: DESCRIPTION,
      features: FEATURES,
      seoTitle: SEO_TITLE,
      seoDescription: DESCRIPTION,
      type: 'Dress',
      price: 3299,
      status: 'active',
      isDropshipped: true,
      collections: ['spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created PEARLORA:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
