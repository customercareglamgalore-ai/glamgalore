import ExcelJS from 'exceljs';
import type { Prisma } from '@prisma/client';

export const ORDER_REPORT_COLUMNS = [
  'Order ID', 'Date', 'Customer Name', 'State', 'Country', 'Products', 'Quantity',
  'Taxable Value', 'CGST', 'SGST', 'IGST', 'Shipping', 'Discounts', 'Total Tax',
  'Grand Total', 'Refunded Amount', 'Refunded Tax', 'Net Total', 'Payment Status', 'Payment Method', 'Order Status',
];

export type OrderForReport = Prisma.OrderGetPayload<{
  include: { items: { include: { product: true } }; customer: true };
}>;

export type ReportRow = (string | number)[];

export function buildOrderReportRows(orders: OrderForReport[]): ReportRow[] {
  return orders.map((o) => [
    o.invoiceNumber || o.id,
    o.createdAt.toISOString().slice(0, 10),
    o.customer?.name || o.customer?.email || '',
    o.customerState || '',
    o.customerCountry,
    o.items.map((i) => `${i.product.title} x${i.quantity}`).join('; '),
    o.items.reduce((sum, i) => sum + i.quantity, 0),
    Number(o.taxableValue),
    Number(o.cgstAmount),
    Number(o.sgstAmount),
    Number(o.igstAmount),
    Number(o.shippingCost),
    Number(o.discountAmount),
    Number(o.totalTax),
    Number(o.total),
    Number(o.refundedAmount),
    Number(o.refundedTax),
    Number(o.total) - Number(o.refundedAmount),
    o.paymentStatus,
    'Razorpay',
    o.status,
  ]);
}

export async function ordersToXlsxBuffer(rows: ReportRow[]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Orders');
  sheet.addRow(ORDER_REPORT_COLUMNS);
  sheet.getRow(1).font = { bold: true };
  rows.forEach((r) => sheet.addRow(r));
  sheet.columns.forEach((col) => {
    col.width = 16;
  });
  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}
