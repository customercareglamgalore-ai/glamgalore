import { prisma } from '@/lib/db';
import { headers, cookies } from 'next/headers';
import crypto from 'crypto';
import { notFound } from 'next/navigation';
import { sendMetaViewContentEvent } from '@/lib/meta-capi';
import { getCustomerIdFromSession } from '@/lib/auth';
import ReviewsSection from '@/components/ReviewsSection';
import ReelStrip from '@/components/ReelStrip';
import ProductGallery from '@/components/ProductGallery';
import ProductPurchasePanel from '@/components/ProductPurchasePanel';
import ProductAccordion from '@/components/ProductAccordion';
import ProductCarousel from '@/components/ProductCarousel';
import Reveal from '@/components/Reveal';
import ViewContentPixel from '@/components/ViewContentPixel';
import { INTERNATIONAL_SHIPPING_INFO, FOR_A_CAUSE_INFO, SIZE_CHART_INFO } from '@/lib/store-content';

export async function generateMetadata({ params }: { params: Promise<{ handle: string }> }) {
  const { handle } = await params;
  const product = await prisma.product.findUnique({
    where: { handle },
    select: {
      title: true,
      seoTitle: true,
      seoDescription: true,
      description: true,
      price: true,
      images: { take: 1, orderBy: { position: 'asc' }, select: { url: true } },
    },
  });

  if (!product) return { title: 'Glam Galore' };

  const title = product.seoTitle || `${product.title} — Glam Galore`;
  const description =
    product.seoDescription ||
    product.description ||
    `${product.title} — ₹${product.price?.toString()} at Glam Galore.`;
  const image = product.images[0]?.url;

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      images: image ? [image] : undefined,
    },
  };
}

export default async function ProductPage({ params }: { params: Promise<{ handle: string }> }) {
  const { handle } = await params;
  const product = await prisma.product.findUnique({
    where: { handle },
    include: {
      images: { orderBy: { position: 'asc' } },
      variants: true,
      reviews: true,
      reels: { orderBy: { position: 'asc' } },
    },
  });

  if (!product) notFound();

  // Server-side Conversions API call for ViewContent, deduped against the
  // client-side pixel (ViewContentPixel below) via this shared eventId —
  // Meta's own diagnostics flagged ViewContent specifically as under-covered
  // by CAPI relative to the pixel alone. Fired without awaiting so it never
  // adds latency to the page response. Enriched with the logged-in
  // customer's own details (when there is a session) — most viewers here are
  // anonymous, but for logged-in repeat customers this closes the same
  // match-quality gap the Purchase event already had.
  const viewContentEventId = crypto.randomUUID();
  const requestHeaders = await headers();
  const requestCookies = await cookies();
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://glamgalore.in';
  const sessionCustomerId = await getCustomerIdFromSession();
  const sessionCustomer = sessionCustomerId
    ? await prisma.customer.findUnique({
        where: { id: sessionCustomerId },
        select: {
          id: true,
          email: true,
          phone: true,
          name: true,
          addresses: { where: { isDefault: true }, take: 1, select: { city: true, state: true, pincode: true, country: true } },
        },
      })
    : null;
  const [sessionFirstName, ...sessionLastNameParts] = (sessionCustomer?.name || '').trim().split(/\s+/);
  const sessionAddress = sessionCustomer?.addresses[0];
  sendMetaViewContentEvent({
    eventId: viewContentEventId,
    contentId: product.id,
    contentName: product.title,
    value: Number(product.price) || 0,
    currency: 'INR',
    email: sessionCustomer?.email,
    phone: sessionCustomer?.phone,
    firstName: sessionFirstName || undefined,
    lastName: sessionLastNameParts.join(' ') || undefined,
    city: sessionAddress?.city,
    state: sessionAddress?.state,
    zip: sessionAddress?.pincode,
    country: sessionAddress?.country,
    externalId: sessionCustomer?.id,
    clientIp: requestHeaders.get('x-forwarded-for'),
    userAgent: requestHeaders.get('user-agent'),
    sourceUrl: `${siteUrl}/products/${product.handle}`,
    fbp: requestCookies.get('_fbp')?.value,
    fbc: requestCookies.get('_fbc')?.value,
  }).catch(() => {});

  const relatedWhere = {
    id: { not: product.id },
    status: 'active',
  } as const;

  let relatedProducts = await prisma.product.findMany({
    where: {
      ...relatedWhere,
      ...(product.collections.length > 0 ? { collections: { hasSome: product.collections } } : {}),
    },
    take: 10,
    orderBy: { createdAt: 'desc' },
    select: {
      handle: true,
      title: true,
      price: true,
      compareAtPrice: true,
      images: { take: 1, orderBy: { position: 'asc' } },
      isOutOfStock: true,
    },
  });

  if (relatedProducts.length === 0) {
    relatedProducts = await prisma.product.findMany({
      where: relatedWhere,
      take: 10,
      orderBy: { createdAt: 'desc' },
      select: {
        handle: true,
        title: true,
        price: true,
        compareAtPrice: true,
        images: { take: 1, orderBy: { position: 'asc' } },
        isOutOfStock: true,
      },
    });
  }

  const avgRating =
    product.reviews.length > 0
      ? product.reviews.reduce((sum, r) => sum + r.rating, 0) / product.reviews.length
      : null;

  return (
    <main className="product-page">
      <ViewContentPixel productId={product.id} title={product.title} price={Number(product.price)} eventId={viewContentEventId} />
      <ProductGallery images={product.images} alt={product.title} />

      <Reveal className="product-info">
        <h1>{product.title}</h1>
        {avgRating && (
          <p className="rating">
            <span className="stars">{'★'.repeat(Math.round(avgRating))}</span> {avgRating.toFixed(1)} ({product.reviews.length} reviews)
          </p>
        )}
        <p className="price">₹{product.price?.toString()}</p>

        {product.isOutOfStock ? (
          <p className="sold-out-message">Sold Out</p>
        ) : (
          <ProductPurchasePanel
            productId={product.id}
            handle={product.handle}
            title={product.title}
            price={Number(product.price)}
            lowStockMessage={product.handle === 'aurelia' ? 'Only a few pieces left' : undefined}
            variants={product.variants.map((v) => ({
              id: v.id,
              optionName: v.optionName,
              optionValue: v.optionValue,
              option2Name: v.option2Name,
              option2Value: v.option2Value,
              swatchHex: v.swatchHex,
              imageUrl: v.imageUrl,
              isOutOfStock: v.isOutOfStock,
            }))}
          />
        )}

        <ProductAccordion
          items={[
            ...(product.description
              ? [{ title: 'Description', content: <p>{product.description}</p> }]
              : []),
            ...(product.features.length > 0
              ? [
                  {
                    title: 'Features',
                    content: (
                      <ul>
                        {product.features.map((f, i) => (
                          <li key={`${f}-${i}`}>{f}</li>
                        ))}
                      </ul>
                    ),
                  },
                ]
              : []),
            ...(SIZE_CHART_INFO
              ? [{ title: 'Size Chart', content: <p>{SIZE_CHART_INFO}</p> }]
              : []),
            ...(INTERNATIONAL_SHIPPING_INFO
              ? [{ title: 'International Shipping', content: <p>{INTERNATIONAL_SHIPPING_INFO}</p> }]
              : []),
            ...(FOR_A_CAUSE_INFO
              ? [{ title: 'Purchase for a Cause', content: <p>{FOR_A_CAUSE_INFO}</p> }]
              : []),
          ]}
        />

        {product.reels.length > 0 && (
          <div className="reels-section reels-section--inline">
            <ReelStrip
              minimal
              reels={product.reels.map((r) => ({
                id: r.id,
                videoUrl: r.videoUrl,
                thumbnailUrl: r.thumbnailUrl,
                caption: r.caption,
                product: {
                  id: product.id,
                  handle: product.handle,
                  title: product.title,
                  price: product.price?.toString() || '',
                  compareAtPrice: product.compareAtPrice?.toString(),
                  imageUrl: product.images[0]?.url,
                  variants: product.variants.map((v) => ({
                    id: v.id,
                    optionName: v.optionName,
                    optionValue: v.optionValue,
                    option2Name: v.option2Name,
                    option2Value: v.option2Value,
                    swatchHex: v.swatchHex,
                    imageUrl: v.imageUrl,
                    isOutOfStock: v.isOutOfStock,
                  })),
                },
              }))}
            />
          </div>
        )}
      </Reveal>

      <Reveal className="reviews-section">
        <h2>Customer reviews</h2>
        <ReviewsSection productId={product.id} initialReviews={product.reviews} />
      </Reveal>

      {relatedProducts.length > 0 && (
        <Reveal className="related-products-section">
          <h2>You may also like</h2>
          <ProductCarousel
            products={relatedProducts.map((p) => ({
              handle: p.handle,
              title: p.title,
              price: p.price?.toString() || '',
              compareAtPrice: p.compareAtPrice ? p.compareAtPrice.toString() : null,
              images: p.images.map((img) => img.url),
              isOutOfStock: p.isOutOfStock,
            }))}
          />
        </Reveal>
      )}
    </main>
  );
}
