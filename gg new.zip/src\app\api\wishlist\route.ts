import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getCustomerIdFromSession } from '@/lib/auth';

// Returns the logged-in customer's wishlist. Anonymous visitors get an
// empty, logged-out response rather than an error — the wishlist button
// itself handles sending them to log in.
export async function GET() {
  const customerId = await getCustomerIdFromSession();
  if (!customerId) return NextResponse.json({ loggedIn: false, handles: [], products: [] });

  const items = await prisma.wishlistItem.findMany({
    where: { customerId },
    include: { product: { include: { images: { take: 4, orderBy: { position: 'asc' } } } } },
    orderBy: { createdAt: 'desc' },
  });

  return NextResponse.json({
    loggedIn: true,
    handles: items.map((i) => i.product.handle),
    products: items.map((i) => ({
      handle: i.product.handle,
      title: i.product.title,
      price: i.product.price?.toString() || '',
      compareAtPrice: i.product.compareAtPrice?.toString(),
      images: i.product.images.map((img) => img.url),
      isOutOfStock: i.product.isOutOfStock,
    })),
  });
}
