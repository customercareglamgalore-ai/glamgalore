// Wishlist is stored client-side only (localStorage), keyed by product
// handle — no account/session needed, mirroring how the cart itself works
// before checkout.
const WISHLIST_KEY = 'wishlist';
export const WISHLIST_UPDATED_EVENT = 'wishlist-updated';

function readWishlist(): string[] {
  if (typeof window === 'undefined') return [];
  try {
    return JSON.parse(localStorage.getItem(WISHLIST_KEY) || '[]');
  } catch {
    return [];
  }
}

function writeWishlist(handles: string[]) {
  localStorage.setItem(WISHLIST_KEY, JSON.stringify(handles));
  window.dispatchEvent(new Event(WISHLIST_UPDATED_EVENT));
}

export function getWishlistHandles(): string[] {
  return readWishlist();
}

export function isWishlisted(handle: string): boolean {
  return readWishlist().includes(handle);
}

export function toggleWishlist(handle: string): boolean {
  const current = readWishlist();
  const alreadyIn = current.includes(handle);
  writeWishlist(alreadyIn ? current.filter((h) => h !== handle) : [...current, handle]);
  return !alreadyIn;
}

export function removeFromWishlist(handle: string) {
  writeWishlist(readWishlist().filter((h) => h !== handle));
}
