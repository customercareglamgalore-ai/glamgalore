// Wishlist is tied to a logged-in customer account (not localStorage) — an
// anonymous visitor tapping the heart gets sent to log in first. A small
// module-level cache avoids every WishlistButton on a collection page
// firing its own /api/wishlist request.
export const WISHLIST_UPDATED_EVENT = 'wishlist-updated';

type WishlistState = { loggedIn: boolean; handles: string[] };

let cache: WishlistState | null = null;
let inFlight: Promise<WishlistState> | null = null;

async function fetchState(): Promise<WishlistState> {
  if (inFlight) return inFlight;
  inFlight = fetch('/api/wishlist')
    .then((res) => res.json())
    .then((data) => {
      cache = { loggedIn: data.loggedIn, handles: data.handles };
      inFlight = null;
      return cache;
    });
  return inFlight;
}

export async function ensureWishlistState(): Promise<WishlistState> {
  if (cache) return cache;
  return fetchState();
}

export function isWishlisted(handle: string): boolean {
  return cache?.handles.includes(handle) ?? false;
}

export function invalidateWishlistCache() {
  cache = null;
}

export async function toggleWishlist(handle: string): Promise<{ loggedIn: boolean; wishlisted?: boolean }> {
  const res = await fetch('/api/wishlist/toggle', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ handle }),
  });

  if (res.status === 401) return { loggedIn: false };

  const data = await res.json();
  if (cache) {
    cache = {
      ...cache,
      handles: data.wishlisted ? [...cache.handles, handle] : cache.handles.filter((h) => h !== handle),
    };
  }
  window.dispatchEvent(new Event(WISHLIST_UPDATED_EVENT));
  return { loggedIn: true, wishlisted: data.wishlisted };
}
