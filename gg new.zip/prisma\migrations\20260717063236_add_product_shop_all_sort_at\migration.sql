-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "shopAllSortAt" TIMESTAMP(3);
