import { NextRequest, NextResponse } from 'next/server';

// Called directly by Razorpay's servers during Magic Checkout (configured as
// the "Shipping Setup" URL in Dashboard → Magic Checkout → Checkout
// Settings) — must stay publicly accessible with no auth. Since this store
// ships free worldwide and doesn't offer Cash on Delivery, every address is
// simply serviceable with zero shipping fee and COD turned off.
//
// NOTE: the exact response shape isn't fully spelled out in Razorpay's
// public docs (the example is request-only) — this follows their own literal
// description of what the endpoint returns. Worth double-checking against
// the Dashboard's validation once Magic Checkout is configured there.
type ShippingInfoRequest = {
  order_id: string;
  razorpay_order_id: string;
  email?: string;
  contact: string;
  addresses: { id: string; zipcode: string; state_code?: string; country: string }[];
};

export async function POST(req: NextRequest) {
  const body: ShippingInfoRequest = await req.json();

  const addresses = (body.addresses || []).map((address) => ({
    id: address.id,
    serviceable: true,
    cod_serviceable: false,
    shipping_fee: 0,
    cod_fee: 0,
    // Undocumented in Razorpay's public docs, but the checkout UI renders a
    // named, selectable delivery option — this covers the case where it
    // expects a list of shipping methods per address rather than (or in
    // addition to) a single flat fee, so it doesn't fall back to some
    // default non-zero rate when this array is absent.
    shipping_methods: [
      { id: 'standard', name: 'Standard', shipping_fee: 0, cod_fee: 0 },
    ],
  }));

  return NextResponse.json({ addresses });
}
