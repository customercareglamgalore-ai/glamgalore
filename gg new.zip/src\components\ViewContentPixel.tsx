'use client';

import { useEffect } from 'react';
import { trackMetaEvent } from './MetaPixel';

export default function ViewContentPixel({
  productId,
  title,
  price,
  eventId,
}: {
  productId: string;
  title: string;
  price: number;
  eventId: string;
}) {
  useEffect(() => {
    trackMetaEvent(
      'ViewContent',
      {
        content_ids: [productId],
        content_name: title,
        content_type: 'product',
        value: price,
        currency: 'INR',
      },
      eventId,
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productId, eventId]);

  return null;
}
