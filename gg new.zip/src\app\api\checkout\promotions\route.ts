import { NextRequest, NextResponse } from 'next/server';

// Required by Razorpay Magic Checkout's Dashboard "Coupon Settings" (Get
// Promotions API) — this URL has to be registered there even though our own
// coupon UI is hidden (show_coupons: false on the client). Customers enter
// discount codes through our own cart page field instead, validated during
// order creation. Returning an empty list means Razorpay's own coupon widget
// never has anything to show, which is what we want; the endpoint just needs
// to exist and respond correctly for the Dashboard setup step to be complete.
export async function POST(req: NextRequest) {
  await req.json().catch(() => null);
  return NextResponse.json({ promotions: [] });
}
