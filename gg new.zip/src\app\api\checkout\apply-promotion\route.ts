import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { resolveDiscount } from '@/lib/discounts';

// Required by Razorpay Magic Checkout's Dashboard "Coupon Settings" (Apply
// Promotions API), registered alongside the Get Promotions URL above. Our
// coupon widget is hidden client-side (show_coupons: false), so this rarely
// gets called by real customers, but it still needs to exist and respond in
// Razorpay's expected shape for the Dashboard setup to be considered
// complete — reuses the same discount validation as our own cart page field.
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const receiptOrderId = body.order_id as string | undefined;
  const code = body.code as string | undefined;

  const order = receiptOrderId ? await prisma.order.findUnique({ where: { id: receiptOrderId } }) : null;
  if (!order) {
    return NextResponse.json(
      { error: { code: 'INVALID_PROMOTION', description: 'Order not found.' } },
      { status: 400 },
    );
  }

  const resolution = await resolveDiscount(code, Number(order.subtotal));
  if (!resolution || 'error' in resolution) {
    return NextResponse.json(
      { error: { code: 'INVALID_PROMOTION', description: resolution && 'error' in resolution ? resolution.error : 'Invalid code.' } },
      { status: 400 },
    );
  }

  return NextResponse.json({
    promotion: {
      code: resolution.code,
      value: Math.round(resolution.amount * 100),
      type: 'flat',
    },
  });
}
