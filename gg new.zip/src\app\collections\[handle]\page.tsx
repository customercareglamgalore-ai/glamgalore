import { Suspense } from 'react';
import { prisma } from '@/lib/db';
import ProductCard from '@/components/ProductCard';
import { notFound } from 'next/navigation';
import { COLLECTION_TITLES } from '@/lib/collections';
import Reveal from '@/components/Reveal';
import CollectionControls from '@/components/CollectionControls';
import Pagination from '@/components/Pagination';
import ReelBubbles from '@/components/ReelBubbles';
import { getCuratedReelBubbles } from '@/lib/curated-reel-bubbles';
import type { Prisma } from '@prisma/client';

const PAGE_SIZE = 12;

export async function generateMetadata({ params }: { params: Promise<{ handle: string }> }) {
  const { handle } = await params;
  const title = COLLECTION_TITLES[handle] || handle.replace(/-/g, ' ');
  return { title: `${title} — Glam Galore` };
}

const SORT_ORDER_BY: Record<string, Prisma.ProductOrderByWithRelationInput> = {
  newest: { createdAt: 'desc' },
  oldest: { createdAt: 'asc' },
  az: { title: 'asc' },
  za: { title: 'desc' },
  'price-low': { price: 'asc' },
  'price-high': { price: 'desc' },
};

export default async function CollectionPage({
  params,
  searchParams,
}: {
  params: Promise<{ handle: string }>;
  searchParams: Promise<{ sort?: string; page?: string }>;
}) {
  const { handle } = await params;
  const { sort = 'best-selling', page: pageParam } = await searchParams;
  const page = Math.max(1, Number(pageParam) || 1);

  const where: Prisma.ProductWhereInput =
    handle === 'all'
      ? { status: 'active' }
      : { status: 'active', collections: { has: handle } };

  // Shop All's default "newest" order needs to be independently correctable
  // from other collections' orderings (they share the same createdAt field,
  // so reordering a product within e.g. Sweat Sesh shifts it in Shop All
  // too). shopAllSortAt overrides createdAt for this one collection's
  // default sort only; the vast majority of products don't have it set and
  // just fall back to their real createdAt. Every other collection/sort
  // combination is unaffected and still queried directly from the DB.
  const useShopAllOverride = handle === 'all' && sort === 'newest';

  let products: Prisma.ProductGetPayload<{ include: { images: { orderBy: { position: 'asc' }; take: 4 } } }>[];
  let totalCount: number;
  let curatedReelBubbles: Awaited<ReturnType<typeof getCuratedReelBubbles>>;

  if (sort === 'best-selling') {
    // "Units sold" isn't a stored field on Product — it's computed here from
    // OrderItem, counting only paid/refunded orders (never abandoned carts
    // or pending payments). Same fetch-all-then-sort-in-JS-then-paginate
    // shape as the Shop All override below, since there's no way to express
    // "order by a separate table's aggregate" directly in a single Prisma
    // orderBy for this case.
    const [allProducts, salesByProduct, bubbles] = await Promise.all([
      prisma.product.findMany({
        where,
        include: { images: { orderBy: { position: 'asc' }, take: 4 } },
      }),
      prisma.orderItem.groupBy({
        by: ['productId'],
        where: { order: { paymentStatus: { in: ['paid', 'refunded'] } } },
        _sum: { quantity: true },
      }),
      getCuratedReelBubbles(),
    ]);
    const unitsSoldByProduct = new Map(salesByProduct.map((s) => [s.productId, s._sum.quantity || 0]));
    allProducts.sort((a, b) => (unitsSoldByProduct.get(b.id) || 0) - (unitsSoldByProduct.get(a.id) || 0));
    totalCount = allProducts.length;
    products = allProducts.slice((page - 1) * PAGE_SIZE, (page - 1) * PAGE_SIZE + PAGE_SIZE);
    curatedReelBubbles = bubbles;
  } else if (useShopAllOverride) {
    const [allProducts, bubbles] = await Promise.all([
      prisma.product.findMany({
        where,
        include: { images: { orderBy: { position: 'asc' }, take: 4 } },
      }),
      getCuratedReelBubbles(),
    ]);
    allProducts.sort((a, b) => {
      const aTime = (a.shopAllSortAt ?? a.createdAt).getTime();
      const bTime = (b.shopAllSortAt ?? b.createdAt).getTime();
      return bTime - aTime;
    });
    totalCount = allProducts.length;
    products = allProducts.slice((page - 1) * PAGE_SIZE, (page - 1) * PAGE_SIZE + PAGE_SIZE);
    curatedReelBubbles = bubbles;
  } else {
    const [queried, count, bubbles] = await Promise.all([
      prisma.product.findMany({
        where,
        include: { images: { orderBy: { position: 'asc' }, take: 4 } },
        orderBy: SORT_ORDER_BY[sort] || SORT_ORDER_BY.newest,
        skip: (page - 1) * PAGE_SIZE,
        take: PAGE_SIZE,
      }),
      prisma.product.count({ where }),
      getCuratedReelBubbles(),
    ]);
    products = queried;
    totalCount = count;
    curatedReelBubbles = bubbles;
  }

  if (totalCount === 0) notFound();

  const totalPages = Math.ceil(totalCount / PAGE_SIZE);

  return (
    <main className="container">
      <ReelBubbles reels={curatedReelBubbles} />
      <Suspense fallback={null}>
        <CollectionControls />
      </Suspense>
      <Reveal className="product-grid collection-grid">
        {products.map((p) => (
          <ProductCard
            key={p.id}
            product={{
              handle: p.handle,
              title: p.title,
              price: p.price?.toString() || '',
              compareAtPrice: p.compareAtPrice?.toString(),
              images: p.images.map((img) => img.url),
              isOutOfStock: p.isOutOfStock,
            }}
          />
        ))}
      </Reveal>
      <Suspense fallback={null}>
        <Pagination totalPages={totalPages} />
      </Suspense>
    </main>
  );
}
