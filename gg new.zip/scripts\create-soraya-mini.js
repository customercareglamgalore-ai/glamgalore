// One-off: creates the "SORAYA Mini" product — a cross-strap halter sequin
// ruched sheath mini dress in 2 colors (Olive, Brown) x 4 sizes (S/M/L/XL),
// sourced from CJ Dropshipping. Same colorway/fabric as SORAYA (the maxi
// skirt version, handle "soraya") but a separate CJ listing/SKUs entirely.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Olive: { S: 'CJLY304628605EV', M: 'CJLY304628606FU', L: 'CJLY304628607GT', XL: 'CJLY304628608HS' },
  Brown: { S: 'CJLY304628601AZ', M: 'CJLY304628602BY', L: 'CJLY304628603CX', XL: 'CJLY304628604DW' },
};

const HERO_IMAGE = {
  Olive: '/products/soraya-mini/soraya-mini-1.png',
  Brown: '/products/soraya-mini/soraya-mini-4.png',
};

const GALLERY_IMAGES = [
  '/products/soraya-mini/soraya-mini-1.png', // Olive front
  '/products/soraya-mini/soraya-mini-2.png', // Olive back
  '/products/soraya-mini/soraya-mini-3.png', // Olive detail
  '/products/soraya-mini/soraya-mini-4.png', // Brown front
  '/products/soraya-mini/soraya-mini-5.png', // Brown back
  '/products/soraya-mini/soraya-mini-6.png', // Brown detail
];

const DESCRIPTION_HTML = '<p>Make an entrance in the SORAYA Mini Sequin Dress, featuring shimmering embellishments, a sculpted wrap waist and flowing mini-length silhouette for effortless glamour.</p>';
const DESCRIPTION = 'Make an entrance in the SORAYA Mini Sequin Dress, featuring shimmering embellishments, a sculpted wrap waist and flowing mini-length silhouette for effortless glamour.';
const FEATURES = [
  'Material: Polyester',
  'Sequin embellished net skirt with asymmetric cowled overlay panel',
  'Non-sheer',
  'Mini length',
  'Fitted bodice',
  'Adjustable halter neck with convertible multiway ties',
  'Asymmetric pleated cowl skirt with embellished netting overlay',
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'soraya-mini' } });
  if (existing) {
    console.error('A product with handle "soraya-mini" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'soraya-mini',
      title: 'SORAYA Mini',
      descriptionHtml: DESCRIPTION_HTML,
      description: DESCRIPTION,
      features: FEATURES,
      type: 'Dress',
      price: 3499,
      status: 'active',
      isDropshipped: true,
      collections: ['mini-dresses', 'spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created SORAYA Mini:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
