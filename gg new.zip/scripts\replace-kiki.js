// Replaces KIKI with a new CJ listing (new SKUs, new photos) at the same
// price and same description/features text. Tries a real delete of the old
// product first; if it's ever been ordered, Order.items has a foreign key
// to it and the delete will fail — in that case, archive + rename it to
// "kiki-legacy" instead (same pattern used for the STARDUST handle
// collision earlier), freeing up the "kiki" handle for the new listing.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Green: { S: 'CJLY240861204DW', M: 'CJLY240861203CX', L: 'CJLY240861202BY' },
};

const HERO_IMAGE = {
  Green: '/products/kiki/kiki-1.png',
};

const GALLERY_IMAGES = [
  '/products/kiki/kiki-1.png', // studio front
  '/products/kiki/kiki-2.png', // studio back
  '/products/kiki/kiki-3.png', // detail
  '/products/kiki/kiki-4.png', // lifestyle, beach
  '/products/kiki/kiki-5.png', // lifestyle, cliffside
];

const DESCRIPTION_HTML =
  "<p>Indulge in luxury with KIKI, our breathtaking 'Kiki Maxi Dress' in Iridescent Pearl. Featuring a sultry bodycon silhouette, this dress is adorned with pearl-like details and a detachable statement pearl draping for a show-stopping touch. The ruching at the hips accentuates your curves while the soft mesh fabrication adds a touch of elegance. Embrace your inner goddess in this exclusive piece.</p>";
const DESCRIPTION =
  "Indulge in luxury with KIKI, our breathtaking 'Kiki Maxi Dress' in Iridescent Pearl. Featuring a sultry bodycon silhouette, this dress is adorned with pearl-like details and a detachable statement pearl draping for a show-stopping touch. The ruching at the hips accentuates your curves while the soft mesh fabrication adds a touch of elegance. Embrace your inner goddess in this exclusive piece.";
const FEATURES = [
  'Mesh fabrication',
  'Bodycon silhouette',
  'Halter neckline with pearl-like details',
  'Statement pearl-like draping at bodice (detachable)',
  'Low rise skirt',
  'Ruching at centre, side & back of hips',
  'Knotted bust detail',
  'Adjustable back & neckties',
];
const SEO_TITLE = 'KIKI MAXI DRESS IRIDESCENT PEARL | Glam Galore';
const SEO_DESCRIPTION =
  'Turn heads in the Kiki Maxi Dress in Iridescent Pearl. With a sultry bodycon fit, pearl details & a statement drape, this luxe piece is pure elegance. ';

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'kiki' } });
  if (existing) {
    try {
      await prisma.product.delete({ where: { handle: 'kiki' } });
      console.log('Deleted old KIKI:', existing.id);
    } catch (err) {
      console.warn('Could not hard-delete old KIKI (likely has order history) — archiving instead:', err.message);
      await prisma.product.update({
        where: { id: existing.id },
        data: { handle: 'kiki-legacy', status: 'archived' },
      });
      console.log('Archived old KIKI as "kiki-legacy":', existing.id);
    }
  }

  const product = await prisma.product.create({
    data: {
      handle: 'kiki',
      title: 'KIKI',
      descriptionHtml: DESCRIPTION_HTML,
      description: DESCRIPTION,
      features: FEATURES,
      seoTitle: SEO_TITLE,
      seoDescription: SEO_DESCRIPTION,
      type: 'Dress',
      price: 2899,
      status: 'active',
      isDropshipped: true,
      collections: ['the-divine-feminine', 'spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created new KIKI:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
