// One-off: creates the VERDEA product — a halter-neck deep-V backless
// bodysuit with an asymmetrical wrap skirt, two-piece set, in 3 colors
// (Brown, Grass Green, Rose Red) x 4 sizes (S/M/L/XL), sourced from CJ
// Dropshipping. Description/features are placeholders — update once real
// copy is provided.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Brown: { S: 'CJLS304630709IR', M: 'CJLS304630710JQ', L: 'CJLS304630711KP', XL: 'CJLS304630712LO' },
  'Grass Green': { S: 'CJLS304630701AZ', M: 'CJLS304630702BY', L: 'CJLS304630703CX', XL: 'CJLS304630704DW' },
  'Rose Red': { S: 'CJLS304630705EV', M: 'CJLS304630706FU', L: 'CJLS304630707GT', XL: 'CJLS304630708HS' },
};

const HERO_IMAGE = {
  Brown: '/products/verdea/verdea-1.png',
  'Rose Red': '/products/verdea/verdea-3.png',
  'Grass Green': '/products/verdea/verdea-7.png',
};

const GALLERY_IMAGES = [
  '/products/verdea/verdea-1.png',  // Brown front
  '/products/verdea/verdea-2.png',  // Brown back
  '/products/verdea/verdea-3.png',  // Rose Red front
  '/products/verdea/verdea-4.png',  // Rose Red back
  '/products/verdea/verdea-5.png',  // Rose Red bodysuit detail
  '/products/verdea/verdea-6.png',  // Rose Red bodysuit detail
  '/products/verdea/verdea-7.png',  // Grass Green front
  '/products/verdea/verdea-8.png',  // Grass Green back
  '/products/verdea/verdea-9.png',  // Grass Green detail
  '/products/verdea/verdea-10.png', // Grass Green detail
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'verdea' } });
  if (existing) {
    console.error('A product with handle "verdea" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'verdea',
      title: 'VERDEA',
      descriptionHtml: '<p>Turn heads in the Verdea Drape Co-ord – plunge neck bodysuit with an asymmetric ruched midi skirt and a flowing draped hem. Perfect for beach clubs, vacations, parties, and resort wear.</p>',
      description: 'Turn heads in the Verdea Drape Co-ord – plunge neck bodysuit with an asymmetric ruched midi skirt and a flowing draped hem. Perfect for beach clubs, vacations, parties, and resort wear.',
      features: [
        'Material: Polyester',
        'Dramatic deep plunge neckline',
        'Halter neck straps with adjustable back neck ties',
        'Low back',
        'Adjustable snap closure at gusset',
        'Mid-rise wide asymmetric, ruched waistband with twisted knot detail',
        'Double layered waistband',
        'Asymmetric handkerchief hem with laser cut finish and split detail',
        'Smooth, pull-on construction',
        'No zipper',
      ],
      type: 'co ord',
      price: 2999,
      status: 'active',
      isDropshipped: true,
      collections: ['co-ords', 'spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created VERDEA:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
