-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "heroVideoUrl" TEXT;
