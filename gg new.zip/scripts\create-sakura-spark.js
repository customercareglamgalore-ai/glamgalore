// One-off: creates the SAKURA SPARK product — a floral beaded halter
// co-ord (crop top + tie-side mini skirt), single colorway (Rose Red Suit)
// x 4 sizes (S/M/L/XL), sourced from CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = { S: 'CJLY302277513MN', M: 'CJLY302277514NM', L: 'CJLY302277515OL', XL: 'CJLY302277516PK' };
const HERO_IMAGE = '/products/sakura-spark/sakura-spark-1.png';
const GALLERY_IMAGES = [
  '/products/sakura-spark/sakura-spark-1.png',
  '/products/sakura-spark/sakura-spark-2.png',
  '/products/sakura-spark/sakura-spark-3.png',
  '/products/sakura-spark/sakura-spark-4.png',
];

const DESCRIPTION_TEXT = 'Shimmer in the Sakura Spark Embellished co ord featuring floral beadwork, a plunging halter neckline, open back and a flattering fitted skirt silhouette.';
const FEATURES = [
  'Material: Polyester',
  'Embellished',
  'Halter neckline',
  'Backless',
  'Regular waisted',
  'Side cut out tie up detailing',
  'Stretchy',
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'sakura-spark' } });
  if (existing) {
    console.error('A product with handle "sakura-spark" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'sakura-spark',
      title: 'SAKURA SPARK',
      descriptionHtml: `<p>${DESCRIPTION_TEXT}</p>`,
      description: DESCRIPTION_TEXT,
      features: FEATURES,
      type: 'co ord',
      price: 3499,
      status: 'active',
      isDropshipped: true,
      collections: ['co-ords', 'spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).map(([size, sku]) => ({
          optionName: 'Color',
          optionValue: 'Rose Red',
          option2Name: 'Size',
          option2Value: size,
          imageUrl: HERO_IMAGE,
          sku,
        })),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created SAKURA SPARK:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
