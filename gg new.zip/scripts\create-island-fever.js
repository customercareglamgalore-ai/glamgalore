// One-off: creates the ISLAND FEVER product — a draped halter mini dress in
// 3 prints (Leopard Print, Floral, Stripes) x 4 sizes (S/M/L/XL only —
// 2XL/3XL intentionally excluded per instructions), sourced from CJ
// Dropshipping. The "Floral" print is CJ's generically-labeled "Color"
// variant — named descriptively here since "Color" isn't a usable
// customer-facing label.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  'Leopard Print': { S: 'CJLY303240437KP', M: 'CJLY303240438LO', L: 'CJLY303240439MN', XL: 'CJLY303240440NM' },
  Floral: { S: 'CJLY303240425YB', M: 'CJLY303240426ZA', L: 'CJLY303240427AZ', XL: 'CJLY303240428BY' },
  Stripes: { S: 'CJLY303240431EV', M: 'CJLY303240432FU', L: 'CJLY303240433GT', XL: 'CJLY303240434HS' },
};

const HERO_IMAGE = {
  'Leopard Print': '/products/island-fever/island-fever-1.png',
  Floral: '/products/island-fever/island-fever-3.png',
  Stripes: '/products/island-fever/island-fever-5.png',
};

const GALLERY_IMAGES = [
  '/products/island-fever/island-fever-1.png', // Leopard front
  '/products/island-fever/island-fever-2.png', // Leopard back
  '/products/island-fever/island-fever-3.png', // Floral front
  '/products/island-fever/island-fever-4.png', // Floral back
  '/products/island-fever/island-fever-5.png', // Stripes front
  '/products/island-fever/island-fever-6.png', // Stripes back
];

const DESCRIPTION_TEXT = 'Island Fever is sooo good for this dress 😭🌺 It works especially well across all three prints — very vacation, hot-girl, tropical-night energy.';
const FEATURES = ['Material: Polyester', 'Draped halter neck design', 'Open back', 'Body hugging'];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'island-fever' } });
  if (existing) {
    console.error('A product with handle "island-fever" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'island-fever',
      title: 'ISLAND FEVER',
      descriptionHtml: `<p>${DESCRIPTION_TEXT}</p>`,
      description: DESCRIPTION_TEXT,
      features: FEATURES,
      type: 'Dress',
      price: 2699,
      status: 'active',
      isDropshipped: true,
      collections: ['spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created ISLAND FEVER:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
