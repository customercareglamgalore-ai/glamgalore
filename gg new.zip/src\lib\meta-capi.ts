// Meta Conversions API — server-side event forwarding, used as a reliable
// backup to the client-side Pixel (survives ad blockers, iOS ATT, etc).
// Docs: https://developers.facebook.com/docs/marketing-api/conversions-api
//
// Pass the same `eventId` used for the client-side fbq() call for the same
// action so Meta dedupes the two into a single event instead of double-counting.

import crypto from 'crypto';

const PIXEL_ID = process.env.NEXT_PUBLIC_META_PIXEL_ID;
const ACCESS_TOKEN = process.env.META_CONVERSIONS_API_TOKEN;

export function isMetaCapiConfigured() {
  return Boolean(PIXEL_ID && ACCESS_TOKEN);
}

function sha256(value: string) {
  return crypto.createHash('sha256').update(value.trim().toLowerCase()).digest('hex');
}

export async function sendMetaPurchaseEvent({
  eventId,
  email,
  phone,
  value,
  currency,
  contentIds,
  clientIp,
  userAgent,
  sourceUrl,
  fbp,
  fbc,
}: {
  eventId: string;
  email?: string | null;
  phone?: string | null;
  value: number;
  currency: string;
  contentIds: string[];
  clientIp?: string | null;
  userAgent?: string | null;
  sourceUrl: string;
  fbp?: string | null;
  fbc?: string | null;
}) {
  if (!isMetaCapiConfigured()) return false;

  const userData: Record<string, unknown> = {};
  if (email) userData.em = [sha256(email)];
  if (phone) userData.ph = [sha256(phone.replace(/\D/g, ''))];
  if (clientIp) userData.client_ip_address = clientIp;
  if (userAgent) userData.client_user_agent = userAgent;
  // Meta's own _fbp/_fbc first-party cookies — passed through verbatim (not
  // hashed), these give much stronger match/dedup quality than IP + user
  // agent alone, per Meta's Conversions API best practices.
  if (fbp) userData.fbp = fbp;
  if (fbc) userData.fbc = fbc;

  const payload = {
    data: [
      {
        event_name: 'Purchase',
        event_time: Math.floor(Date.now() / 1000),
        event_id: eventId,
        event_source_url: sourceUrl,
        action_source: 'website',
        user_data: userData,
        custom_data: {
          currency,
          value,
          content_ids: contentIds,
          content_type: 'product',
        },
      },
    ],
  };

  const res = await fetch(`https://graph.facebook.com/v21.0/${PIXEL_ID}/events?access_token=${ACCESS_TOKEN}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    console.error('Meta Conversions API Purchase event failed:', await res.text());
    return false;
  }
  return true;
}

// Meta's own diagnostics flag ViewContent specifically as under-covered by
// Conversions API relative to the client-side pixel (which drops events to
// ad blockers, iOS ATT, etc.) — this closes that gap the same way Purchase
// already does, deduped against ViewContentPixel's client-side call via the
// same eventId.
export async function sendMetaViewContentEvent({
  eventId,
  contentId,
  contentName,
  value,
  currency,
  clientIp,
  userAgent,
  sourceUrl,
  fbp,
  fbc,
}: {
  eventId: string;
  contentId: string;
  contentName: string;
  value: number;
  currency: string;
  clientIp?: string | null;
  userAgent?: string | null;
  sourceUrl: string;
  fbp?: string | null;
  fbc?: string | null;
}) {
  if (!isMetaCapiConfigured()) return false;

  const userData: Record<string, unknown> = {};
  if (clientIp) userData.client_ip_address = clientIp;
  if (userAgent) userData.client_user_agent = userAgent;
  if (fbp) userData.fbp = fbp;
  if (fbc) userData.fbc = fbc;

  const payload = {
    data: [
      {
        event_name: 'ViewContent',
        event_time: Math.floor(Date.now() / 1000),
        event_id: eventId,
        event_source_url: sourceUrl,
        action_source: 'website',
        user_data: userData,
        custom_data: {
          currency,
          value,
          content_ids: [contentId],
          content_name: contentName,
          content_type: 'product',
        },
      },
    ],
  };

  const res = await fetch(`https://graph.facebook.com/v21.0/${PIXEL_ID}/events?access_token=${ACCESS_TOKEN}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    console.error('Meta Conversions API ViewContent event failed:', await res.text());
    return false;
  }
  return true;
}
