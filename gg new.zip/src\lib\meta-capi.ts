// Meta Conversions API — server-side event forwarding, used as a reliable
// backup to the client-side Pixel (survives ad blockers, iOS ATT, etc).
// Docs: https://developers.facebook.com/docs/marketing-api/conversions-api
//
// Pass the same `eventId` used for the client-side fbq() call for the same
// action so Meta dedupes the two into a single event instead of double-counting.

import crypto from 'crypto';
import { COUNTRY_TO_ISO_CODE } from '@/lib/currency';

const PIXEL_ID = process.env.NEXT_PUBLIC_META_PIXEL_ID;
const ACCESS_TOKEN = process.env.META_CONVERSIONS_API_TOKEN;

export function isMetaCapiConfigured() {
  return Boolean(PIXEL_ID && ACCESS_TOKEN);
}

function sha256(value: string) {
  return crypto.createHash('sha256').update(value.trim().toLowerCase()).digest('hex');
}

// Meta's matching for name/city/state fields is exact-match on the hash, so
// punctuation the customer typed (an apostrophe in a name, a comma after a
// city) that Meta's own normalization doesn't strip would silently break the
// match — stripped here before hashing per Meta's parameter documentation.
function sha256Normalized(value: string) {
  return sha256(value.replace(/[^a-z0-9]/gi, ''));
}

type MatchParams = {
  email?: string | null;
  phone?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  city?: string | null;
  state?: string | null;
  zip?: string | null;
  country?: string | null;
  externalId?: string | null;
  clientIp?: string | null;
  userAgent?: string | null;
  fbp?: string | null;
  fbc?: string | null;
};

// Shared by every event below — the more of these Meta gets, the better it
// can match a hit to a real Facebook/Instagram profile (Event Match Quality),
// independent of any single field. Any field left undefined is simply
// omitted rather than sent empty.
function buildMatchUserData(params: MatchParams): Record<string, unknown> {
  const { email, phone, firstName, lastName, city, state, zip, country, externalId, clientIp, userAgent, fbp, fbc } = params;
  const userData: Record<string, unknown> = {};
  if (email) userData.em = [sha256(email)];
  if (phone) userData.ph = [sha256(phone.replace(/\D/g, ''))];
  if (firstName) userData.fn = [sha256Normalized(firstName)];
  if (lastName) userData.ln = [sha256Normalized(lastName)];
  if (city) userData.ct = [sha256Normalized(city)];
  if (state) userData.st = [sha256Normalized(state)];
  if (zip) userData.zp = [sha256(zip.replace(/\s/g, ''))];
  // Meta requires the 2-letter ISO country code, not the full name we store
  // (e.g. "in", not "india") — COUNTRY_TO_ISO_CODE only covers the ~13
  // countries we support currencies for, so this silently omits the field
  // for anything else rather than sending a code Meta would reject.
  const countryCode = country && COUNTRY_TO_ISO_CODE[country];
  if (countryCode) userData.country = [sha256(countryCode)];
  if (externalId) userData.external_id = [sha256(externalId)];
  if (clientIp) userData.client_ip_address = clientIp;
  if (userAgent) userData.client_user_agent = userAgent;
  // Meta's own _fbp/_fbc first-party cookies — passed through verbatim (not
  // hashed), these give much stronger match/dedup quality than IP + user
  // agent alone, per Meta's Conversions API best practices.
  if (fbp) userData.fbp = fbp;
  if (fbc) userData.fbc = fbc;
  return userData;
}

async function sendMetaEvent(eventName: string, payload: unknown): Promise<boolean> {
  const res = await fetch(`https://graph.facebook.com/v21.0/${PIXEL_ID}/events?access_token=${ACCESS_TOKEN}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    console.error(`Meta Conversions API ${eventName} event failed:`, await res.text());
    return false;
  }
  return true;
}

export async function sendMetaPurchaseEvent({
  eventId,
  value,
  currency,
  contentIds,
  sourceUrl,
  ...match
}: MatchParams & {
  eventId: string;
  value: number;
  currency: string;
  contentIds: string[];
  sourceUrl: string;
}) {
  if (!isMetaCapiConfigured()) return false;

  return sendMetaEvent('Purchase', {
    data: [
      {
        event_name: 'Purchase',
        event_time: Math.floor(Date.now() / 1000),
        event_id: eventId,
        event_source_url: sourceUrl,
        action_source: 'website',
        user_data: buildMatchUserData(match),
        custom_data: {
          currency,
          value,
          content_ids: contentIds,
          content_type: 'product',
        },
      },
    ],
  });
}

// Meta's own diagnostics flag ViewContent specifically as under-covered by
// Conversions API relative to the client-side pixel (which drops events to
// ad blockers, iOS ATT, etc.) — this closes that gap the same way Purchase
// does, deduped against ViewContentPixel's client-side call via the same
// eventId. Enriched with the logged-in customer's own details (when there is
// a session) the same way Purchase is — most product-page viewers are
// anonymous, but for the repeat customers who are logged in, this closes the
// same match-quality gap Purchase already had.
export async function sendMetaViewContentEvent({
  eventId,
  contentId,
  contentName,
  value,
  currency,
  sourceUrl,
  ...match
}: MatchParams & {
  eventId: string;
  contentId: string;
  contentName: string;
  value: number;
  currency: string;
  sourceUrl: string;
}) {
  if (!isMetaCapiConfigured()) return false;

  return sendMetaEvent('ViewContent', {
    data: [
      {
        event_name: 'ViewContent',
        event_time: Math.floor(Date.now() / 1000),
        event_id: eventId,
        event_source_url: sourceUrl,
        action_source: 'website',
        user_data: buildMatchUserData(match),
        custom_data: {
          currency,
          value,
          content_ids: [contentId],
          content_name: contentName,
          content_type: 'product',
        },
      },
    ],
  });
}
