'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import ProductPurchasePanel from './ProductPurchasePanel';

export type ReelViewerItem = {
  id: string;
  videoUrl: string;
  thumbnailUrl?: string | null;
  caption?: string | null;
  product: {
    id: string;
    handle: string;
    title: string;
    price: string;
    compareAtPrice?: string | null;
    imageUrl?: string | null;
    variants: {
      id: string;
      optionName: string | null;
      optionValue: string | null;
      option2Name: string | null;
      option2Value: string | null;
      swatchHex: string | null;
      imageUrl: string | null;
    }[];
  };
};

export default function ReelViewer({
  reels,
  initialIndex,
  onClose,
}: {
  reels: ReelViewerItem[];
  initialIndex: number;
  onClose: () => void;
}) {
  const [index, setIndex] = useState(initialIndex);
  const [muted, setMuted] = useState(true);
  const [liked, setLiked] = useState(false);
  const touchStartX = useRef<number | null>(null);

  const reel = reels[index];

  function goNext() {
    setIndex((i) => (i + 1) % reels.length);
    setLiked(false);
  }
  function goPrev() {
    setIndex((i) => (i - 1 + reels.length) % reels.length);
    setLiked(false);
  }

  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') goNext();
      if (e.key === 'ArrowLeft') goPrev();
    }
    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onClose, reels.length]);

  function handleTouchStart(e: React.TouchEvent) {
    touchStartX.current = e.touches[0].clientX;
  }
  function handleTouchEnd(e: React.TouchEvent) {
    if (touchStartX.current === null) return;
    const delta = e.changedTouches[0].clientX - touchStartX.current;
    if (delta > 50) goPrev();
    else if (delta < -50) goNext();
    touchStartX.current = null;
  }

  async function handleShare() {
    const url = `${location.origin}/products/${reel.product.handle}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: reel.product.title, url });
      } catch {
        // user cancelled share -- nothing to do
      }
    } else {
      await navigator.clipboard.writeText(url);
    }
  }

  if (!reel) return null;

  return createPortal(
    <div className="reel-viewer-overlay" onClick={onClose}>
      <div
        className="reel-viewer-stage"
        onClick={(e) => e.stopPropagation()}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        <div className="reel-viewer-video-pane">
          <video key={reel.id} src={reel.videoUrl} autoPlay muted={muted} loop playsInline className="reel-viewer-video" />

          <button type="button" className="reel-viewer-close" aria-label="Close" onClick={onClose}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
              <line x1="5" y1="5" x2="19" y2="19" />
              <line x1="19" y1="5" x2="5" y2="19" />
            </svg>
          </button>

          <button type="button" className="reel-viewer-mute" aria-label={muted ? 'Unmute' : 'Mute'} onClick={() => setMuted((m) => !m)}>
            {muted ? (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="4 9 8 9 13 4 13 20 8 15 4 15 4 9" />
                <line x1="17" y1="9" x2="22" y2="14" />
                <line x1="22" y1="9" x2="17" y2="14" />
              </svg>
            ) : (
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="4 9 8 9 13 4 13 20 8 15 4 15 4 9" />
                <path d="M17 8a5 5 0 0 1 0 8" />
                <path d="M20 5a9 9 0 0 1 0 14" />
              </svg>
            )}
          </button>

          {reels.length > 1 && (
            <>
              <button type="button" className="reel-viewer-nav reel-viewer-nav--prev" aria-label="Previous reel" onClick={goPrev}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
                  <polyline points="15 6 9 12 15 18" />
                </svg>
              </button>
              <button type="button" className="reel-viewer-nav reel-viewer-nav--next" aria-label="Next reel" onClick={goNext}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
                  <polyline points="9 6 15 12 9 18" />
                </svg>
              </button>
            </>
          )}

          <div className="reel-viewer-social">
            <button type="button" className="reel-viewer-social-btn" aria-label="Like" onClick={() => setLiked((l) => !l)}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill={liked ? '#ff4d6d' : 'none'} stroke={liked ? '#ff4d6d' : 'white'} strokeWidth="1.8">
                <path d="M12 21s-7.5-4.7-10-9.3C.3 8.4 2 5 5.5 5c2 0 3.3 1 4.5 2.5C11.2 6 12.5 5 14.5 5 18 5 19.7 8.4 22 11.7 19.5 16.3 12 21 12 21z" />
              </svg>
            </button>
            <button type="button" className="reel-viewer-social-btn" aria-label="Share" onClick={handleShare}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <line x1="22" y1="2" x2="11" y2="13" />
                <polygon points="22 2 15 22 11 13 2 9 22 2" />
              </svg>
            </button>
          </div>

          {reel.caption && <p className="reel-viewer-caption">{reel.caption}</p>}
        </div>

        <div className="reel-viewer-product-pane">
          <Link href={`/products/${reel.product.handle}`} className="reel-viewer-product-header" onClick={onClose}>
            {reel.product.imageUrl && <img src={reel.product.imageUrl} alt={reel.product.title} />}
            <span>
              <span className="reel-viewer-product-title">{reel.product.title}</span>
              <span className="reel-viewer-product-price">
                {reel.product.compareAtPrice && Number(reel.product.compareAtPrice) > Number(reel.product.price) && (
                  <span className="compare-price">₹{reel.product.compareAtPrice}</span>
                )}
                ₹{reel.product.price}
              </span>
            </span>
          </Link>

          <ProductPurchasePanel
            productId={reel.product.id}
            handle={reel.product.handle}
            title={reel.product.title}
            price={Number(reel.product.price)}
            variants={reel.product.variants}
          />

          <Link href={`/products/${reel.product.handle}`} className="reel-viewer-more-info" onClick={onClose}>
            More info
          </Link>
        </div>
      </div>
    </div>,
    document.body
  );
}
