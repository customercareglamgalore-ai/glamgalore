// One-off: creates the SORAYA product — a halter-neck sequin panel maxi
// skirt (with a matching bodysuit top) in 2 colors (Olive, Brown) x 4 sizes
// (S/M/L/XL), sourced from CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Olive: { S: 'CJLY304624505EV', M: 'CJLY304624506FU', L: 'CJLY304624507GT', XL: 'CJLY304624508HS' },
  Brown: { S: 'CJLY304624501AZ', M: 'CJLY304624502BY', L: 'CJLY304624503CX', XL: 'CJLY304624504DW' },
};

const HERO_IMAGE = {
  Olive: '/products/soraya/soraya-1.png',
  Brown: '/products/soraya/soraya-4.png',
};

const GALLERY_IMAGES = [
  '/products/soraya/soraya-1.png', // Olive front
  '/products/soraya/soraya-2.png', // Olive back
  '/products/soraya/soraya-3.png', // Olive detail
  '/products/soraya/soraya-4.png', // Brown front
  '/products/soraya/soraya-5.png', // Brown back
  '/products/soraya/soraya-6.png', // Brown detail
];

const DESCRIPTION_HTML = '<p>Make an entrance in the Soraya Sequin Maxi Skirt, featuring shimmering embellishments, a sculpted wrap waist and flowing floor-length silhouette for effortless glamour.</p>';
const DESCRIPTION = 'Make an entrance in the Soraya Sequin Maxi Skirt, featuring shimmering embellishments, a sculpted wrap waist and flowing floor-length silhouette for effortless glamour.';
const FEATURES = [
  'Material: Polyester',
  'Sequin embellished net skirt with asymmetric cowled overlay panel',
  'Non-sheer',
  'Maxi length',
  'Fitted bodice',
  'Adjustable halter neck with convertible multiway ties',
  'Asymmetric pleated cowl skirt with embellished netting overlay',
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'soraya' } });
  if (existing) {
    console.error('A product with handle "soraya" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'soraya',
      title: 'SORAYA',
      descriptionHtml: DESCRIPTION_HTML,
      description: DESCRIPTION,
      features: FEATURES,
      type: 'Skirt',
      price: 3499,
      status: 'active',
      isDropshipped: true,
      collections: ['spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created SORAYA:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
