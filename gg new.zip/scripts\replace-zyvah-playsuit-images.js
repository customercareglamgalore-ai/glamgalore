// Replaces ZYVAH - Playsuit's product photos with a fresh set (leopard
// bustier + baroque-print lace shorts, front/back/detail) — these are the
// images that were mistakenly first applied to the plain "zyvah" product;
// this is the correct target. Deletes the old ProductImage rows (legacy
// cdn.shopify.com URLs) and re-points the variant's imageUrl at the new
// hero image. Single colorway ("Blue - Brown"), sizes/SKUs untouched.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const GALLERY_IMAGES = [
  '/products/zyvah-playsuit/zyvah-playsuit-1.png', // front
  '/products/zyvah-playsuit/zyvah-playsuit-2.png', // back
  '/products/zyvah-playsuit/zyvah-playsuit-3.png', // detail
];
const HERO_IMAGE = GALLERY_IMAGES[0];

async function main() {
  const product = await prisma.product.findUnique({ where: { handle: 'zyvah-playsuit' }, include: { images: true, variants: true } });
  if (!product) {
    console.error('No product with handle "zyvah-playsuit" found.');
    process.exit(1);
  }

  await prisma.productImage.deleteMany({ where: { productId: product.id } });
  await prisma.productImage.createMany({
    data: GALLERY_IMAGES.map((url, i) => ({ productId: product.id, url, position: i })),
  });

  await prisma.productVariant.updateMany({
    where: { productId: product.id },
    data: { imageUrl: HERO_IMAGE },
  });

  console.log('Replaced ZYVAH - Playsuit images:', GALLERY_IMAGES.length, 'new photos');
  console.log('Re-pointed', product.variants.length, 'variants to the new hero image');
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
