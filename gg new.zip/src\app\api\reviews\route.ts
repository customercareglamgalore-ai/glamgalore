// Public review submission — anyone can post a review from the product page,
// no login or purchase required (per explicit decision: open submission,
// moderate after the fact by deleting bad ones rather than approving good
// ones first). Always unverified (verified purchase reviews, if ever added,
// would need to come from an order lookup, not a public form).
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

const MAX_NAME_LENGTH = 80;
const MAX_TITLE_LENGTH = 120;
const MAX_BODY_LENGTH = 2000;
const MAX_IMAGES = 4;

export async function POST(req: NextRequest) {
  const { productId, authorName, rating, title, body, imageUrls } = await req.json();

  if (!productId || typeof productId !== 'string') {
    return NextResponse.json({ error: 'Missing product' }, { status: 400 });
  }

  const trimmedName = String(authorName || '').trim().slice(0, MAX_NAME_LENGTH);
  const trimmedBody = String(body || '').trim().slice(0, MAX_BODY_LENGTH);
  const trimmedTitle = String(title || '').trim().slice(0, MAX_TITLE_LENGTH) || null;
  const numericRating = Number(rating);
  // Only accept URLs our own upload endpoint just handed back — never an
  // arbitrary URL the client sends, or this becomes an open image host.
  const cleanImageUrls = Array.isArray(imageUrls)
    ? imageUrls.filter((url): url is string => typeof url === 'string' && url.startsWith('/uploads/reviews/')).slice(0, MAX_IMAGES)
    : [];

  if (!trimmedName) {
    return NextResponse.json({ error: 'Name is required' }, { status: 400 });
  }
  if (!Number.isInteger(numericRating) || numericRating < 1 || numericRating > 5) {
    return NextResponse.json({ error: 'Rating must be between 1 and 5' }, { status: 400 });
  }
  if (!trimmedBody) {
    return NextResponse.json({ error: 'Review text is required' }, { status: 400 });
  }

  const product = await prisma.product.findUnique({ where: { id: productId }, select: { id: true } });
  if (!product) {
    return NextResponse.json({ error: 'Product not found' }, { status: 404 });
  }

  const review = await prisma.review.create({
    data: {
      productId,
      authorName: trimmedName,
      rating: numericRating,
      title: trimmedTitle,
      body: trimmedBody,
      imageUrls: cleanImageUrls,
      verified: false,
      source: 'site',
    },
  });

  return NextResponse.json({
    id: review.id,
    authorName: review.authorName,
    rating: review.rating,
    title: review.title,
    body: review.body,
    imageUrls: review.imageUrls,
    verified: review.verified,
  });
}
