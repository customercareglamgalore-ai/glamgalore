// One-off: creates the SWEET VICE product — a lace-lingerie corset top with
// boning and lace-up back, 2 colorways only (Gray, Pink — Black
// intentionally excluded per instructions) x 3 sizes (S/M/L), sourced from
// CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Gray: { S: 'CJCS303881601AZ', M: 'CJCS303881602BY', L: 'CJCS303881603CX' },
  Pink: { S: 'CJCS303881607GT', M: 'CJCS303881608HS', L: 'CJCS303881609IR' },
};

const HERO_IMAGE = {
  Gray: '/products/sweet-vice/sweet-vice-1.png',
  Pink: '/products/sweet-vice/sweet-vice-4.png',
};

const GALLERY_IMAGES = [
  '/products/sweet-vice/sweet-vice-1.png', // Gray front (model)
  '/products/sweet-vice/sweet-vice-2.png', // Gray back (model)
  '/products/sweet-vice/sweet-vice-3.png', // Gray front (mannequin)
  '/products/sweet-vice/sweet-vice-4.png', // Pink front (model)
  '/products/sweet-vice/sweet-vice-5.png', // Pink back (model)
  '/products/sweet-vice/sweet-vice-6.png', // Pink front (mannequin)
  '/products/sweet-vice/sweet-vice-7.png', // Pink back (mannequin)
];

const DESCRIPTION_TEXT = 'Meet Sweet Vice, a corset top with lace bra detailing, sculpting boning and a lace-up back, a dangerously pretty statement piece.';
const FEATURES = [
  'Material: Poly cotton',
  'Lace lingerie corset top',
  'Boning throughout',
  'Padded at bust and hip',
  'Adjustable spaghetti straps',
  'Bow and charm details at front',
  'Lacing and offset zip closure at back',
  'Fully lined',
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'sweet-vice' } });
  if (existing) {
    console.error('A product with handle "sweet-vice" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'sweet-vice',
      title: 'SWEET VICE',
      descriptionHtml: `<p>${DESCRIPTION_TEXT}</p>`,
      description: DESCRIPTION_TEXT,
      features: FEATURES,
      type: 'CORSET',
      price: 2699,
      status: 'active',
      isDropshipped: true,
      collections: ['spring-has-sprung', 'strictly-tops'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created SWEET VICE:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
