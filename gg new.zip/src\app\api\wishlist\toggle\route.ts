import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getCustomerIdFromSession } from '@/lib/auth';

export async function POST(req: NextRequest) {
  const customerId = await getCustomerIdFromSession();
  if (!customerId) return NextResponse.json({ error: 'Not logged in' }, { status: 401 });

  const { handle } = await req.json();
  const product = await prisma.product.findUnique({ where: { handle } });
  if (!product) return NextResponse.json({ error: 'Product not found' }, { status: 404 });

  const existing = await prisma.wishlistItem.findUnique({
    where: { customerId_productId: { customerId, productId: product.id } },
  });

  if (existing) {
    await prisma.wishlistItem.delete({ where: { id: existing.id } });
    return NextResponse.json({ wishlisted: false });
  }

  await prisma.wishlistItem.create({ data: { customerId, productId: product.id } });
  return NextResponse.json({ wishlisted: true });
}
