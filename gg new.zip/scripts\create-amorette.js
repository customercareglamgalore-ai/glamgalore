// One-off: creates the AMORETTE product — a sweet beaded embroidered
// sequined halter-neck mini dress in 3 colors (Orange, Pink, Rose Red) x 4
// sizes (S/M/L/XL), sourced from CJ Dropshipping. Description/features are
// placeholders — update once real copy is provided.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Orange: { S: 'CJLY304641909IR', M: 'CJLY304641910JQ', L: 'CJLY304641911KP', XL: 'CJLY304641912LO' },
  Pink: { S: 'CJLY304641901AZ', M: 'CJLY304641902BY', L: 'CJLY304641903CX', XL: 'CJLY304641904DW' },
  'Rose Red': { S: 'CJLY304641913MN', M: 'CJLY304641914NM', L: 'CJLY304641915OL', XL: 'CJLY304641916PK' },
};

const HERO_IMAGE = {
  Orange: '/products/amorette/amorette-1.png',
  Pink: '/products/amorette/amorette-3.png',
  'Rose Red': '/products/amorette/amorette-5.png',
};

const GALLERY_IMAGES = [
  '/products/amorette/amorette-1.png', // Orange front
  '/products/amorette/amorette-2.png', // Orange back
  '/products/amorette/amorette-3.png', // Pink front
  '/products/amorette/amorette-4.png', // Pink back
  '/products/amorette/amorette-5.png', // Rose Red front
  '/products/amorette/amorette-6.png', // Rose Red back
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'amorette' } });
  if (existing) {
    console.error('A product with handle "amorette" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'amorette',
      title: 'AMORETTE',
      descriptionHtml: '<p>Turn every entrance into a moment in the Amorette Mini Dress, featuring intricate bead embellishments, a plunging cowl neckline and an open tie-back.</p>',
      description: 'Turn every entrance into a moment in the Amorette Mini Dress, featuring intricate bead embellishments, a plunging cowl neckline and an open tie-back.',
      features: [
        'Material: Polyester',
        'Hand-embellished sequin and bead detailing',
        'Plunging cowl halter neckline',
        'Adjustable open tie-back design',
        'Flattering body-skimming mini silhouette',
        'Fully lined for a comfortable fit',
      ],
      type: 'Dress',
      price: 3499,
      status: 'active',
      isDropshipped: true,
      collections: ['mini-dresses', 'spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created AMORETTE:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
