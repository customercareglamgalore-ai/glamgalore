// Replaces ZYVAH's product photos with a fresh set (leopard bustier +
// baroque-print lace shorts, front/back/detail) — deletes the old
// ProductImage rows (legacy cdn.shopify.com URLs) and re-points every
// variant's imageUrl at the new hero image. The new set only shows one
// look, so both existing colorways ("Brown - Floral", "Brown - Blue") get
// pointed at the same new hero — colors/sizes/SKUs are otherwise untouched.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const GALLERY_IMAGES = [
  '/products/zyvah/zyvah-1.png', // front
  '/products/zyvah/zyvah-2.png', // back
  '/products/zyvah/zyvah-3.png', // detail
];
const HERO_IMAGE = GALLERY_IMAGES[0];

async function main() {
  const product = await prisma.product.findUnique({ where: { handle: 'zyvah' }, include: { images: true, variants: true } });
  if (!product) {
    console.error('No product with handle "zyvah" found.');
    process.exit(1);
  }

  await prisma.productImage.deleteMany({ where: { productId: product.id } });
  await prisma.productImage.createMany({
    data: GALLERY_IMAGES.map((url, i) => ({ productId: product.id, url, position: i })),
  });

  await prisma.productVariant.updateMany({
    where: { productId: product.id },
    data: { imageUrl: HERO_IMAGE },
  });

  console.log('Replaced ZYVAH images:', GALLERY_IMAGES.length, 'new photos');
  console.log('Re-pointed', product.variants.length, 'variants to the new hero image');
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
