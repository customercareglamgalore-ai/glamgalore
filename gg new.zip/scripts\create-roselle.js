// One-off: creates the ROSELLE product — a romantic pink lace halter cami
// top with floral detailing and tie-back straps, in 1 color (Pink) x 3
// sizes (S/M/L), sourced from CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Pink: { S: 'CJCS307774201AZ', M: 'CJCS307774202BY', L: 'CJCS307774203CX' },
};

const HERO_IMAGE = {
  Pink: '/products/roselle/roselle-1.png',
};

const GALLERY_IMAGES = [
  '/products/roselle/roselle-1.png', // model front
  '/products/roselle/roselle-2.png', // model back
  '/products/roselle/roselle-3.png', // flat front
  '/products/roselle/roselle-4.png', // flat back
];

const DESCRIPTION =
  'ROSELLE is a romantic pink lace cami with delicate floral detailing, a flattering V-neckline and tie-back straps, perfect for dreamy summer styling.';
const DESCRIPTION_HTML = `<p>${DESCRIPTION}</p>`;
const FEATURES = [
  'Material: Polyester',
  'Delicate floral lace for a soft, romantic finish',
  'Flattering V-neckline for an elegant silhouette',
  'Adjustable pink tie straps for a customizable fit',
  'Open tie-back design for a feminine, effortless look',
  'Lightweight sheer construction perfect for layering or warm-weather styling',
];
const SEO_TITLE = 'ROSELLE LACE HALTER CAMI TOP | Glam Galore';

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'roselle' } });
  if (existing) {
    console.error('A product with handle "roselle" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'roselle',
      title: 'ROSELLE',
      descriptionHtml: DESCRIPTION_HTML,
      description: DESCRIPTION,
      features: FEATURES,
      seoTitle: SEO_TITLE,
      seoDescription: DESCRIPTION,
      type: 'Top',
      price: 2699,
      status: 'active',
      isDropshipped: true,
      collections: ['strictly-tops', 'spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created ROSELLE:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
