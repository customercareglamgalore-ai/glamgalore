// One-off: retry CJ submission for an order that failed with
// "shippingCountryCode must be not empty" because Razorpay returned the
// country as a lowercase ISO code (e.g. "in"), which didn't match our
// uppercase-keyed ISO_CODE_TO_COUNTRY map (fixed in complete-magic-order.ts
// alongside this script). Fixes the stored address, then resubmits to CJ.
// This duplicates the minimal slice of src/lib/cj-dropshipping.ts logic
// needed here, since that file is TypeScript and this is a plain Node script.
const { PrismaClient } = require('@prisma/client');
const Razorpay = require('razorpay');
const prisma = new PrismaClient();
const razorpay = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });

const CJ_BASE_URL = 'https://developers.cjdropshipping.com/api2.0/v1';
const REFRESH_MARGIN_MS = 24 * 60 * 60 * 1000;
const PREFERRED_LOGISTIC_NAME = 'cjpacket asia ordinary';

const COUNTRY_TO_ISO_CODE = {
  India: 'IN', 'United States': 'US', 'United Kingdom': 'GB', Canada: 'CA',
  Australia: 'AU', Germany: 'DE', France: 'FR', Ireland: 'IE', Netherlands: 'NL',
  Spain: 'ES', Italy: 'IT', Singapore: 'SG', 'United Arab Emirates': 'AE',
};

async function loginWithCredentials() {
  const email = process.env.CJ_EMAIL;
  const apiKey = process.env.CJ_API_KEY;
  const res = await fetch(`${CJ_BASE_URL}/authentication/getAccessToken`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: apiKey }),
  });
  const data = await res.json();
  if (!data.result || !data.data?.accessToken) throw new Error(`CJ login failed: ${data.code} ${data.message}`);
  return data.data;
}

async function refreshWithToken(refreshToken) {
  const res = await fetch(`${CJ_BASE_URL}/authentication/refreshAccessToken`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refreshToken }),
  });
  const data = await res.json();
  if (!data.result || !data.data?.accessToken) throw new Error(`CJ refresh failed: ${data.code} ${data.message}`);
  return data.data;
}

async function getValidAccessToken() {
  const settings = await prisma.storeSettings.findUnique({ where: { id: 'singleton' } });
  const stillValid = settings?.cjAccessToken && settings.cjAccessTokenExpiresAt &&
    settings.cjAccessTokenExpiresAt.getTime() - Date.now() > REFRESH_MARGIN_MS;
  if (stillValid) return settings.cjAccessToken;

  const refreshStillValid = settings?.cjRefreshToken && settings.cjRefreshTokenExpiresAt &&
    settings.cjRefreshTokenExpiresAt.getTime() - Date.now() > REFRESH_MARGIN_MS;

  const result = refreshStillValid ? await refreshWithToken(settings.cjRefreshToken) : await loginWithCredentials();

  await prisma.storeSettings.upsert({
    where: { id: 'singleton' },
    create: {
      id: 'singleton', cjAccessToken: result.accessToken, cjRefreshToken: result.refreshToken,
      cjAccessTokenExpiresAt: new Date(result.accessTokenExpiryDate), cjRefreshTokenExpiresAt: new Date(result.refreshTokenExpiryDate),
    },
    update: {
      cjAccessToken: result.accessToken, cjRefreshToken: result.refreshToken,
      cjAccessTokenExpiresAt: new Date(result.accessTokenExpiryDate), cjRefreshTokenExpiresAt: new Date(result.refreshTokenExpiryDate),
    },
  });
  return result.accessToken;
}

function formatPhoneForCJ(phone, countryCode) {
  const digits = phone.replace(/\D/g, '');
  if (countryCode === 'IN') {
    if (digits.length === 10) return `91${digits}`;
    if (digits.length === 11 && digits.startsWith('0')) return `91${digits.slice(1)}`;
    return digits;
  }
  return digits;
}

async function resolveLogisticName(headers, countryCode, products) {
  const res = await fetch(`${CJ_BASE_URL}/logistic/freightCalculate`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ startCountryCode: 'CN', endCountryCode: countryCode, products: products.map((p) => ({ quantity: p.quantity, variantSku: p.sku })) }),
  });
  if (!res.ok) throw new Error(`CJ freight calculation failed: ${res.status} ${await res.text()}`);
  const data = await res.json();
  if (!data.result || !data.data?.length) throw new Error(`No CJ shipping option available for ${countryCode}: ${data.message || 'unknown reason'}`);
  const preferred = data.data.find((opt) => opt.logisticName.toLowerCase() === PREFERRED_LOGISTIC_NAME);
  if (preferred) return preferred.logisticName;
  return [...data.data].sort((a, b) => a.logisticPrice - b.logisticPrice)[0].logisticName;
}

async function main() {
  const orderId = process.argv[2];
  if (!orderId) {
    console.error('Usage: node scripts/retry-cj-order.js <orderId>');
    process.exit(1);
  }

  const existing = await prisma.order.findUnique({ where: { id: orderId } });
  if (!existing) throw new Error(`Order ${orderId} not found`);

  const address = existing.shippingAddress;
  // Fix the lowercase-ISO-code bug: normalize to the full country name.
  const fixedCountry = /^[a-z]{2}$/i.test(address.country || '') && address.country.toUpperCase() === 'IN' ? 'India' : address.country;

  // The name can be missing if Razorpay's customer_details.name came back
  // empty at checkout time — re-fetch the Razorpay order directly as a
  // fallback source, same field complete-magic-order.ts reads it from.
  let fixedName = address.name || process.argv[3];
  if (!fixedName && existing.razorpayOrderId) {
    const rzpOrder = await razorpay.orders.fetch(existing.razorpayOrderId);
    fixedName = rzpOrder.customer_details?.name || '';
    console.log('Fetched name from Razorpay order:', fixedName || '(still empty)');
  }

  if (!fixedName) {
    throw new Error(
      'Customer name is empty on the order and on the Razorpay order record. ' +
      'Check the payment in the Razorpay Dashboard for the customer\'s name, then pass it: ' +
      'node scripts/retry-cj-order.js <orderId> "Customer Name"',
    );
  }

  const fixedAddress = { ...address, country: fixedCountry, name: fixedName };

  const order = await prisma.order.update({
    where: { id: orderId },
    data: { shippingAddress: fixedAddress, customerCountry: fixedCountry },
    include: { items: { include: { variant: true } } },
  });

  const products = order.items
    .filter((item) => /^cj/i.test(item.variant?.sku || ''))
    .map((item) => ({ sku: item.variant.sku, quantity: item.quantity, storeLineItemId: item.id }));

  if (products.length === 0) {
    console.log('Nothing in this order is CJ-fulfilled — no submission needed.');
    return;
  }

  const countryCode = COUNTRY_TO_ISO_CODE[fixedCountry] || 'IN';
  const headers = { 'CJ-Access-Token': await getValidAccessToken(), 'Content-Type': 'application/json' };
  const logisticName = await resolveLogisticName(headers, countryCode, products);

  const payload = {
    orderNumber: order.id,
    shippingCustomerName: fixedName || '',
    shippingAddress: address.line1 || '',
    shippingAddress2: address.line2 || '',
    shippingCity: address.city || '',
    shippingProvince: address.state || '',
    shippingCountry: fixedCountry || '',
    shippingCountryCode: countryCode,
    shippingZip: address.pincode || '',
    shippingPhone: address.phone ? formatPhoneForCJ(address.phone, countryCode) : '',
    email: address.email || '',
    fromCountryCode: 'CN',
    logisticName,
    products,
  };

  console.log('Submitting to CJ:', JSON.stringify(payload, null, 2));

  const res = await fetch(`${CJ_BASE_URL}/shopping/order/createOrderV2`, { method: 'POST', headers, body: JSON.stringify(payload) });
  const data = await res.json();
  if (!res.ok || !data.result) throw new Error(`CJ order submission failed: ${res.status} ${JSON.stringify(data)}`);

  await prisma.order.update({ where: { id: orderId }, data: { cjOrderId: data.data.orderId } });
  console.log('Success! CJ order ID:', data.data.orderId);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
