const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const codes = await prisma.discountCode.findMany({
    where: { code: { in: ['RAHINIG', 'RISHITAS'] } },
  });
  console.log('--- Discount codes ---');
  for (const c of codes) {
    console.log(`${c.code}: active=${c.active} valueType=${c.valueType} value=${c.value} usageLimit=${c.usageLimit} usageCount=${c.usageCount}`);
  }
  if (codes.length === 0) console.log('Neither code found in DB.');

  console.log('\n--- Last 5 orders ---');
  const orders = await prisma.order.findMany({
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { customer: true },
  });
  for (const o of orders) {
    console.log(`${o.id} | ${o.createdAt.toISOString()} | paymentStatus=${o.paymentStatus} status=${o.status} cjOrderId=${o.cjOrderId || 'NONE'} email=${o.customer?.email} discountCode=${o.discountCode || '-'}`);
  }
}

main().finally(() => prisma.$disconnect());
