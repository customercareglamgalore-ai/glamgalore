import type { Order, OrderItem, Product, ProductImage, ProductVariant } from '@prisma/client';

type OrderWithItems = Order & {
  items: (OrderItem & { product: Product & { images: ProductImage[] }; variant: ProductVariant | null })[];
};

type ShippingAddress = {
  name: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
  country?: string;
};

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://glamgalore.in';
const FONT = "-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif";

function money(n: unknown): string {
  return `Rs. ${Number(n).toFixed(2)}`;
}

function absoluteImageUrl(url?: string | null): string | null {
  if (!url) return null;
  return url.startsWith('http') ? url : `${SITE_URL}${url}`;
}

export function buildOrderConfirmationEmail(order: OrderWithItems): { subject: string; html: string; text: string } {
  const address = order.shippingAddress as unknown as ShippingAddress;
  const orderNumber = order.invoiceNumber ?? order.id;
  const subject = `Order #${orderNumber} confirmed`;

  const itemRows = order.items
    .map((item) => {
      const variantLabel = item.variant
        ? [item.variant.optionValue, item.variant.option2Value].filter(Boolean).join(' / ')
        : '';
      const lineTotal = Number(item.unitPrice) * item.quantity;
      const imageUrl = absoluteImageUrl(item.product.images[0]?.url);
      return `
        <tr>
          <td style="padding:14px 0;border-bottom:1px solid #f0ede9;width:64px;">
            ${imageUrl ? `<img src="${imageUrl}" width="56" height="70" style="object-fit:cover;border-radius:6px;display:block;" alt="">` : ''}
          </td>
          <td style="padding:14px 0 14px 14px;border-bottom:1px solid #f0ede9;vertical-align:top;">
            <div style="font-size:14px;font-weight:600;color:#201a16;">${item.product.title} &times; ${item.quantity}</div>
            ${variantLabel ? `<div style="font-size:12px;color:#888;margin-top:2px;">${variantLabel}</div>` : ''}
          </td>
          <td style="padding:14px 0;border-bottom:1px solid #f0ede9;text-align:right;font-size:14px;color:#201a16;vertical-align:top;">${money(lineTotal)}</td>
        </tr>`;
    })
    .join('');

  const isZeroTax = order.taxType === 'export_zero_rated';

  const discountRow =
    Number(order.discountAmount) > 0
      ? `<tr><td style="padding:4px 0;font-size:13px;color:#555;">Discount</td><td style="padding:4px 0;font-size:13px;color:#555;text-align:right;">&minus;${money(order.discountAmount)}</td></tr>`
      : '';

  const html = `
  <div style="max-width:560px;margin:0 auto;font-family:${FONT};color:#201a16;">
    <div style="display:flex;justify-content:space-between;align-items:center;padding:28px 0;border-bottom:1px solid #f0ede9;">
      <div style="font-family:Georgia,'Times New Roman',serif;font-size:24px;letter-spacing:0.03em;">Glam Galore</div>
      <div style="font-size:12px;color:#999;letter-spacing:0.03em;">ORDER #${orderNumber}</div>
    </div>

    <div style="padding:28px 0 20px;">
      <h1 style="font-size:21px;margin:0 0 10px;font-weight:600;">Your wish is our command!</h1>
      <p style="font-size:14px;color:#555;margin:0 0 20px;line-height:1.5;">We're getting your order ready to be shipped. We'll email you again once it's on its way.</p>
      <a href="${SITE_URL}/order-confirmed?orderId=${order.id}" style="display:inline-block;background:#201a16;color:#fff;padding:13px 28px;text-decoration:none;font-size:13px;letter-spacing:0.03em;text-transform:uppercase;">View your order</a>
      <p style="font-size:13px;margin-top:14px;"><a href="${SITE_URL}" style="color:#777;">or Visit our store</a></p>
    </div>

    <h2 style="font-size:13px;text-transform:uppercase;letter-spacing:0.04em;color:#999;margin:0 0 4px;padding-bottom:10px;border-bottom:1px solid #f0ede9;">Order summary</h2>
    <table style="width:100%;border-collapse:collapse;">
      ${itemRows}
    </table>

    <table style="width:100%;border-collapse:collapse;margin-top:14px;">
      <tr><td style="padding:4px 0;font-size:13px;color:#555;">Subtotal</td><td style="padding:4px 0;font-size:13px;color:#555;text-align:right;">${money(order.subtotal)}</td></tr>
      ${discountRow}
      <tr><td style="padding:4px 0;font-size:13px;color:#555;">Shipping</td><td style="padding:4px 0;font-size:13px;color:#555;text-align:right;">${Number(order.shippingCost) === 0 ? 'Free' : money(order.shippingCost)}</td></tr>
      <tr><td style="padding:12px 0 0;font-size:16px;font-weight:700;border-top:1px solid #201a16;">Total</td><td style="padding:12px 0 0;font-size:16px;font-weight:700;text-align:right;border-top:1px solid #201a16;">${money(order.total)}</td></tr>
    </table>
    <p style="font-size:12px;color:#999;text-align:right;margin-top:4px;">${isZeroTax ? 'No taxes charged on international orders' : 'Inclusive of all taxes'}</p>

    <h2 style="font-size:13px;text-transform:uppercase;letter-spacing:0.04em;color:#999;margin:28px 0 12px;padding-bottom:10px;border-bottom:1px solid #f0ede9;">Customer information</h2>
    <div>
      <p style="font-size:12px;color:#999;text-transform:uppercase;letter-spacing:0.03em;margin:0 0 4px;">Shipping address</p>
      <p style="font-size:14px;color:#201a16;margin:0 0 20px;line-height:1.5;">
        ${address.name}<br>
        ${address.line1}${address.line2 ? `<br>${address.line2}` : ''}<br>
        ${address.city}, ${address.state} ${address.pincode}<br>
        ${address.country ?? 'India'}
      </p>
    </div>

    <div style="text-align:center;padding:24px 0;margin-top:20px;border-top:1px solid #f0ede9;font-size:12px;color:#999;">
      If you have any questions, reply to this email or contact us at <a href="mailto:support@glamgalore.in" style="color:#c4322a;">support@glamgalore.in</a>
    </div>
  </div>`;

  const text = [
    `Your wish is our command! Order #${orderNumber} confirmed.`,
    `View your order: ${SITE_URL}/order-confirmed?orderId=${order.id}`,
    '',
    ...order.items.map((i) => `${i.product.title} x${i.quantity} — ${money(Number(i.unitPrice) * i.quantity)}`),
    '',
    `Subtotal: ${money(order.subtotal)}`,
    Number(order.discountAmount) > 0 ? `Discount: -${money(order.discountAmount)}` : '',
    `Shipping: ${Number(order.shippingCost) === 0 ? 'Free' : money(order.shippingCost)}`,
    `Total: ${money(order.total)}`,
    order.taxType === 'export_zero_rated' ? 'No taxes charged on international orders' : 'Inclusive of all taxes',
    '',
    `Shipping to: ${address.name}, ${address.line1}, ${address.city}, ${address.state} ${address.pincode}, ${address.country ?? 'India'}`,
    '',
    'If you have any questions, reply to this email or contact us at support@glamgalore.in',
  ]
    .filter(Boolean)
    .join('\n');

  return { subject, html, text };
}
