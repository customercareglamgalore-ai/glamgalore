'use client';

import { useEffect, useRef, useState } from 'react';

type GalleryImage = { id: string; url: string; altText?: string | null };

export default function ProductGallery({ images, alt }: { images: GalleryImage[]; alt: string }) {
  const trackRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    const slides = track.querySelectorAll('.slide');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActive(Number((entry.target as HTMLElement).dataset.index));
          }
        });
      },
      { root: track, threshold: 0.6 }
    );
    slides.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [images.length]);

  function goTo(index: number) {
    const track = trackRef.current;
    const slide = track?.children[index] as HTMLElement | undefined;
    slide?.scrollIntoView({ behavior: 'smooth', inline: 'start', block: 'nearest' });
  }

  // Slides to whichever image matches the color variant just selected in
  // ProductPurchasePanel — a separately-mounted component, so this listens
  // for a plain browser event rather than sharing state directly.
  useEffect(() => {
    function handleVariantImage(e: Event) {
      const url = (e as CustomEvent<string>).detail;
      const index = images.findIndex((img) => img.url === url);
      if (index !== -1) goTo(index);
    }
    window.addEventListener('product-variant-image', handleVariantImage);
    return () => window.removeEventListener('product-variant-image', handleVariantImage);
  }, [images]);

  return (
    <div className="product-gallery">
      <div className="gallery-track" ref={trackRef}>
        {images.map((img, i) => (
          <div className="slide" key={img.id} data-index={i}>
            <img src={img.url} alt={img.altText || alt} />
          </div>
        ))}
      </div>
      {images.length > 1 && (
        <div className="gallery-dots">
          {images.map((img, i) => (
            <button
              key={img.id}
              type="button"
              className={i === active ? 'active' : ''}
              aria-label={`Go to image ${i + 1}`}
              onClick={() => goTo(i)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
