'use client';

import { useEffect, useRef, useState } from 'react';

type GalleryImage = { id: string; url: string; altText?: string | null };

export default function ProductGallery({
  images,
  alt,
  heroVideoUrl,
}: {
  images: GalleryImage[];
  alt: string;
  heroVideoUrl?: string | null;
}) {
  const trackRef = useRef<HTMLDivElement>(null);
  const heroSlideRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  // 'static' -> waiting/holding on the photo, 'video' -> clip is playing,
  // 'done' -> clip finished, holding on the photo again for good.
  const [heroPhase, setHeroPhase] = useState<'static' | 'video' | 'done'>('static');
  const triggeredRef = useRef(false);

  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    const slides = track.querySelectorAll('.slide');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActive(Number((entry.target as HTMLElement).dataset.index));
          }
        });
      },
      { root: track, threshold: 0.6 }
    );
    slides.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [images.length]);

  function goTo(index: number) {
    const track = trackRef.current;
    const slide = track?.children[index] as HTMLElement | undefined;
    slide?.scrollIntoView({ behavior: 'smooth', inline: 'start', block: 'nearest' });
  }

  // Slides to whichever image matches the color variant just selected in
  // ProductPurchasePanel — a separately-mounted component, so this listens
  // for a plain browser event rather than sharing state directly.
  useEffect(() => {
    function handleVariantImage(e: Event) {
      const url = (e as CustomEvent<string>).detail;
      const index = images.findIndex((img) => img.url === url);
      if (index !== -1) goTo(index);
    }
    window.addEventListener('product-variant-image', handleVariantImage);
    return () => window.removeEventListener('product-variant-image', handleVariantImage);
  }, [images]);

  // Hero video reveal: once the first slide actually scrolls into view, hold
  // on the static photo briefly, play the animated clip once, then settle
  // back on the static photo for good. Triggers only once per page view —
  // scrolling away and back doesn't replay it, unlike the card animation.
  useEffect(() => {
    if (!heroVideoUrl) return;
    const el = heroSlideRef.current;
    if (!el) return;
    let timer: ReturnType<typeof setTimeout> | null = null;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !triggeredRef.current) {
          triggeredRef.current = true;
          timer = setTimeout(() => setHeroPhase('video'), 500);
        }
      },
      { threshold: 0.5 }
    );
    observer.observe(el);
    return () => {
      observer.disconnect();
      if (timer) clearTimeout(timer);
    };
  }, [heroVideoUrl]);

  return (
    <div className="product-gallery">
      <div className="gallery-track" ref={trackRef}>
        {images.map((img, i) => (
          <div className="slide" key={img.id} data-index={i} ref={i === 0 ? heroSlideRef : undefined}>
            {i === 0 && heroVideoUrl && heroPhase === 'video' ? (
              <video
                src={heroVideoUrl}
                autoPlay
                muted
                playsInline
                disablePictureInPicture
                disableRemotePlayback
                onEnded={() => setHeroPhase('done')}
                aria-label={alt}
              />
            ) : (
              <img src={img.url} alt={img.altText || alt} />
            )}
          </div>
        ))}
      </div>
      {images.length > 1 && (
        <div className="gallery-dots">
          {images.map((img, i) => (
            <button
              key={img.id}
              type="button"
              className={i === active ? 'active' : ''}
              aria-label={`Go to image ${i + 1}`}
              onClick={() => goTo(i)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
