'use client';

import { useRef, useState } from 'react';

type Review = {
  id: string;
  authorName: string;
  rating: number;
  title?: string | null;
  body: string;
  imageUrls: string[];
  verified: boolean;
};

const MAX_IMAGES = 4;

export default function ReviewForm({ productId, onSubmitted }: { productId: string; onSubmitted: (review: Review) => void }) {
  const [open, setOpen] = useState(false);
  const [authorName, setAuthorName] = useState('');
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  function handleImageSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (images.length >= MAX_IMAGES) {
      setError(`You can add up to ${MAX_IMAGES} photos`);
      return;
    }

    setUploading(true);
    setError(null);
    const formData = new FormData();
    formData.append('file', file);

    fetch('/api/reviews/upload', { method: 'POST', body: formData })
      .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
      .then(({ ok, data }) => {
        if (!ok) {
          setError(data.error || 'Could not upload that image');
          return;
        }
        setImages((prev) => [...prev, data.url]);
      })
      .catch(() => setError('Could not upload that image'))
      .finally(() => setUploading(false));
  }

  function removeImage(url: string) {
    setImages((prev) => prev.filter((u) => u !== url));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (rating < 1) {
      setError('Please select a star rating');
      return;
    }
    setSubmitting(true);
    setError(null);

    fetch('/api/reviews', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId, authorName, rating, title, body, imageUrls: images }),
    })
      .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
      .then(({ ok, data }) => {
        if (!ok) {
          setError(data.error || 'Something went wrong. Please try again.');
          setSubmitting(false);
          return;
        }
        onSubmitted(data);
        setDone(true);
        setSubmitting(false);
      })
      .catch(() => {
        setError('Something went wrong. Please try again.');
        setSubmitting(false);
      });
  }

  if (done) {
    return <p className="review-form-thanks">Thanks for sharing your review!</p>;
  }

  if (!open) {
    return (
      <button type="button" className="write-review-trigger" onClick={() => setOpen(true)}>
        Write a review
      </button>
    );
  }

  return (
    <form className="review-form" onSubmit={handleSubmit}>
      <div className="review-form-field">
        <label>Your rating</label>
        <div className="review-star-picker" role="radiogroup" aria-label="Rating">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              className="review-star-button"
              aria-label={`${n} star${n > 1 ? 's' : ''}`}
              onMouseEnter={() => setHoverRating(n)}
              onMouseLeave={() => setHoverRating(0)}
              onClick={() => setRating(n)}
            >
              {(hoverRating || rating) >= n ? '★' : '☆'}
            </button>
          ))}
        </div>
      </div>
      <div className="review-form-field">
        <label htmlFor="review-author">Name</label>
        <input id="review-author" required value={authorName} onChange={(e) => setAuthorName(e.target.value)} maxLength={80} />
      </div>
      <div className="review-form-field">
        <label htmlFor="review-title">Title (optional)</label>
        <input id="review-title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
      </div>
      <div className="review-form-field">
        <label htmlFor="review-body">Your review</label>
        <textarea id="review-body" required rows={4} value={body} onChange={(e) => setBody(e.target.value)} maxLength={2000} />
      </div>
      <div className="review-form-field">
        <label>Add photos (optional)</label>
        <div className="review-image-picker">
          {images.map((url) => (
            <div key={url} className="review-image-thumb">
              <img src={url} alt="Uploaded review photo" />
              <button type="button" aria-label="Remove photo" onClick={() => removeImage(url)}>×</button>
            </div>
          ))}
          {images.length < MAX_IMAGES && (
            <button
              type="button"
              className="review-image-add"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
            >
              {uploading ? '...' : '+'}
            </button>
          )}
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={handleImageSelect}
          style={{ display: 'none' }}
        />
      </div>
      {error && <p className="review-form-error">{error}</p>}
      <div className="review-form-actions">
        <button type="button" className="review-form-cancel" onClick={() => setOpen(false)}>Cancel</button>
        <button type="submit" className="btn" disabled={submitting}>{submitting ? 'Submitting...' : 'Submit review'}</button>
      </div>
    </form>
  );
}
