// One-off: creates the RAVELLE product — a scarlet draped maxi dress with a
// sheer overlay, plunging neckline and fitted bodysuit base, in 1 color
// (Red) x 3 sizes (S/M/L), sourced from CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Red: { S: 'CJLY307863601AZ', M: 'CJLY307863602BY', L: 'CJLY307863603CX' },
};

const HERO_IMAGE = {
  Red: '/products/ravelle/ravelle-1.png',
};

const GALLERY_IMAGES = [
  '/products/ravelle/ravelle-1.png',
  '/products/ravelle/ravelle-2.png',
  '/products/ravelle/ravelle-3.png',
  '/products/ravelle/ravelle-4.png',
  '/products/ravelle/ravelle-5.png',
];

const DESCRIPTION =
  'Ravelle is a striking scarlet maxi dress featuring a sheer flowing overlay, sculpted bodysuit, plunging neckline and delicate straps for effortless allure.';
const DESCRIPTION_HTML = `<p>${DESCRIPTION}</p>`;
const FEATURES = [
  'Material: Polyester, mesh fabrication',
  'Sheer flowing overlay for an ethereal, dramatic silhouette',
  'Plunging U-neckline for a bold, feminine finish',
  'Fitted bodysuit base for a sculpted and secure fit',
  'Draped side cutout adding a sultry touch',
  'Floor-length silhouette designed for effortless movement and glamour',
];
const SEO_TITLE = 'RAVELLE SCARLET DRAPED MAXI DRESS | Glam Galore';

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'ravelle' } });
  if (existing) {
    console.error('A product with handle "ravelle" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'ravelle',
      title: 'RAVELLE',
      descriptionHtml: DESCRIPTION_HTML,
      description: DESCRIPTION,
      features: FEATURES,
      seoTitle: SEO_TITLE,
      seoDescription: DESCRIPTION,
      type: 'Dress',
      price: 2999,
      status: 'active',
      isDropshipped: true,
      collections: ['spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created RAVELLE:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
