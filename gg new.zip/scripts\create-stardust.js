// One-off: creates the STARDUST product — a sequin lace-trim maxi dress,
// single colorway (White) x 4 sizes (S/M/L/XL), sourced from CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = { S: 'CJLY304628901AZ', M: 'CJLY304628902BY', L: 'CJLY304628903CX', XL: 'CJLY304628904DW' };
const HERO_IMAGE = '/products/stardust/stardust-2.png';
const GALLERY_IMAGES = [
  '/products/stardust/stardust-2.png', // front (studio)
  '/products/stardust/stardust-3.png', // back
  '/products/stardust/stardust-1.png', // lifestyle (beach)
];

const DESCRIPTION_TEXT = 'Shine effortlessly in the Stardust, featuring a plunging lace-trim neckline, shimmering sequins and a figure-skimming silhouette.';
const FEATURES = [
  'Material: Polyester',
  'All-over shimmering sequin mesh',
  'Plunging lace-trim V neckline',
  'Adjustable spaghetti straps',
  'Figure-skimming maxi silhouette',
  'Lightweight stretch lining for comfort',
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'stardust' } });
  if (existing) {
    console.error('A product with handle "stardust" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'stardust',
      title: 'STARDUST',
      descriptionHtml: `<p>${DESCRIPTION_TEXT}</p>`,
      description: DESCRIPTION_TEXT,
      features: FEATURES,
      type: 'Dress',
      price: 2999,
      status: 'active',
      isDropshipped: true,
      collections: ['spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).map(([size, sku]) => ({
          optionName: 'Color',
          optionValue: 'White',
          option2Name: 'Size',
          option2Value: size,
          imageUrl: HERO_IMAGE,
          sku,
        })),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created STARDUST:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
