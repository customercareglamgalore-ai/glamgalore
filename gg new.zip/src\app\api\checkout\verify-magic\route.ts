// Verifies payment for the Magic Checkout flow via the client-side handler.
// This fires when the browser stays on the page through payment completion —
// for redirect-heavy payment methods (UPI apps, netbanking, 3D-secure OTP),
// the Razorpay webhook (/api/webhooks/razorpay) is the reliable path instead,
// since it fires from Razorpay's own servers regardless of what happens in
// the browser. Both call the same completeMagicOrder(), which is idempotent,
// so whichever fires first does the work and the other is a no-op.
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { completeMagicOrder } from '@/lib/complete-magic-order';

export async function POST(req: NextRequest) {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json();

  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  if (expectedSignature !== razorpay_signature) {
    return NextResponse.json({ error: 'Payment verification failed' }, { status: 400 });
  }

  const result = await completeMagicOrder(razorpay_order_id, razorpay_payment_id, {
    clientIp: req.headers.get('x-forwarded-for'),
    userAgent: req.headers.get('user-agent'),
    fbp: req.cookies.get('_fbp')?.value,
    fbc: req.cookies.get('_fbc')?.value,
  });

  if (!result.success) {
    return NextResponse.json({ error: result.error || 'Could not complete order' }, { status: 400 });
  }
  return NextResponse.json({ success: true, orderId: result.orderId });
}
