// Undoes replace-zyvah-images.js — those new leopard/baroque photos were
// meant for a DIFFERENT product ("ZYVAH - Playsuit", handle zyvah-playsuit),
// not this one. Restores ZYVAH's original images and per-variant imageUrl
// exactly as they were before that script ran (legacy cdn.shopify.com URLs,
// same position values).
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const ORIGINAL_IMAGES = [
  { url: 'https://cdn.shopify.com/s/files/1/0707/4968/3991/files/6_6a8d56f7-f397-46bc-a181-ca818b056a42.png?v=1754459819', position: 1 },
  { url: 'https://cdn.shopify.com/s/files/1/0707/4968/3991/files/5_ac746b38-8b4c-4ef8-aacc-a09b7cf0b227.png?v=1754459819', position: 2 },
  { url: 'https://cdn.shopify.com/s/files/1/0707/4968/3991/files/4_6ab2a726-2544-4f60-9fea-453cdf20aa78.png?v=1754459819', position: 3 },
  { url: 'https://cdn.shopify.com/s/files/1/0707/4968/3991/files/1_2c86f4db-f9da-46fc-b0c4-d41facdc4225.png?v=1754459819', position: 4 },
  { url: 'https://cdn.shopify.com/s/files/1/0707/4968/3991/files/2_c6a7e9e2-54e8-46b4-94a4-f47e3b1ae713.png?v=1754459819', position: 5 },
  { url: 'https://cdn.shopify.com/s/files/1/0707/4968/3991/files/3_d752e1ff-9c63-49f9-886c-e453fe56b686.png?v=1754459819', position: 6 },
];

const VARIANT_IMAGE_BY_COLOR = {
  'Brown - Floral': 'https://cdn.shopify.com/s/files/1/0707/4968/3991/files/6_6a8d56f7-f397-46bc-a181-ca818b056a42.png?v=1754459819',
  'Brown - Blue': 'https://cdn.shopify.com/s/files/1/0707/4968/3991/files/1_2c86f4db-f9da-46fc-b0c4-d41facdc4225.png?v=1754459819',
};

async function main() {
  const product = await prisma.product.findUnique({ where: { handle: 'zyvah' }, include: { images: true, variants: true } });
  if (!product) {
    console.error('No product with handle "zyvah" found.');
    process.exit(1);
  }

  await prisma.productImage.deleteMany({ where: { productId: product.id } });
  await prisma.productImage.createMany({
    data: ORIGINAL_IMAGES.map((img) => ({ productId: product.id, url: img.url, position: img.position })),
  });

  for (const variant of product.variants) {
    const imageUrl = VARIANT_IMAGE_BY_COLOR[variant.optionValue];
    if (imageUrl) {
      await prisma.productVariant.update({ where: { id: variant.id }, data: { imageUrl } });
    }
  }

  console.log('Restored ZYVAH images:', ORIGINAL_IMAGES.length, 'original photos');
  console.log('Re-pointed variants back to their original per-color images');
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
