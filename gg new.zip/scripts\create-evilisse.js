// One-off: creates the EVILISSE product — an off-shoulder draped maxi dress
// with a twisted waist cutout, in 2 colors (Black, Yellow) x 3 sizes
// (S/M/L), sourced from CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Black: { S: 'CJLY307855304DW', M: 'CJLY307855305EV', L: 'CJLY307855306FU' },
  Yellow: { S: 'CJLY307855301AZ', M: 'CJLY307855302BY', L: 'CJLY307855303CX' },
};

const HERO_IMAGE = {
  Black: '/products/evilisse/evilisse-1.png',
  Yellow: '/products/evilisse/evilisse-4.png',
};

const GALLERY_IMAGES = [
  '/products/evilisse/evilisse-1.png', // Black front
  '/products/evilisse/evilisse-2.png', // Black back
  '/products/evilisse/evilisse-3.png', // Black side
  '/products/evilisse/evilisse-4.png', // Yellow detail
  '/products/evilisse/evilisse-5.png', // Yellow front
  '/products/evilisse/evilisse-6.png', // Yellow back
];

const DESCRIPTION =
  'Evilisse is a dreamy lemon-yellow maxi dress featuring an off-shoulder drape, twisted waist cutout and fluid silhouette for an effortlessly feminine look.';
const DESCRIPTION_HTML = `<p>${DESCRIPTION}</p>`;
const FEATURES = [
  'Material: Polyester, mesh fabrication',
  'Off-shoulder draped neckline for a soft, romantic finish',
  'Twisted waist detailing creates an elegant, sculpted silhouette',
  'Asymmetrical cutout design adds a subtle, alluring touch',
  'Floor-length flowing skirt for graceful movement',
  'Lightweight, fluid fabric with a soft, luxe drape',
];
const SEO_TITLE = 'EVILISSE DRAPED MAXI DRESS | Glam Galore';

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'evilisse' } });
  if (existing) {
    console.error('A product with handle "evilisse" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'evilisse',
      title: 'EVILISSE',
      descriptionHtml: DESCRIPTION_HTML,
      description: DESCRIPTION,
      features: FEATURES,
      seoTitle: SEO_TITLE,
      seoDescription: DESCRIPTION,
      type: 'Dress',
      price: 2999,
      status: 'active',
      isDropshipped: true,
      collections: ['spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created EVILISSE:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
