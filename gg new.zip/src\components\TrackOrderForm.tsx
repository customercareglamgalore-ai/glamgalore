'use client';

import { useState } from 'react';

type TrackingCheckpoint = { status: string; message: string; location?: string; time: string };
type DeliveryEstimate = {
  estimatedStart: string;
  estimatedEnd: string;
  isDelivered: boolean;
  isDelayed: boolean;
  progress: number;
  disclaimer: string;
};
type TrackOrderResult = {
  orderId: string;
  invoiceNumber: string | null;
  status: string;
  paymentStatus: string;
  createdAt: string;
  trackingNumber: string | null;
  trackingCarrier: string | null;
  items: { title: string; quantity: number }[];
  tracking: { status?: string; checkpoints?: TrackingCheckpoint[] } | null;
  delivery: DeliveryEstimate;
};

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

const STATUS_LABEL: Record<string, string> = {
  pending: 'Payment pending',
  paid: 'Paid — preparing your order',
  fulfilling: 'Preparing for shipment',
  shipped: 'Shipped',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
};

export default function TrackOrderForm() {
  const [contactMethod, setContactMethod] = useState<'email' | 'phone'>('email');
  const [form, setForm] = useState({ orderNumber: '', email: '', phone: '' });
  const [status, setStatus] = useState<'idle' | 'loading' | 'done'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<TrackOrderResult | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus('loading');
    setError(null);
    setResult(null);

    const res = await fetch('/api/track-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        orderNumber: form.orderNumber,
        email: contactMethod === 'email' ? form.email : undefined,
        phone: contactMethod === 'phone' ? form.phone : undefined,
      }),
    });
    const data = await res.json();

    if (!res.ok) {
      setError(data.error || 'Something went wrong. Please try again.');
      setStatus('idle');
      return;
    }

    setResult(data);
    setStatus('done');
  }

  return (
    <div>
      <form onSubmit={handleSubmit} className="contact-form">
        {error && <p className="contact-form-error">{error}</p>}
        <input
          placeholder="Order number (e.g. GG-000123)"
          value={form.orderNumber}
          onChange={(e) => setForm({ ...form, orderNumber: e.target.value })}
          required
        />
        <div className="track-order-contact-toggle">
          <button
            type="button"
            className={contactMethod === 'email' ? 'active' : ''}
            onClick={() => setContactMethod('email')}
          >
            Email
          </button>
          <button
            type="button"
            className={contactMethod === 'phone' ? 'active' : ''}
            onClick={() => setContactMethod('phone')}
          >
            Phone number
          </button>
        </div>
        {contactMethod === 'email' ? (
          <input
            type="email"
            placeholder="Email used at checkout"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            required
          />
        ) : (
          <input
            type="tel"
            placeholder="Phone number used at checkout"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            required
          />
        )}
        <button type="submit" className="btn contact-form-submit" disabled={status === 'loading'}>
          {status === 'loading' ? 'Looking up...' : 'Track Order'}
        </button>
      </form>

      {result && (
        <div className="track-order-result">
          <p className="track-order-status">{STATUS_LABEL[result.status] ?? result.status}</p>

          {!result.delivery.isDelivered && (
            <div className={`delivery-estimate ${result.delivery.isDelayed ? 'delivery-estimate--delayed' : ''}`}>
              {result.delivery.isDelayed ? (
                <>
                  <span className="delivery-estimate-badge">Order Delayed</span>
                  <p className="delivery-estimate-copy">
                    Your order has passed our standard delivery window. We&apos;re following up with our fulfillment
                    partner on your behalf — thank you for bearing with us.
                  </p>
                </>
              ) : (
                <>
                  <span className="delivery-estimate-label">Estimated Delivery</span>
                  <p className="delivery-estimate-range">
                    {formatDate(result.delivery.estimatedStart)} – {formatDate(result.delivery.estimatedEnd)}
                  </p>
                  <div className="delivery-estimate-bar">
                    <div className="delivery-estimate-bar-fill" style={{ width: `${result.delivery.progress * 100}%` }} />
                  </div>
                </>
              )}
              <p className="delivery-estimate-disclaimer">{result.delivery.disclaimer}</p>
            </div>
          )}

          <ul className="track-order-items">
            {result.items.map((item, i) => (
              <li key={i}>{item.title} × {item.quantity}</li>
            ))}
          </ul>

          {result.trackingNumber && (
            <div className="track-order-tracking">
              <p><strong>Carrier:</strong> {result.trackingCarrier || 'Assigned by fulfillment partner'}</p>
              <p><strong>Tracking number:</strong> {result.trackingNumber}</p>
              {result.tracking?.checkpoints && result.tracking.checkpoints.length > 0 && (
                <ul className="track-order-checkpoints">
                  {result.tracking.checkpoints.map((cp, i) => (
                    <li key={i}>
                      <span className="track-order-checkpoint-time">{new Date(cp.time).toLocaleString('en-IN')}</span>
                      <span>{cp.message}{cp.location ? ` — ${cp.location}` : ''}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
