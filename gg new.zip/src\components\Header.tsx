'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { CATEGORY_LINKS, COLLECTION_LINKS } from '@/lib/collections';
import SearchModal from '@/components/SearchModal';
import { CART_UPDATED_EVENT, getCartCount } from '@/lib/cart-count';
import { WISHLIST_UPDATED_EVENT, getWishlistHandles } from '@/lib/wishlist';

type Group = 'collection' | 'category';

export default function Header() {
  const pathname = usePathname();
  const isHome = pathname === '/';
  const [menuOpen, setMenuOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState<Group | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [wishlistCount, setWishlistCount] = useState(0);

  useEffect(() => {
    setCartCount(getCartCount());
    function handleUpdate() {
      setCartCount(getCartCount());
    }
    window.addEventListener(CART_UPDATED_EVENT, handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener(CART_UPDATED_EVENT, handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  useEffect(() => {
    setWishlistCount(getWishlistHandles().length);
    function handleUpdate() {
      setWishlistCount(getWishlistHandles().length);
    }
    window.addEventListener(WISHLIST_UPDATED_EVENT, handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener(WISHLIST_UPDATED_EVENT, handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  function closeAll() {
    setMenuOpen(false);
    setOpenGroup(null);
  }

  function toggleGroup(group: Group) {
    setOpenGroup((current) => (current === group ? null : group));
  }

  function renderGroup(group: Group, label: string, links: { href: string; title: string }[]) {
    return (
      <div className={`nav-group ${openGroup === group ? 'open' : ''}`}>
        <button type="button" className="nav-group-toggle" onClick={() => toggleGroup(group)}>
          {label}
        </button>
        <div className="nav-dropdown">
          {links.map((c) => (
            <Link key={c.href} href={c.href} onClick={closeAll}>{c.title}</Link>
          ))}
        </div>
      </div>
    );
  }

  return (
    <header className={`site-header ${isHome ? 'site-header--overlay' : ''}`}>
      <div className="header-side header-side--left">
        <button
          className="menu-toggle"
          aria-label="Menu"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
        >
          {menuOpen ? (
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
              <line x1="5" y1="5" x2="19" y2="19" />
              <line x1="19" y1="5" x2="5" y2="19" />
            </svg>
          ) : (
            <span style={{ fontSize: '20px', lineHeight: 1 }} aria-hidden="true">&#129293;</span>
          )}
        </button>

        <nav className="desktop-nav desktop-nav--left">
          <Link href="/" onClick={closeAll}>Home</Link>
          {renderGroup('category', 'Shop by Category', CATEGORY_LINKS)}
          {renderGroup('collection', 'Shop by Collection', COLLECTION_LINKS)}
        </nav>
      </div>

      <Link href="/" className="logo" onClick={closeAll}>Glam Galore</Link>

      <div className="header-side header-side--right">
        <nav className="desktop-nav desktop-nav--right">
          <Link href="/contact" onClick={closeAll}>Contact Us</Link>
          <Link href="/track-order" onClick={closeAll}>Track Your Order</Link>
        </nav>

        <div className="header-icons">
          <button type="button" aria-label="Search" onClick={() => setSearchOpen(true)}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <circle cx="11" cy="11" r="7" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
          </button>
          <Link href="/account" aria-label="Account" className="account-icon-link">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="8" r="4" />
              <path d="M4 21c0-4 4-6 8-6s8 2 8 6" />
            </svg>
          </Link>
          <Link href="/wishlist" aria-label="Wishlist" className="wishlist-icon-link">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 21s-7.5-4.8-10-9.3C.5 8.2 2.3 4.5 6 4.5c2.1 0 3.7 1.1 6 3.5 2.3-2.4 3.9-3.5 6-3.5 3.7 0 5.5 3.7 4 7.2C19.5 16.2 12 21 12 21Z" />
            </svg>
            {wishlistCount > 0 && <span className="cart-count-badge">{wishlistCount}</span>}
          </Link>
          <Link href="/cart" aria-label="Cart" data-cart-icon className="cart-icon-link">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 8h12l-1 12H7L6 8Z" />
              <path d="M9 8V6a3 3 0 0 1 6 0v2" />
            </svg>
            {cartCount > 0 && <span className="cart-count-badge">{cartCount}</span>}
          </Link>
        </div>
      </div>

      <nav className={`mobile-nav ${menuOpen ? 'open' : ''}`}>
        <Link href="/" onClick={closeAll}>Home</Link>
        {renderGroup('category', 'Shop by Category', CATEGORY_LINKS)}
        {renderGroup('collection', 'Shop by Collection', COLLECTION_LINKS)}
        <Link href="/contact" onClick={closeAll}>Contact Us</Link>
        <Link href="/track-order" onClick={closeAll}>Track Your Order</Link>
        <Link href="/account" onClick={closeAll}>Account</Link>
      </nav>

      {searchOpen && <SearchModal onClose={() => setSearchOpen(false)} />}

      {(menuOpen || openGroup) &&
        typeof document !== 'undefined' &&
        createPortal(<button type="button" className="nav-backdrop" aria-label="Close menu" onClick={closeAll} />, document.body)}
    </header>
  );
}
