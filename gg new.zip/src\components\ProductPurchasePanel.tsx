'use client';

import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import SizeGuideModal from './SizeGuideModal';
import { trackMetaEvent } from './MetaPixel';
import { flyProductToCart } from '@/lib/cart-fly-animation';
import { notifyCartUpdated } from '@/lib/cart-count';
import WishlistButton from './WishlistButton';

type Variant = {
  id: string;
  optionName?: string | null;
  optionValue: string | null;
  option2Name?: string | null;
  option2Value: string | null;
  swatchHex: string | null;
  imageUrl: string | null;
};

function addToCart(productId: string, variantId: string | undefined, cart: any[]) {
  const existing = cart.find(
    (item) => item.productId === productId && item.variantId === variantId
  );
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ productId, variantId, quantity: 1 });
  }
  return cart;
}

export default function ProductPurchasePanel({
  productId,
  handle,
  title,
  price,
  variants,
  lowStockMessage,
}: {
  productId: string;
  handle: string;
  title: string;
  price: number;
  variants: Variant[];
  lowStockMessage?: string;
}) {
  const router = useRouter();
  const [added, setAdded] = useState(false);
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false);

  // Some products have Color/Size in the opposite field order (an import
  // quirk from the original export) -- detect that from the option names
  // rather than assuming position, so the right field always renders as
  // the "Color" image-swatch picker.
  const reversed = /^size$/i.test(variants[0]?.optionName || '') && /colou?r/i.test(variants[0]?.option2Name || '');

  function colorOf(v: Variant) {
    return reversed ? v.option2Value : v.optionValue;
  }
  function sizeOf(v: Variant) {
    return reversed ? v.optionValue : v.option2Value;
  }

  const colors = useMemo(
    () => [...new Set(variants.map(colorOf).filter(Boolean))] as string[],
    [variants]
  );
  const sizes = useMemo(
    () => [...new Set(variants.map(sizeOf).filter(Boolean))] as string[],
    [variants]
  );

  const [selectedColor, setSelectedColor] = useState(colors[0] ?? null);
  const [selectedSize, setSelectedSize] = useState(sizes[0] ?? null);

  const selectedVariant = useMemo(
    () =>
      variants.find(
        (v) =>
          (colors.length === 0 || colorOf(v) === selectedColor) &&
          (sizes.length === 0 || sizeOf(v) === selectedSize)
      ),
    [variants, colors, sizes, selectedColor, selectedSize]
  );

  function trackAddToCart() {
    trackMetaEvent('AddToCart', {
      content_ids: [productId],
      content_name: title,
      content_type: 'product',
      value: price,
      currency: 'INR',
    });
  }

  function handleAddToCart() {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    addToCart(productId, selectedVariant?.id, cart);
    localStorage.setItem('cart', JSON.stringify(cart));
    notifyCartUpdated();
    trackAddToCart();
    flyProductToCart();
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  }

  function handleBuyItNow() {
    const cart = addToCart(productId, selectedVariant?.id, []);
    localStorage.setItem('cart', JSON.stringify(cart));
    notifyCartUpdated();
    trackAddToCart();
    router.push('/cart');
  }

  return (
    <div className="purchase-panel">
      {colors.length > 0 && (
        <fieldset className="variant-picker variant-picker--swatches">
          <legend>Color{selectedColor ? ` — ${selectedColor}` : ''}</legend>
          {colors.map((color) => {
            const variant = variants.find((v) => colorOf(v) === color);
            return (
              <label
                key={color}
                className={`image-swatch ${color === selectedColor ? 'selected' : ''}`}
                title={color}
              >
                <input
                  type="radio"
                  name="color"
                  value={color}
                  checked={color === selectedColor}
                  onChange={() => setSelectedColor(color)}
                />
                {variant?.imageUrl ? (
                  <img src={variant.imageUrl} alt={color} />
                ) : variant?.swatchHex ? (
                  <span className="swatch" style={{ background: variant.swatchHex }} />
                ) : (
                  <span className="image-swatch-fallback">{color}</span>
                )}
              </label>
            );
          })}
        </fieldset>
      )}

      {sizes.length > 0 && (
        <fieldset className="variant-picker">
          <legend>Size</legend>
          {sizes.map((size) => (
            <label key={size} className={size === selectedSize ? 'selected' : ''}>
              <input
                type="radio"
                name="size"
                value={size}
                checked={size === selectedSize}
                onChange={() => setSelectedSize(size)}
              />
              {size}
            </label>
          ))}
        </fieldset>
      )}

      {sizes.length > 0 && lowStockMessage && (
        <p className="low-stock-message">{lowStockMessage}</p>
      )}

      {sizes.length > 0 && (
        <button type="button" className="size-guide-trigger" onClick={() => setSizeGuideOpen(true)}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="7" width="20" height="10" rx="1" />
            <line x1="6" y1="7" x2="6" y2="10" />
            <line x1="10" y1="7" x2="10" y2="12" />
            <line x1="14" y1="7" x2="14" y2="10" />
            <line x1="18" y1="7" x2="18" y2="12" />
          </svg>
          Size Guide
        </button>
      )}

      <div className="purchase-actions-row">
        <button className="add-to-cart" onClick={handleAddToCart}>
          {added ? 'Added to cart' : 'Add to cart'}
        </button>
        <WishlistButton handle={handle} className="product-panel-wishlist" />
      </div>
      <button className="btn buy-it-now" onClick={handleBuyItNow}>
        Buy it now
      </button>

      {sizeGuideOpen && <SizeGuideModal onClose={() => setSizeGuideOpen(false)} />}
    </div>
  );
}
