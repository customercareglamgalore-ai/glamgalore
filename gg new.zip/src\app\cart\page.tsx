'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import Script from 'next/script';
import Reveal from '@/components/Reveal';
import { notifyCartUpdated } from '@/lib/cart-count';

type CartItem = {
  productId: string;
  variantId?: string;
  quantity: number;
  title?: string;
  variantLabel?: string;
  price?: string;
  imageUrl?: string;
};

function sameLine(a: CartItem, b: CartItem) {
  return a.productId === b.productId && (a.variantId || null) === (b.variantId || null);
}

export default function CartPage() {
  const [items, setItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [discountCode, setDiscountCode] = useState('');

  function hydrateAndSet(raw: CartItem[]) {
    return fetch('/api/cart/hydrate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: raw }),
    })
      .then((res) => res.json())
      .then((data) => setItems(data.items));
  }

  useEffect(() => {
    const raw = JSON.parse(localStorage.getItem('cart') || '[]') as CartItem[];
    hydrateAndSet(raw).finally(() => setLoading(false));
  }, []);

  function persistCart(nextItems: CartItem[]) {
    const raw = nextItems.map(({ productId, variantId, quantity }) => ({ productId, variantId, quantity }));
    localStorage.setItem('cart', JSON.stringify(raw));
    notifyCartUpdated();
    hydrateAndSet(raw);
  }

  function changeQuantity(item: CartItem, delta: number) {
    const nextQuantity = item.quantity + delta;
    if (nextQuantity <= 0) {
      persistCart(items.filter((i) => !sameLine(i, item)));
      return;
    }
    persistCart(items.map((i) => (sameLine(i, item) ? { ...i, quantity: nextQuantity } : i)));
  }

  function removeItem(item: CartItem) {
    persistCart(items.filter((i) => !sameLine(i, item)));
  }

  const total = items.reduce((sum, i) => sum + Number(i.price || 0) * i.quantity, 0);

  function handleCheckout() {
    setSubmitting(true);
    setError(null);

    const cartItems = JSON.parse(localStorage.getItem('cart') || '[]');

    fetch('/api/checkout/create-magic-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cartItems, discountCode }),
    })
      .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
      .then(({ ok, data }) => {
        if (!ok) {
          setError(data.error || 'Something went wrong. Please try again.');
          setSubmitting(false);
          return;
        }

        const options = {
          key: data.keyId,
          amount: data.amount,
          currency: data.currency,
          name: 'Glam Galore',
          order_id: data.razorpayOrderId,
          one_click_checkout: true,
          show_coupons: false,
          theme: { color: '#000000' },
          handler: function (response: any) {
            fetch('/api/checkout/verify-magic', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(response),
            })
              .then((res) => res.json())
              .then((result) => {
                if (result.success) {
                  localStorage.removeItem('cart');
                  notifyCartUpdated();
                  window.location.href = `/order-confirmed?orderId=${result.orderId}`;
                } else {
                  setError('Payment received, but confirming your order failed. Please contact support with your payment ID.');
                }
              });
          },
          modal: {
            ondismiss: function () {
              setSubmitting(false);
            },
          },
        };

        const rzp = new (window as any).Razorpay(options);
        rzp.open();
        setSubmitting(false);
      })
      .catch(() => {
        setError('Something went wrong starting checkout. Please try again.');
        setSubmitting(false);
      });
  }

  if (loading) return <main className="container"><p>Loading your cart...</p></main>;

  if (items.length === 0) {
    return (
      <main className="container">
        <h1 className="section-heading">Your cart is empty</h1>
        <p style={{ textAlign: 'center' }}><Link href="/" className="btn">Continue shopping</Link></p>
      </main>
    );
  }

  return (
    <main className="container">
      <Script src="https://checkout.razorpay.com/v1/magic-checkout.js" strategy="afterInteractive" />
      <Reveal>
        <h1 className="section-heading">Your Cart</h1>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {items.map((item) => (
            <li
              key={`${item.productId}-${item.variantId || 'default'}`}
              style={{ display: 'flex', gap: 16, borderTop: '1px solid #eee', padding: '16px 0', alignItems: 'flex-start' }}
            >
              {item.imageUrl && <img src={item.imageUrl} alt={item.title} style={{ width: 80, height: 100, objectFit: 'cover' }} />}
              <div style={{ flex: 1 }}>
                <p>{item.title}</p>
                {item.variantLabel && <p style={{ color: '#777', fontSize: '0.85rem' }}>{item.variantLabel}</p>}
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '8px 0' }}>
                  <div style={{ display: 'flex', alignItems: 'center', border: '1px solid #ccc' }}>
                    <button
                      type="button"
                      aria-label="Decrease quantity"
                      onClick={() => changeQuantity(item, -1)}
                      style={{ width: 28, height: 28, border: 'none', background: '#f5f5f5', color: '#000', cursor: 'pointer', fontSize: 16 }}
                    >
                      −
                    </button>
                    <span style={{ width: 32, textAlign: 'center', fontSize: 14 }}>{item.quantity}</span>
                    <button
                      type="button"
                      aria-label="Increase quantity"
                      onClick={() => changeQuantity(item, 1)}
                      style={{ width: 28, height: 28, border: 'none', background: '#f5f5f5', color: '#000', cursor: 'pointer', fontSize: 16 }}
                    >
                      +
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem(item)}
                    style={{ border: 'none', background: 'none', color: '#e22120', cursor: 'pointer', fontSize: 13, textDecoration: 'underline', padding: 0 }}
                  >
                    Remove
                  </button>
                </div>
                <p>₹{item.price}</p>
              </div>
            </li>
          ))}
        </ul>
        <p style={{ textAlign: 'right', fontSize: '1.1rem' }}>Total: ₹{total.toFixed(2)}</p>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, margin: '12px 0' }}>
          <input
            placeholder="Discount code"
            value={discountCode}
            onChange={(e) => setDiscountCode(e.target.value)}
            style={{ padding: 8, border: '1px solid #ccc', fontSize: 13, maxWidth: 200 }}
          />
        </div>
        {error && <p style={{ color: '#e22120', textAlign: 'right' }}>{error}</p>}
        <p style={{ textAlign: 'right' }}>
          <button type="button" className="btn" onClick={handleCheckout} disabled={submitting}>
            {submitting ? 'Processing...' : 'Checkout'}
          </button>
        </p>
      </Reveal>
    </main>
  );
}
