'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import WishlistButton from './WishlistButton';

type ProductCardData = {
  handle: string;
  title: string;
  price: number | string;
  compareAtPrice?: number | string | null;
  images: string[];
  isOutOfStock?: boolean;
};

export default function ProductCard({ product }: { product: ProductCardData }) {
  const [index, setIndex] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const imageWrapRef = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);

  function startCycle() {
    if (product.images.length <= 1) return;
    if (timerRef.current) clearInterval(timerRef.current);
    let i = 0;
    timerRef.current = setInterval(() => {
      i = (i + 1) % product.images.length;
      setIndex(i);
    }, 700);
  }

  function stopCycle() {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
    setIndex(0);
  }

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // A gentle breathing zoom on the card photo, only while it's actually on
  // screen — toggling the class off (rather than just pausing) resets it to
  // scale(1), so scrolling away and back always replays it fresh instead of
  // resuming mid-cycle.
  useEffect(() => {
    const el = imageWrapRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting),
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <Link
      href={`/products/${product.handle}`}
      className="product-card"
      onMouseEnter={startCycle}
      onMouseLeave={stopCycle}
      onTouchStart={startCycle}
      onTouchEnd={stopCycle}
    >
      <div className={`image-wrap ${inView ? 'image-wrap--in-view' : ''}`} ref={imageWrapRef}>
        {product.images[index] && <img src={product.images[index]} alt={product.title} loading="lazy" />}
        {product.isOutOfStock && <span className="sold-out-badge">Sold Out</span>}
        <WishlistButton handle={product.handle} className="product-card-wishlist" />
      </div>
      <p className="title">{product.title}</p>
      <p className="price">
        {product.compareAtPrice && Number(product.compareAtPrice) > Number(product.price) && (
          <span className="compare-price">₹{product.compareAtPrice}</span>
        )}
        ₹{product.price}
      </p>
    </Link>
  );
}
