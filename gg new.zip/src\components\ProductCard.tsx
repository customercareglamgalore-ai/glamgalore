'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import WishlistButton from './WishlistButton';

type ProductCardData = {
  handle: string;
  title: string;
  price: number | string;
  compareAtPrice?: number | string | null;
  images: string[];
  isOutOfStock?: boolean;
  heroVideoUrl?: string | null;
};

export default function ProductCard({ product }: { product: ProductCardData }) {
  const [index, setIndex] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const cardRef = useRef<HTMLAnchorElement>(null);

  // 'static' -> waiting/holding on the photo, 'video' -> clip is playing,
  // 'done' -> clip finished, holding on the photo again for good. Only
  // relevant when heroVideoUrl is set; otherwise stays 'done' forever and
  // the card behaves exactly as it did before this feature existed.
  const [heroPhase, setHeroPhase] = useState<'static' | 'video' | 'done'>(product.heroVideoUrl ? 'static' : 'done');
  const triggeredRef = useRef(false);

  function startCycle() {
    // Don't let hover-cycling fight with the hero video reveal — once the
    // clip has played (or if this card has no video at all), it behaves
    // exactly like before.
    if (heroPhase !== 'done') return;
    if (product.images.length <= 1) return;
    if (timerRef.current) clearInterval(timerRef.current);
    let i = 0;
    timerRef.current = setInterval(() => {
      i = (i + 1) % product.images.length;
      setIndex(i);
    }, 700);
  }

  function stopCycle() {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
    setIndex(0);
  }

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // Reveal-on-scroll: once the card actually scrolls into view, hold on the
  // static photo briefly, play the animated clip once, then settle back on
  // the static photo for good. Triggers only once per page view.
  useEffect(() => {
    if (!product.heroVideoUrl) return;
    const el = cardRef.current;
    if (!el) return;
    let timer: ReturnType<typeof setTimeout> | null = null;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !triggeredRef.current) {
          triggeredRef.current = true;
          timer = setTimeout(() => setHeroPhase('video'), 500);
        }
      },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => {
      observer.disconnect();
      if (timer) clearTimeout(timer);
    };
  }, [product.heroVideoUrl]);

  return (
    <Link
      href={`/products/${product.handle}`}
      className="product-card"
      ref={cardRef}
      onMouseEnter={startCycle}
      onMouseLeave={stopCycle}
      onTouchStart={startCycle}
      onTouchEnd={stopCycle}
    >
      <div className="image-wrap">
        {product.heroVideoUrl && heroPhase === 'video' ? (
          <video
            src={product.heroVideoUrl}
            autoPlay
            muted
            playsInline
            disablePictureInPicture
            disableRemotePlayback
            onEnded={() => setHeroPhase('done')}
            aria-label={product.title}
          />
        ) : (
          product.images[index] && <img src={product.images[index]} alt={product.title} loading="lazy" />
        )}
        {product.isOutOfStock && <span className="sold-out-badge">Sold Out</span>}
        <WishlistButton handle={product.handle} className="product-card-wishlist" />
      </div>
      <p className="title">{product.title}</p>
      <p className="price">
        {product.compareAtPrice && Number(product.compareAtPrice) > Number(product.price) && (
          <span className="compare-price">₹{product.compareAtPrice}</span>
        )}
        ₹{product.price}
      </p>
    </Link>
  );
}
