'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import WishlistButton from './WishlistButton';

type ProductCardData = {
  handle: string;
  title: string;
  price: number | string;
  compareAtPrice?: number | string | null;
  images: string[];
  isOutOfStock?: boolean;
  heroVideoUrl?: string | null;
};

export default function ProductCard({ product }: { product: ProductCardData }) {
  const [index, setIndex] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const cardRef = useRef<HTMLAnchorElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const triggeredRef = useRef(false);

  // The photo stays visible underneath the whole time — the video only
  // actually covers it once the browser confirms real frames are being
  // painted (the 'playing' event), never on a timer alone. That guarantees
  // there's never a blank gap between "photo hidden" and "video has
  // something to show", which a timer-based swap can't promise on slower
  // connections/devices.
  const [showVideo, setShowVideo] = useState(false);
  const [videoDone, setVideoDone] = useState(false);

  function startCycle() {
    // Don't let hover-cycling fight with the hero video reveal.
    if (showVideo) return;
    if (product.images.length <= 1) return;
    if (timerRef.current) clearInterval(timerRef.current);
    let i = 0;
    timerRef.current = setInterval(() => {
      i = (i + 1) % product.images.length;
      setIndex(i);
    }, 700);
  }

  function stopCycle() {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
    setIndex(0);
  }

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // Reveal-on-scroll: once the card actually scrolls into view, wait
  // briefly, then attempt to play the clip. Triggers only once per page
  // view. If autoplay is ever blocked, this just never fires 'playing' and
  // the photo stays put — never a blank card.
  useEffect(() => {
    if (!product.heroVideoUrl) return;
    const el = cardRef.current;
    if (!el) return;
    let timer: ReturnType<typeof setTimeout> | null = null;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !triggeredRef.current) {
          triggeredRef.current = true;
          timer = setTimeout(() => {
            videoRef.current?.play().catch(() => {});
          }, 500);
        }
      },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => {
      observer.disconnect();
      if (timer) clearTimeout(timer);
    };
  }, [product.heroVideoUrl]);

  // preload="auto" alone doesn't reliably paint a visible frame in every
  // browser — same fix already proven for the Reels thumbnails elsewhere in
  // this codebase: nudge currentTime once data is available to force a real
  // frame to render, so playback starts from something visible immediately.
  function handleLoadedData() {
    const video = videoRef.current;
    if (video && video.currentTime === 0) video.currentTime = 0.05;
  }

  function handleEnded() {
    setShowVideo(false);
    setVideoDone(true);
    videoRef.current?.pause();
  }

  return (
    <Link
      href={`/products/${product.handle}`}
      className="product-card"
      ref={cardRef}
      onMouseEnter={startCycle}
      onMouseLeave={stopCycle}
      onTouchStart={startCycle}
      onTouchEnd={stopCycle}
    >
      <div className="image-wrap">
        {product.images[index] && <img src={product.images[index]} alt={product.title} loading="lazy" />}
        {product.heroVideoUrl && !videoDone && (
          <video
            ref={videoRef}
            src={product.heroVideoUrl}
            muted
            playsInline
            controls={false}
            disablePictureInPicture
            disableRemotePlayback
            preload="auto"
            onLoadedData={handleLoadedData}
            onPlaying={() => setShowVideo(true)}
            onEnded={handleEnded}
            aria-label={product.title}
            style={{ opacity: showVideo ? 1 : 0 }}
          />
        )}
        {product.isOutOfStock && <span className="sold-out-badge">Sold Out</span>}
        <WishlistButton handle={product.handle} className="product-card-wishlist" />
      </div>
      <p className="title">{product.title}</p>
      <p className="price">
        {product.compareAtPrice && Number(product.compareAtPrice) > Number(product.price) && (
          <span className="compare-price">₹{product.compareAtPrice}</span>
        )}
        ₹{product.price}
      </p>
    </Link>
  );
}
