// Verifies the Razorpay payment signature server-side after checkout.
// This step is mandatory: without it, someone could call your "mark as paid"
// endpoint directly and get free orders. Never mark an order paid based on
// what the browser tells you — only after this signature check passes.
//
// Actual completion (customer re-point, GST recompute, invoice, CJ
// submission, emails) is handled by the shared completeOrder() in
// complete-order.ts — the same function the Razorpay webhook calls, so
// whichever fires first for a given payment does the work and the other is
// a no-op.
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { completeOrder } from '@/lib/complete-order';

export async function POST(req: NextRequest) {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json();

  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  if (expectedSignature !== razorpay_signature) {
    return NextResponse.json({ error: 'Payment verification failed' }, { status: 400 });
  }

  const result = await completeOrder(razorpay_order_id, razorpay_payment_id, {
    clientIp: req.headers.get('x-forwarded-for'),
    userAgent: req.headers.get('user-agent'),
    fbp: req.cookies.get('_fbp')?.value,
    fbc: req.cookies.get('_fbc')?.value,
  });

  if (!result.success) {
    return NextResponse.json({ error: result.error || 'Could not complete order' }, { status: 400 });
  }
  return NextResponse.json({ success: true, orderId: result.orderId });
}
