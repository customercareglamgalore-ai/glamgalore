// Verifies the Razorpay payment signature server-side after checkout.
// This step is mandatory: without it, someone could call your "mark as paid"
// endpoint directly and get free orders. Never mark an order paid based on
// what the browser tells you — only after this signature check passes.

import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { prisma } from '@/lib/db';
import { submitOrderToCJ } from '@/lib/cj-dropshipping';
import { allocateInvoiceNumber } from '@/lib/invoice-numbering';
import { generateInvoicePdf } from '@/lib/invoice-pdf';
import { sendMail } from '@/lib/email';
import { buildOrderConfirmationEmail } from '@/lib/email-templates/order-confirmation';
import { buildAdminOrderNotificationEmail } from '@/lib/email-templates/admin-order-notification';
import { sendMetaPurchaseEvent } from '@/lib/meta-capi';
import { recordDiscountUsage } from '@/lib/discounts';

export async function POST(req: NextRequest) {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json();

  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  if (expectedSignature !== razorpay_signature) {
    return NextResponse.json({ error: 'Payment verification failed' }, { status: 400 });
  }

  const order = await prisma.order.update({
    where: { razorpayOrderId: razorpay_order_id },
    data: {
      razorpayPaymentId: razorpay_payment_id,
      razorpaySignature: razorpay_signature,
      paymentStatus: 'paid',
      status: 'fulfilling',
    },
    include: {
      items: {
        include: {
          product: { include: { images: { take: 1, orderBy: { position: 'asc' } } } },
          variant: true,
        },
      },
    },
  });

  // Only counted against the code's usage limit once payment is actually
  // confirmed, so abandoned carts don't burn through a limited-use code.
  try {
    await recordDiscountUsage(order.discountCode);
  } catch (err) {
    console.error('Failed to record discount usage:', order.id, err);
  }

  // Push the order to CJ Dropshipping for fulfillment now that payment is confirmed.
  try {
    const cjOrderId = await submitOrderToCJ(order);
    await prisma.order.update({ where: { id: order.id }, data: { cjOrderId } });
  } catch (err) {
    // Don't fail the checkout response over this — payment already succeeded.
    // Log it and let a retry job / manual review pick it up.
    console.error('CJ order submission failed, needs manual retry:', order.id, err);
  }

  // Allocate an invoice number and generate the PDF now that the order is paid.
  // Invoice numbers are only ever allocated here, so the sequence only ever
  // tracks paid orders.
  let invoiceNumber: string | null = null;
  try {
    ({ invoiceNumber } = await allocateInvoiceNumber());
    await prisma.order.update({ where: { id: order.id }, data: { invoiceNumber, invoiceDate: new Date() } });
    const { filePath } = await generateInvoicePdf(order.id);
    await prisma.order.update({ where: { id: order.id }, data: { invoicePdfPath: filePath } });
  } catch (err) {
    console.error('Invoice generation failed, needs manual retry:', order.id, err);
  }

  // Send the order confirmation email. The invoice PDF is generated above for
  // admin/GST records but intentionally not attached here — customers should
  // only get the confirmation email itself.
  try {
    const address = order.shippingAddress as unknown as { email?: string };
    if (address.email) {
      const { subject, html, text } = buildOrderConfirmationEmail({ ...order, invoiceNumber: invoiceNumber ?? order.invoiceNumber });
      await sendMail({ to: address.email, subject, html, text });
    }
  } catch (err) {
    console.error('Order confirmation email failed:', order.id, err);
  }

  // Notify the store owner that a new order came in. Separate from the
  // customer confirmation above — goes to ADMIN_NOTIFICATION_EMAIL, not the
  // customer's address. Same best-effort handling: never fails checkout.
  try {
    const adminEmail = process.env.ADMIN_NOTIFICATION_EMAIL;
    if (adminEmail) {
      const { subject, html, text } = buildAdminOrderNotificationEmail(order);
      await sendMail({ to: adminEmail, subject, html, text });
    }
  } catch (err) {
    console.error('Admin order notification email failed:', order.id, err);
  }

  // Server-side Purchase event via Meta Conversions API — a reliable backup
  // to the client-side pixel fired on /order-confirmed, deduped via the same
  // "purchase-{orderId}" event_id. No-ops silently if not configured yet.
  try {
    const address = order.shippingAddress as unknown as { email?: string; phone?: string };
    await sendMetaPurchaseEvent({
      eventId: `purchase-${order.id}`,
      email: address.email,
      phone: address.phone,
      value: Number(order.total),
      currency: order.currency,
      contentIds: order.items.map((item) => item.productId),
      clientIp: req.headers.get('x-forwarded-for'),
      userAgent: req.headers.get('user-agent'),
      sourceUrl: `${process.env.NEXT_PUBLIC_SITE_URL}/order-confirmed?orderId=${order.id}`,
      fbp: req.cookies.get('_fbp')?.value,
      fbc: req.cookies.get('_fbc')?.value,
    });
  } catch (err) {
    console.error('Meta Conversions API Purchase event failed:', order.id, err);
  }

  return NextResponse.json({ success: true, orderId: order.id });
}
