'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

// This custom checkout form has been replaced by Razorpay Magic Checkout,
// which now runs from the cart page (collects address/payment itself).
// Anyone landing here via an old bookmark or back-button gets sent there.
export default function CheckoutPage() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/cart');
  }, [router]);

  return null;
}
