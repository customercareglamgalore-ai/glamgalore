'use client';

import { useEffect, useState } from 'react';
import Script from 'next/script';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Reveal from '@/components/Reveal';
import { notifyCartUpdated } from '@/lib/cart-count';
import { CHECKOUT_COUNTRIES } from '@/lib/currency';

const INDIAN_STATES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat',
  'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh',
  'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab',
  'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand',
  'West Bengal', 'Delhi', 'Jammu and Kashmir', 'Ladakh', 'Chandigarh', 'Puducherry',
];

type CartItem = {
  productId: string;
  variantId?: string;
  quantity: number;
  title?: string;
  variantLabel?: string;
  price?: string;
  imageUrl?: string;
};

type Address = {
  name: string;
  email: string;
  phone: string;
  line1: string;
  line2: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
  gstin: string;
};

const EMPTY_ADDRESS: Address = {
  name: '', email: '', phone: '', line1: '', line2: '', city: '', state: '', pincode: '', country: 'India', gstin: '',
};

export default function CheckoutPage() {
  const router = useRouter();
  const [items, setItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [address, setAddress] = useState<Address>(EMPTY_ADDRESS);
  const [discountCode, setDiscountCode] = useState('');
  const [specialInstructions, setSpecialInstructions] = useState('');

  useEffect(() => {
    const raw = JSON.parse(localStorage.getItem('cart') || '[]') as CartItem[];
    if (raw.length === 0) {
      router.replace('/cart');
      return;
    }
    fetch('/api/cart/hydrate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: raw }),
    })
      .then((res) => res.json())
      .then((data) => setItems(data.items))
      .finally(() => setLoading(false));
  }, [router]);

  const total = items.reduce((sum, i) => sum + Number(i.price || 0) * i.quantity, 0);

  function updateField(field: keyof Address, value: string) {
    setAddress((prev) => ({ ...prev, [field]: value }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    const cartItems = JSON.parse(localStorage.getItem('cart') || '[]');

    fetch('/api/checkout/create-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cartItems, shippingAddress: address, discountCode, specialInstructions }),
    })
      .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
      .then(({ ok, data }) => {
        if (!ok) {
          setError(data.error || 'Something went wrong. Please try again.');
          setSubmitting(false);
          return;
        }

        const options = {
          key: data.keyId,
          amount: data.amount,
          currency: data.currency,
          name: 'Glam Galore',
          order_id: data.razorpayOrderId,
          theme: { color: '#000000' },
          prefill: {
            name: address.name,
            email: address.email,
            contact: address.phone,
          },
          notes: specialInstructions ? { customer_note: specialInstructions } : undefined,
          handler: function (response: any) {
            fetch('/api/checkout/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(response),
            })
              .then((res) => res.json())
              .then((result) => {
                if (result.success ?? result.orderId) {
                  localStorage.removeItem('cart');
                  notifyCartUpdated();
                  window.location.href = `/order-confirmed?orderId=${result.orderId ?? data.orderId}`;
                } else {
                  setError('Payment received, but confirming your order failed. Please contact support with your payment ID.');
                }
              })
              .catch(() => {
                setError('Payment received, but confirming your order failed. Please contact support with your payment ID.');
              });
          },
          modal: {
            ondismiss: function () {
              setSubmitting(false);
            },
          },
        };

        const rzp = new (window as any).Razorpay(options);
        rzp.on('payment.failed', function () {
          setError('Payment failed. Please try again or use a different payment method.');
          setSubmitting(false);
        });
        rzp.open();
      })
      .catch(() => {
        setError('Something went wrong starting checkout. Please try again.');
        setSubmitting(false);
      });
  }

  if (loading) return <main className="container"><p>Loading checkout...</p></main>;

  return (
    <main className="container">
      <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="afterInteractive" />
      <Reveal>
        <h1 className="section-heading">Checkout</h1>

        <ul style={{ listStyle: 'none', padding: 0 }}>
          {items.map((item) => (
            <li
              key={`${item.productId}-${item.variantId || 'default'}`}
              style={{ display: 'flex', gap: 16, borderTop: '1px solid #eee', padding: '12px 0', alignItems: 'center' }}
            >
              {item.imageUrl && <img src={item.imageUrl} alt={item.title} style={{ width: 60, height: 75, objectFit: 'cover' }} />}
              <div style={{ flex: 1 }}>
                <p>{item.title} × {item.quantity}</p>
                {item.variantLabel && <p style={{ color: '#777', fontSize: '0.85rem' }}>{item.variantLabel}</p>}
              </div>
              <p>₹{(Number(item.price || 0) * item.quantity).toFixed(2)}</p>
            </li>
          ))}
        </ul>
        <p style={{ textAlign: 'right', fontSize: '1.1rem', margin: '8px 0 20px' }}>Total: ₹{total.toFixed(2)}</p>

        <form onSubmit={handleSubmit}>
          <div className="order-details-card">
            <div className="order-details-field">
              <label htmlFor="name">Full name</label>
              <input id="name" required value={address.name} onChange={(e) => updateField('name', e.target.value)} />
            </div>
            <div className="order-details-field">
              <label htmlFor="email">Email</label>
              <input id="email" type="email" required value={address.email} onChange={(e) => updateField('email', e.target.value)} />
            </div>
            <div className="order-details-field">
              <label htmlFor="phone">Phone number</label>
              <input id="phone" type="tel" required value={address.phone} onChange={(e) => updateField('phone', e.target.value)} />
            </div>
            <div className="order-details-field">
              <label htmlFor="line1">Address line 1</label>
              <input id="line1" required value={address.line1} onChange={(e) => updateField('line1', e.target.value)} />
            </div>
            <div className="order-details-field">
              <label htmlFor="line2">Address line 2 (optional)</label>
              <input id="line2" value={address.line2} onChange={(e) => updateField('line2', e.target.value)} />
            </div>
            <div className="order-details-field">
              <label htmlFor="city">City</label>
              <input id="city" required value={address.city} onChange={(e) => updateField('city', e.target.value)} />
            </div>
            <div className="order-details-field">
              <label htmlFor="country">Country</label>
              <select id="country" required value={address.country} onChange={(e) => updateField('country', e.target.value)}>
                {CHECKOUT_COUNTRIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="order-details-field">
              <label htmlFor="state">State</label>
              {address.country === 'India' ? (
                <select id="state" required value={address.state} onChange={(e) => updateField('state', e.target.value)}>
                  <option value="">Select a state</option>
                  {INDIAN_STATES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              ) : (
                <input id="state" required value={address.state} onChange={(e) => updateField('state', e.target.value)} />
              )}
            </div>
            <div className="order-details-field">
              <label htmlFor="pincode">Pincode</label>
              <input id="pincode" required value={address.pincode} onChange={(e) => updateField('pincode', e.target.value)} />
            </div>
            <div className="order-details-field">
              <label htmlFor="gstin">GSTIN (optional, for business invoices)</label>
              <input id="gstin" value={address.gstin} onChange={(e) => updateField('gstin', e.target.value)} />
            </div>
            <div className="order-details-field">
              <label htmlFor="special-instructions">Special instructions</label>
              <textarea
                id="special-instructions"
                placeholder="e.g. custom sizing — bust, waist, hip measurements"
                value={specialInstructions}
                onChange={(e) => setSpecialInstructions(e.target.value)}
                rows={2}
              />
            </div>
            <div className="order-details-field">
              <label htmlFor="discount-code">Discount code</label>
              <input
                id="discount-code"
                placeholder="Enter code"
                value={discountCode}
                onChange={(e) => setDiscountCode(e.target.value)}
              />
            </div>
          </div>

          {error && <p style={{ color: '#e22120', textAlign: 'right', margin: '0 0 8px' }}>{error}</p>}
          <p style={{ textAlign: 'right', margin: '0 0 var(--space-3)' }}>
            <button type="submit" className="btn" disabled={submitting}>
              {submitting ? 'Processing...' : `Pay ₹${total.toFixed(2)}`}
            </button>
          </p>
        </form>

        <p style={{ textAlign: 'center' }}><Link href="/cart" style={{ color: '#777' }}>← Back to cart</Link></p>
      </Reveal>
    </main>
  );
}
