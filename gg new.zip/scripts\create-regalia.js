// One-off: creates the REGALIA product — a halter co-ord (wrap crop top +
// draped maxi skirt) in 2 colorways (Dark Brown, Rose Red) x 3 sizes
// (S/M/L), sourced from CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  'Dark Brown': { S: 'CJLS303344601AZ', M: 'CJLS303344602BY', L: 'CJLS303344603CX' },
  'Rose Red': { S: 'CJLS303344604DW', M: 'CJLS303344605EV', L: 'CJLS303344606FU' },
};

const HERO_IMAGE = {
  'Dark Brown': '/products/regalia/regalia-1.png',
  'Rose Red': '/products/regalia/regalia-5.png',
};

const GALLERY_IMAGES = [
  '/products/regalia/regalia-1.png', // Dark Brown front
  '/products/regalia/regalia-2.png', // Dark Brown back
  '/products/regalia/regalia-3.png', // Dark Brown bust closeup
  '/products/regalia/regalia-4.png', // Dark Brown waist closeup
  '/products/regalia/regalia-5.png', // Rose Red front
  '/products/regalia/regalia-6.png', // Rose Red back
  '/products/regalia/regalia-7.png', // Rose Red bust closeup
  '/products/regalia/regalia-8.png', // Rose Red waist closeup
];

const DESCRIPTION_TEXT = 'Command the room in Regalia, a luxe halter co-ord featuring shimmering trims, a plunging wrap top and sculptural draped maxi skirt for statement nights.';
const FEATURES = [
  'Material: Polyester',
  'Plunging halter-neck crop top',
  'Shimmering embellished trim',
  'Sculptural draped maxi skirt',
  'Flattering V-shaped waistband',
  'Adjustable tie-back design',
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'regalia' } });
  if (existing) {
    console.error('A product with handle "regalia" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'regalia',
      title: 'REGALIA',
      descriptionHtml: `<p>${DESCRIPTION_TEXT}</p>`,
      description: DESCRIPTION_TEXT,
      features: FEATURES,
      type: 'co ord',
      price: 3899,
      status: 'active',
      isDropshipped: true,
      collections: ['spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created REGALIA:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
