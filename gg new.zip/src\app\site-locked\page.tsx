'use client';

import { useState } from 'react';

export default function SiteLockedPage() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    const res = await fetch('/api/site-unlock', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password }),
    });

    if (res.ok) {
      window.location.href = '/';
    } else {
      setError('That password is incorrect.');
      setSubmitting(false);
    }
  }

  return (
    <main
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        padding: 24,
      }}
    >
      <div style={{ maxWidth: 360, width: '100%' }}>
        <h1 style={{ fontSize: '1.6rem', marginBottom: 12 }}>Only those with the password can access our exclusive launch discount code🔒</h1>
        <p style={{ color: '#666', marginBottom: 8 }}>Only those with the password can unlock our exclusive launch prices.</p>
        <p style={{ color: '#666', marginBottom: 24 }}>Enter your password below to continue.</p>
        <form onSubmit={handleSubmit}>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            autoFocus
            style={{ width: '100%', padding: 12, border: '1px solid #ccc', fontSize: 14, marginBottom: 12 }}
          />
          {error && <p style={{ color: '#e22120', fontSize: 13, marginBottom: 12 }}>{error}</p>}
          <button
            type="submit"
            disabled={submitting}
            style={{ width: '100%', padding: 12, background: '#000', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 14 }}
          >
            {submitting ? 'Checking...' : 'Unlock'}
          </button>
        </form>
      </div>
    </main>
  );
}
