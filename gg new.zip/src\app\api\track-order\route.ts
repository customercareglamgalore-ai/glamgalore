import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { listTracking } from '@/lib/parcelwill';
import { getDeliveryEstimate, getDeliveryDisclaimer } from '@/lib/delivery-estimate';

// Public order lookup — requires both the order reference AND either the
// email or phone number used to place it, so a guessable order number alone
// can't leak someone else's address/order contents.
export async function POST(req: NextRequest) {
  const { orderNumber, email, phone } = await req.json();
  if (!orderNumber || (!email && !phone)) {
    return NextResponse.json({ error: 'Order number and email or phone number are required' }, { status: 400 });
  }

  // Accept the order number in whatever form the customer has it: our
  // invoice number ("GG-000185" or "GG000185"), or — for historical orders
  // imported from Shopify — the original Shopify order name, with or
  // without its "#"/"GG" prefix (e.g. "#GG451813", "GG451813", "451813").
  const normalizeRef = (s: string) => s.toUpperCase().replace(/[^A-Z0-9]/g, '');
  const target = normalizeRef(String(orderNumber));

  let candidates;
  if (email) {
    const normalizedEmail = String(email).trim().toLowerCase();
    candidates = await prisma.order.findMany({
      where: { customer: { email: normalizedEmail } },
      include: { items: { include: { product: true } } },
    });
  } else {
    // Phone isn't reliably backfilled onto every Customer record, but it's
    // always present on the order's own shippingAddress — match on the last
    // 10 digits so formatting differences (+91, spaces, leading 0) don't
    // matter on either side.
    const digits = String(phone).replace(/\D/g, '');
    const last10 = digits.slice(-10);
    if (last10.length < 10) {
      return NextResponse.json({ error: 'Enter a valid phone number' }, { status: 400 });
    }
    candidates = await prisma.order.findMany({
      where: { shippingAddress: { path: ['phone'], string_contains: last10 } },
      include: { items: { include: { product: true } } },
    });
  }

  const order = candidates.find((o) => {
    const shopifyOrderName = (o.shippingAddress as { shopifyOrderName?: string } | null)?.shopifyOrderName;
    const normalizedShopifyName = shopifyOrderName ? normalizeRef(shopifyOrderName) : null;
    return (
      normalizeRef(o.id) === target ||
      (o.invoiceNumber && normalizeRef(o.invoiceNumber) === target) ||
      (normalizedShopifyName && (normalizedShopifyName === target || normalizedShopifyName.replace(/^GG/, '') === target))
    );
  });

  if (!order) {
    return NextResponse.json({ error: `No order found with that order number and ${email ? 'email' : 'phone number'}` }, { status: 404 });
  }

  let checkpoints: Awaited<ReturnType<typeof listTracking>> = null;
  if (order.trackingNumber) {
    checkpoints = await listTracking(order.id);
  }

  const estimate = getDeliveryEstimate(order.createdAt, order.status, order.customerCountry);

  return NextResponse.json({
    orderId: order.id,
    invoiceNumber: order.invoiceNumber,
    status: order.status,
    paymentStatus: order.paymentStatus,
    createdAt: order.createdAt,
    trackingNumber: order.trackingNumber,
    trackingCarrier: order.trackingCarrier,
    items: order.items.map((i) => ({ title: i.product.title, quantity: i.quantity })),
    tracking: checkpoints,
    delivery: {
      estimatedStart: estimate.estimatedStart,
      estimatedEnd: estimate.estimatedEnd,
      isDelivered: estimate.isDelivered,
      isDelayed: estimate.isDelayed,
      progress: estimate.progress,
      disclaimer: getDeliveryDisclaimer(order.customerCountry),
    },
  });
}
