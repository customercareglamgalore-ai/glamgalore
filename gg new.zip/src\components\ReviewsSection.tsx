'use client';

import { useState } from 'react';
import ReviewList from './ReviewList';
import ReviewForm from './ReviewForm';

type Review = {
  id: string;
  authorName: string;
  rating: number;
  title?: string | null;
  body: string;
  imageUrls: string[];
  verified: boolean;
};

export default function ReviewsSection({ productId, initialReviews }: { productId: string; initialReviews: Review[] }) {
  const [reviews, setReviews] = useState(initialReviews);

  return (
    <>
      <ReviewList reviews={reviews} />
      <ReviewForm productId={productId} onSubmitted={(review) => setReviews((prev) => [review, ...prev])} />
    </>
  );
}
