// One-off: creates the HEIRESS product — a strapless corset + bow-trim
// A-line mini skirt set, single colorway (Pink & Black — CJ generically
// labeled this "Suit Sets", not a usable customer-facing name) x 4 sizes
// (S/M/L/XL), sourced from CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = { S: 'CJLS305137001AZ', M: 'CJLS305137002BY', L: 'CJLS305137003CX', XL: 'CJLS305137004DW' };
const HERO_IMAGE = '/products/heiress/heiress-1.png';
const GALLERY_IMAGES = [
  '/products/heiress/heiress-1.png', // front
  '/products/heiress/heiress-2.png', // back
  '/products/heiress/heiress-3.png', // flat lay
];

const DESCRIPTION_TEXT = 'Own every entrance in the Heiress Set, featuring a sculpted strapless corset, statement satin bows and a flattering A-line mini skirt for timeless elegance.';
const FEATURES = [
  'Material: Polyester',
  'Structured strapless corset bodice',
  'Statement satin bow detailing',
  'Flattering A-line mini skirt',
  'Sculpting boned construction',
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'heiress' } });
  if (existing) {
    console.error('A product with handle "heiress" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'heiress',
      title: 'HEIRESS',
      descriptionHtml: `<p>${DESCRIPTION_TEXT}</p>`,
      description: DESCRIPTION_TEXT,
      features: FEATURES,
      type: 'co ord',
      price: 3899,
      status: 'active',
      isDropshipped: true,
      collections: ['spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).map(([size, sku]) => ({
          optionName: 'Color',
          optionValue: 'Pink & Black',
          option2Name: 'Size',
          option2Value: size,
          imageUrl: HERO_IMAGE,
          sku,
        })),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created HEIRESS:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
