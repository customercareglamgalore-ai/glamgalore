// One-off: creates the SECRET GARDEN product — a strapless floral sequin
// mini dress with beaded fringe hem, single colorway (Green) x 4 sizes
// (S/M/L/XL), sourced from CJ Dropshipping.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = { S: 'CJLY302277501AZ', M: 'CJLY302277502BY', L: 'CJLY302277503CX', XL: 'CJLY302277504DW' };
const HERO_IMAGE = '/products/secret-garden/secret-garden-1.png';
const GALLERY_IMAGES = [
  '/products/secret-garden/secret-garden-1.png',
  '/products/secret-garden/secret-garden-2.png',
  '/products/secret-garden/secret-garden-3.png',
];

const DESCRIPTION_TEXT = 'Bloom in the secret garden Embellished Mini Dress featuring intricate floral beadwork, a strapless neckline, fringe hem and a flattering fitted silhouette.';
const FEATURES = [
  'Fabric Type: Polyester',
  'Lined',
  'Non-stretch',
  'Strapless',
  'Floral sequin design',
  'Beaded tassel detail',
  'Zipper',
  'Print placement may vary',
  'Care instructions: Cold hand wash only',
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'secret-garden' } });
  if (existing) {
    console.error('A product with handle "secret-garden" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'secret-garden',
      title: 'SECRET GARDEN',
      descriptionHtml: `<p>${DESCRIPTION_TEXT}</p>`,
      description: DESCRIPTION_TEXT,
      features: FEATURES,
      type: 'Dress',
      price: 3499,
      status: 'active',
      isDropshipped: true,
      collections: ['mini-dresses', 'spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).map(([size, sku]) => ({
          optionName: 'Color',
          optionValue: 'Green',
          option2Name: 'Size',
          option2Value: size,
          imageUrl: HERO_IMAGE,
          sku,
        })),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created SECRET GARDEN:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
