// One-off: creates the NERINA product — a draped halter maxi dress in 4
// colors (Black, Brown, Yellow, White) x 3 sizes (S/M/L), sourced from CJ
// Dropshipping. Photos were manually matched to colors from the supplied
// product photo set; SKUs come from the CJ listing's Variant Pricing table.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Black: { S: 'CJLY302279510JQ', M: 'CJLY302279511KP', L: 'CJLY302279512LO' },
  Brown: { S: 'CJLY302279513MN', M: 'CJLY302279514NM', L: 'CJLY302279515OL' },
  Yellow: { S: 'CJLY302279501AZ', M: 'CJLY302279502BY', L: 'CJLY302279503CX' },
  White: { S: 'CJLY302279507GT', M: 'CJLY302279508HS', L: 'CJLY302279509IR' },
};

// Front-facing "hero" photo per color — also used to sync the color swatch
// tap to the matching gallery slide (see ProductGallery/ProductPurchasePanel).
const HERO_IMAGE = {
  Black: '/products/nerina/nerina-1.png',
  Brown: '/products/nerina/nerina-3.png',
  Yellow: '/products/nerina/nerina-6.png',
  White: '/products/nerina/nerina-9.png',
};

const GALLERY_IMAGES = [
  '/products/nerina/nerina-1.png',  // Black front
  '/products/nerina/nerina-2.png',  // Black back
  '/products/nerina/nerina-3.png',  // Brown front
  '/products/nerina/nerina-4.png',  // Brown close-up
  '/products/nerina/nerina-5.png',  // Brown back
  '/products/nerina/nerina-6.png',  // Yellow front
  '/products/nerina/nerina-7.png',  // Yellow close-up
  '/products/nerina/nerina-8.png',  // Yellow back
  '/products/nerina/nerina-9.png',  // White front
  '/products/nerina/nerina-10.png', // White back
];

const DESCRIPTION_HTML = `<p>Turn heads in the Nerina Draped Halter Maxi Dress featuring a plunging neckline, open back, side cut-outs and elegant draping for effortless evening glamour.</p>`;
const FEATURES = ['Material: Polyester', 'Plunging neckline', 'Side cut out', 'Waist gathering', 'Open back'];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'nerina' } });
  if (existing) {
    console.error('A product with handle "nerina" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'nerina',
      title: 'NERINA',
      descriptionHtml: DESCRIPTION_HTML,
      description: 'Turn heads in the Nerina Draped Halter Maxi Dress featuring a plunging neckline, open back, side cut-outs and elegant draping for effortless evening glamour.',
      features: FEATURES,
      type: 'Dress',
      price: 3499,
      status: 'active',
      isDropshipped: true,
      collections: ['spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created NERINA:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
