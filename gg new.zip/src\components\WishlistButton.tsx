'use client';

import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { ensureWishlistState, isWishlisted, toggleWishlist, WISHLIST_UPDATED_EVENT } from '@/lib/wishlist';

export default function WishlistButton({ handle, className }: { handle: string; className?: string }) {
  const router = useRouter();
  const pathname = usePathname();
  const [wishlisted, setWishlisted] = useState(false);

  useEffect(() => {
    let cancelled = false;
    ensureWishlistState().then(() => {
      if (!cancelled) setWishlisted(isWishlisted(handle));
    });
    function handleUpdate() {
      setWishlisted(isWishlisted(handle));
    }
    window.addEventListener(WISHLIST_UPDATED_EVENT, handleUpdate);
    return () => {
      cancelled = true;
      window.removeEventListener(WISHLIST_UPDATED_EVENT, handleUpdate);
    };
  }, [handle]);

  async function handleClick(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    const result = await toggleWishlist(handle);
    if (!result.loggedIn) {
      router.push(`/account?redirect=${encodeURIComponent(pathname)}`);
      return;
    }
    setWishlisted(!!result.wishlisted);
  }

  return (
    <button
      type="button"
      className={`wishlist-button ${wishlisted ? 'active' : ''} ${className || ''}`}
      aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
      aria-pressed={wishlisted}
      onClick={handleClick}
    >
      <svg width="20" height="20" viewBox="0 0 24 24" fill={wishlisted ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 21s-7.5-4.8-10-9.3C.5 8.2 2.3 4.5 6 4.5c2.1 0 3.7 1.1 6 3.5 2.3-2.4 3.9-3.5 6-3.5 3.7 0 5.5 3.7 4 7.2C19.5 16.2 12 21 12 21Z" />
      </svg>
    </button>
  );
}
