// Replaces BEHATI's product photos with a fresh set (new studio/lifestyle
// shots) — deletes the old ProductImage rows (which pointed at legacy
// cdn.shopify.com URLs) and re-points every variant's imageUrl at the new
// hero image. Colors/sizes/SKUs are untouched.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const GALLERY_IMAGES = [
  '/products/behati/behati-1.png', // lifestyle, beach sunset
  '/products/behati/behati-2.png', // lifestyle, beach
  '/products/behati/behati-3.png', // lifestyle, beach side
  '/products/behati/behati-4.png', // flat/mannequin front
];
const HERO_IMAGE = GALLERY_IMAGES[0];

async function main() {
  const product = await prisma.product.findUnique({ where: { handle: 'behati' }, include: { images: true, variants: true } });
  if (!product) {
    console.error('No product with handle "behati" found.');
    process.exit(1);
  }

  await prisma.productImage.deleteMany({ where: { productId: product.id } });
  await prisma.productImage.createMany({
    data: GALLERY_IMAGES.map((url, i) => ({ productId: product.id, url, position: i })),
  });

  await prisma.productVariant.updateMany({
    where: { productId: product.id },
    data: { imageUrl: HERO_IMAGE },
  });

  console.log('Replaced BEHATI images:', GALLERY_IMAGES.length, 'new photos');
  console.log('Re-pointed', product.variants.length, 'variants to the new hero image');
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
