// Sets heroVideoUrl on the 8 products with approved AI-animated hero clips.
// Each video file lives at /products/<handle>/<handle>-hero.mp4, deployed
// alongside that product's regular photos.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const HANDLES = [
  'bandage-dress',
  'nikki',
  'zyvah-playsuit',
  'bohemian-bordeaux',
  'seaknot',
  'marina',
  'bandage-dress-midi',
  'limoncello',
  'aurelia',
  'imani',
];

async function main() {
  for (const handle of HANDLES) {
    const heroVideoUrl = `/products/${handle}/${handle}-hero.mp4`;
    const result = await prisma.product.updateMany({ where: { handle }, data: { heroVideoUrl } });
    if (result.count === 0) {
      console.warn(`No product found for handle "${handle}" — skipped`);
    } else {
      console.log(`${handle} -> ${heroVideoUrl}`);
    }
  }
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
