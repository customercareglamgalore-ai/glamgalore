// Extracted from the original inline rule in create-order/route.ts so both the
// checkout quote preview and the real order creation share one source of truth.
// Free shipping worldwide, domestic and international, with no order-size
// threshold — matches the site's "Free shipping worldwide" messaging.
export function computeShippingCost(_subtotalINR: number, _country: string): number {
  return 0;
}
