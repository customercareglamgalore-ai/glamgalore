// One-off: creates the AMOURA product — an elegant V-neck printed halter
// dress in 2 colors (Sage, Red) x 4 sizes (S/M/L/XL), sourced from CJ
// Dropshipping. Description/features are placeholders — update once real
// copy is provided.
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const SKUS = {
  Sage: { S: 'CJLY304629501AZ', M: 'CJLY304629502BY', L: 'CJLY304629503CX', XL: 'CJLY304629504DW' },
  Red: { S: 'CJLY304629505EV', M: 'CJLY304629506FU', L: 'CJLY304629507GT', XL: 'CJLY304629508HS' },
};

const HERO_IMAGE = {
  Red: '/products/amoura/amoura-1.png',
  Sage: '/products/amoura/amoura-3.png',
};

const GALLERY_IMAGES = [
  '/products/amoura/amoura-1.png', // Red front
  '/products/amoura/amoura-2.png', // Red back
  '/products/amoura/amoura-3.png', // Sage front
  '/products/amoura/amoura-4.png', // Sage back
];

async function main() {
  const existing = await prisma.product.findUnique({ where: { handle: 'amoura' } });
  if (existing) {
    console.error('A product with handle "amoura" already exists:', existing.id);
    process.exit(1);
  }

  const product = await prisma.product.create({
    data: {
      handle: 'amoura',
      title: 'AMOURA',
      descriptionHtml: '<p>The Amoura is an effortlessly glamorous statement mini, crafted with delicate floral embellishments. Its halter neckline and plunging silhouette create a flattering, feminine shape, while the intricate detailing adds an elevated touch. Perfect for vacations, parties, and sunset occasions.</p>',
      description: 'The Amoura is an effortlessly glamorous statement mini, crafted with delicate floral embellishments. Its halter neckline and plunging silhouette create a flattering, feminine shape, while the intricate detailing adds an elevated touch. Perfect for vacations, parties, and sunset occasions.',
      features: [
        'Material: Polyester',
        'Intricate floral embellishment detailing',
        'Plunging halter neckline',
        'Figure-flattering mini silhouette',
      ],
      type: 'Dress',
      price: 3499,
      status: 'active',
      isDropshipped: true,
      collections: ['mini-dresses', 'spring-has-sprung'],
      images: {
        create: GALLERY_IMAGES.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: Object.entries(SKUS).flatMap(([color, sizes]) =>
          Object.entries(sizes).map(([size, sku]) => ({
            optionName: 'Color',
            optionValue: color,
            option2Name: 'Size',
            option2Value: size,
            imageUrl: HERO_IMAGE[color],
            sku,
          })),
        ),
      },
    },
    include: { images: true, variants: true },
  });

  console.log('Created AMOURA:', product.id);
  console.log('Images:', product.images.length);
  console.log('Variants:', product.variants.length);
}

main().catch((err) => { console.error(err); process.exit(1); }).finally(() => prisma.$disconnect());
