import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q')?.trim() || '';
  if (!q) return NextResponse.json({ products: [] });

  // Beyond the title, also match style descriptors that live elsewhere —
  // the category ("mini dress", "long dress"), the write-up ("maxi skirt",
  // "leopard print"), and each variant's own color/print name (e.g.
  // "Leopard Print"), since the title alone rarely spells those out. A
  // simple plural strip ("leopards" -> "leopard") covers the common case
  // without pulling in real stemming.
  const terms = [q];
  if (q.length > 3 && q.toLowerCase().endsWith('s')) terms.push(q.slice(0, -1));

  const products = await prisma.product.findMany({
    where: {
      status: 'active',
      OR: terms.flatMap((term) => [
        { title: { contains: term, mode: 'insensitive' } },
        { description: { contains: term, mode: 'insensitive' } },
        { type: { contains: term, mode: 'insensitive' } },
        { variants: { some: { optionValue: { contains: term, mode: 'insensitive' } } } },
        { variants: { some: { option2Value: { contains: term, mode: 'insensitive' } } } },
      ]),
    },
    include: { images: { take: 4, orderBy: { position: 'asc' } } },
    orderBy: { createdAt: 'desc' },
    take: 40,
  });

  return NextResponse.json({
    products: products.map((p) => ({
      handle: p.handle,
      title: p.title,
      price: p.price?.toString() || '',
      compareAtPrice: p.compareAtPrice?.toString(),
      images: p.images.map((img) => img.url),
      isOutOfStock: p.isOutOfStock,
    })),
  });
}
