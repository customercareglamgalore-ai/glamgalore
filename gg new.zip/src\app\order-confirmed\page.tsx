import Link from 'next/link';
import { notFound } from 'next/navigation';
import { prisma } from '@/lib/db';
import { getCustomerIdFromSession } from '@/lib/auth';
import Reveal from '@/components/Reveal';
import PurchasePixel from '@/components/PurchasePixel';

export const metadata = {
  title: 'Order Confirmed — Glam Galore',
  robots: { index: false, follow: false },
};

type ShippingAddress = {
  name: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
};

export default async function OrderConfirmedPage({
  searchParams,
}: {
  searchParams: Promise<{ orderId?: string }>;
}) {
  const { orderId } = await searchParams;
  const customerId = await getCustomerIdFromSession();
  if (!orderId || !customerId) notFound();

  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: {
      items: {
        include: {
          product: { include: { images: { take: 1, orderBy: { position: 'asc' } } } },
          variant: true,
        },
      },
    },
  });

  if (!order || order.customerId !== customerId) notFound();

  const address = order.shippingAddress as unknown as ShippingAddress;

  return (
    <main className="container" style={{ maxWidth: 640, margin: '0 auto' }}>
      <PurchasePixel
        orderId={order.id}
        value={Number(order.total)}
        currency={order.currency}
        contentIds={order.items.map((item) => item.productId)}
      />
      <Reveal>
      <h1 className="section-heading">Your wish is our command!</h1>
      <p>Order #{order.invoiceNumber ?? order.id}</p>
      <p>Status: {order.status}</p>

      <ul style={{ listStyle: 'none', padding: 0, marginTop: 24 }}>
        {order.items.map((item) => (
          <li
            key={item.id}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, borderTop: '1px solid #eee', padding: '12px 0' }}
          >
            <span style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              {item.product.images[0] && (
                <img
                  src={item.product.images[0].url}
                  alt={item.product.title}
                  width={56}
                  height={56}
                  style={{ width: 56, height: 56, objectFit: 'cover', flexShrink: 0 }}
                />
              )}
              <span>
                {item.product.title}
                {item.variant &&
                  ` — ${[item.variant.optionValue, item.variant.option2Value].filter(Boolean).join(' / ')}`}
                {' '}× {item.quantity}
              </span>
            </span>
            <span style={{ flexShrink: 0 }}>₹{(Number(item.unitPrice) * item.quantity).toFixed(2)}</span>
          </li>
        ))}
      </ul>

      <p style={{ textAlign: 'right', marginTop: 16 }}>Product Subtotal: ₹{order.subtotal.toString()}</p>
      {Number(order.discountAmount) > 0 && (
        <p style={{ textAlign: 'right' }}>Discount: −₹{order.discountAmount.toString()}</p>
      )}
      <p style={{ textAlign: 'right' }}>Shipping: {Number(order.shippingCost) === 0 ? 'Free' : `₹${order.shippingCost.toString()}`}</p>
      <p style={{ textAlign: 'right', fontSize: '1.1rem', fontWeight: 600 }}>Grand Total: ₹{order.total.toString()}</p>
      <p style={{ textAlign: 'right', fontSize: 13, color: '#999' }}>
        {order.taxType === 'export_zero_rated' ? 'No taxes charged on international orders' : 'Inclusive of all taxes'}
      </p>

      {order.invoiceNumber ? (
        <p style={{ textAlign: 'right', marginTop: 8 }}>
          <a href={`/api/invoices/${order.id}`} className="btn">Download Invoice ({order.invoiceNumber})</a>
        </p>
      ) : order.paymentStatus === 'paid' ? (
        <p style={{ textAlign: 'right', marginTop: 8, fontSize: 13, color: '#999' }}>Invoice generating — refresh in a moment.</p>
      ) : null}

      <h2 style={{ marginTop: 32 }}>Shipping to</h2>
      <address style={{ fontStyle: 'normal' }}>
        {address.name}
        <br />
        {address.line1}
        <br />
        {address.line2 && (
          <>
            {address.line2}
            <br />
          </>
        )}
        {address.city}, {address.state} {address.pincode}
      </address>

      <p style={{ marginTop: 32 }}>
        <Link href="/" className="btn">Continue shopping</Link>
      </p>
      </Reveal>
    </main>
  );
}
