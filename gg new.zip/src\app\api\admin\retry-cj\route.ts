// Manually sets/corrects an order's shipping address and (re-)submits it to
// CJ Dropshipping. For orders that got paid but never had a usable address
// (e.g. captured before Magic Checkout was actually returning customer
// details) and need to be pushed through by hand. Protected by the same
// admin Basic Auth as everything else under /api/admin.
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { submitOrderToCJ } from '@/lib/cj-dropshipping';

export async function POST(req: NextRequest) {
  const { orderId, shippingAddress } = await req.json();
  if (!orderId || !shippingAddress) {
    return NextResponse.json({ error: 'orderId and shippingAddress are required' }, { status: 400 });
  }

  const order = await prisma.order.update({
    where: { id: orderId },
    data: {
      shippingAddress,
      customerState: shippingAddress.state,
      customerCountry: shippingAddress.country,
    },
    include: {
      items: {
        include: {
          product: { include: { images: { take: 1, orderBy: { position: 'asc' } } } },
          variant: true,
        },
      },
    },
  });

  const cjOrderId = await submitOrderToCJ(order);
  await prisma.order.update({ where: { id: orderId }, data: { cjOrderId } });

  return NextResponse.json({ success: true, cjOrderId });
}
