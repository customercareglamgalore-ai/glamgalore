import type { Order, OrderItem, Product, ProductVariant } from '@prisma/client';

type OrderWithItems = Order & {
  items: (OrderItem & { product: Product; variant: ProductVariant | null })[];
};

type ShippingAddress = {
  name?: string; email?: string; phone?: string;
  line1?: string; line2?: string; city?: string; state?: string; pincode?: string; country?: string;
};

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://glamgalore.in';
const FONT = "-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif";

function money(n: unknown): string {
  return `Rs. ${Number(n).toFixed(2)}`;
}

// Sent to the store owner (ADMIN_NOTIFICATION_EMAIL) the moment a paid order
// comes in — separate from buildOrderConfirmationEmail, which goes to the
// customer. Kept plain/functional since this is an internal alert, not a
// branded customer touchpoint.
export function buildAdminOrderNotificationEmail(order: OrderWithItems): { subject: string; html: string; text: string } {
  const address = order.shippingAddress as unknown as ShippingAddress;
  const orderNumber = order.invoiceNumber ?? order.id;
  const subject = `New order #${orderNumber} — ${money(order.total)}`;

  const itemRows = order.items
    .map((item) => {
      const variantLabel = item.variant
        ? [item.variant.optionValue, item.variant.option2Value].filter(Boolean).join(' / ')
        : '';
      return `
        <tr>
          <td style="padding:8px 0;border-bottom:1px solid #eee;">${item.product.title}${variantLabel ? ` (${variantLabel})` : ''}</td>
          <td style="padding:8px 0;border-bottom:1px solid #eee;text-align:center;">${item.quantity}</td>
          <td style="padding:8px 0;border-bottom:1px solid #eee;text-align:right;">${money(Number(item.unitPrice) * item.quantity)}</td>
        </tr>`;
    })
    .join('');

  const html = `
  <div style="max-width:560px;margin:0 auto;font-family:${FONT};color:#201a16;">
    <h1 style="font-size:18px;">New order received</h1>
    <p style="font-size:14px;"><a href="${SITE_URL}/admin/reports" style="color:#c4322a;">View in admin →</a></p>

    <h2 style="font-size:13px;text-transform:uppercase;color:#999;margin-top:24px;">Items</h2>
    <table style="width:100%;border-collapse:collapse;font-size:13px;">
      <tr><th style="text-align:left;padding-bottom:6px;">Product</th><th style="text-align:center;padding-bottom:6px;">Qty</th><th style="text-align:right;padding-bottom:6px;">Amount</th></tr>
      ${itemRows}
    </table>
    <p style="font-size:14px;font-weight:700;text-align:right;margin-top:8px;">Total: ${money(order.total)}</p>

    <h2 style="font-size:13px;text-transform:uppercase;color:#999;margin-top:24px;">Customer</h2>
    <p style="font-size:13px;line-height:1.6;">
      ${address.name || ''}<br>
      ${address.email || ''} ${address.phone ? `· ${address.phone}` : ''}<br>
      ${address.line1 || ''}${address.line2 ? `, ${address.line2}` : ''}<br>
      ${address.city || ''}, ${address.state || ''} ${address.pincode || ''}<br>
      ${address.country || 'India'}
    </p>

    ${order.customerNote ? `
    <h2 style="font-size:13px;text-transform:uppercase;color:#999;margin-top:24px;">Special instructions</h2>
    <p style="font-size:13px;line-height:1.6;white-space:pre-wrap;">${order.customerNote}</p>` : ''}
  </div>`;

  const text = [
    `New order #${orderNumber} — ${money(order.total)}`,
    `View in admin: ${SITE_URL}/admin/reports`,
    '',
    ...order.items.map((i) => {
      const variantLabel = i.variant ? [i.variant.optionValue, i.variant.option2Value].filter(Boolean).join(' / ') : '';
      return `${i.product.title}${variantLabel ? ` (${variantLabel})` : ''} x${i.quantity} — ${money(Number(i.unitPrice) * i.quantity)}`;
    }),
    '',
    `Total: ${money(order.total)}`,
    '',
    `Customer: ${address.name || ''}`,
    `${address.email || ''} ${address.phone ? `· ${address.phone}` : ''}`,
    `${address.line1 || ''}${address.line2 ? `, ${address.line2}` : ''}`,
    `${address.city || ''}, ${address.state || ''} ${address.pincode || ''}`,
    address.country || 'India',
    ...(order.customerNote ? ['', 'Special instructions:', order.customerNote] : []),
  ]
    .filter(Boolean)
    .join('\n');

  return { subject, html, text };
}
