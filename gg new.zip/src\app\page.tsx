import { prisma } from '@/lib/db';
import ProductCard from '@/components/ProductCard';
import ProductCarousel from '@/components/ProductCarousel';
import ReviewCarousel from '@/components/ReviewCarousel';
import BlogStrip from '@/components/BlogStrip';
import ReelStrip from '@/components/ReelStrip';
import ContactForm from '@/components/ContactForm';
import Reveal from '@/components/Reveal';
import HeartTrail from '@/components/HeartTrail';
import HeroMedia from '@/components/HeroMedia';
import Link from 'next/link';
import collectionImages from '../../data/collection-images.json';

// Section order mirrors the live theme's templates/index.json:
// hero slideshow -> "Top Selling" -> "Shop by Category" collage ->
// seasonal banner -> "Celebrity Closet" (frontpage collection) ->
// reviews -> blogs -> contact.

async function getCollectionProducts(collectionHandle: string, take = 8) {
  return prisma.product.findMany({
    where: { status: 'active', collections: { has: collectionHandle } },
    include: { images: { orderBy: { position: 'asc' }, take: 4 } },
    take,
    orderBy: { createdAt: 'desc' },
  });
}

// Curated, fixed order for the homepage "Top Selling" section (independent of
// the sortable /collections/top-selling page, which keeps its own controls).
const TOP_SELLING_HANDLES = ['aurelia', 'imani', 'burnt-honey', 'seamless-snatch'];

async function getProductsByHandlesInOrder(handles: string[]) {
  const products = await prisma.product.findMany({
    where: { handle: { in: handles } },
    include: { images: { orderBy: { position: 'asc' }, take: 4 } },
  });
  const byHandle = new Map(products.map((p) => [p.handle, p]));
  return handles.map((h) => byHandle.get(h)).filter((p): p is NonNullable<typeof p> => Boolean(p));
}

const SHOP_BY_CATEGORY = [
  { handle: 'mini-dresses', label: 'Mini Dresses', large: true },
  { handle: 'co-ords', label: 'Co-ords', large: false },
  { handle: 'swimwear', label: 'Swimwear', large: false },
];

function toCardProduct(p: {
  handle: string;
  title: string;
  price: unknown;
  compareAtPrice: unknown;
  images: { url: string }[];
  isOutOfStock?: boolean;
}) {
  return {
    handle: p.handle,
    title: p.title,
    price: p.price?.toString() || '',
    compareAtPrice: p.compareAtPrice ? p.compareAtPrice.toString() : null,
    images: p.images.map((img) => img.url),
    isOutOfStock: p.isOutOfStock,
  };
}

export default async function HomePage() {
  const [topSelling, celebrityCloset, blogPosts, reviewPool, socialReels] = await Promise.all([
    getProductsByHandlesInOrder(TOP_SELLING_HANDLES),
    getCollectionProducts('frontpage'),
    prisma.blogPost.findMany({ orderBy: { publishedAt: 'desc' } }),
    prisma.review.findMany({
      where: { rating: { gte: 4 } },
      orderBy: [{ rating: 'desc' }, { createdAt: 'desc' }],
      take: 40,
      include: { product: { select: { title: true } } },
    }),
    prisma.reel.findMany({
      where: { featuredHome: true },
      orderBy: { position: 'asc' },
      take: 16,
      include: {
        product: {
          select: {
            id: true,
            handle: true,
            title: true,
            price: true,
            compareAtPrice: true,
            images: { take: 1, orderBy: { position: 'asc' } },
            variants: true,
          },
        },
      },
    }),
  ]);

  // Prefer reviews with a photo, since they read best in a slideshow.
  const topReviews = [...reviewPool]
    .sort((a, b) => (b.imageUrls.length > 0 ? 1 : 0) - (a.imageUrls.length > 0 ? 1 : 0))
    .slice(0, 10);

  return (
    <main>
      <Link href="/collections/all" className="hero-slideshow">
        <HeroMedia
          desktopSrc="/hero/homepage-hero-desktop.webp"
          mobileImageSrc="/hero/hero-poster.webp"
          videoSrc="/hero/hero-video.mp4"
          posterSrc="/hero/hero-poster.webp"
          alt="New season. New you."
        />
        <HeartTrail />
      </Link>

      <Reveal className="container brand-statement">
        <h2>The Divine Feminine Fashion</h2>
        <p>Timeless, high-vibrational pieces ~ awakening the modern goddess.</p>
      </Reveal>

      {socialReels.length > 0 && (
        <Reveal className="container">
          <h2 className="section-heading">As Seen on Socials #GlamGalore</h2>
          <ReelStrip
            reels={socialReels.map((r) => ({
              id: r.id,
              videoUrl: r.videoUrl,
              thumbnailUrl: r.thumbnailUrl,
              caption: r.caption,
              product: {
                id: r.product.id,
                handle: r.product.handle,
                title: r.product.title,
                price: r.product.price?.toString() || '',
                compareAtPrice: r.product.compareAtPrice?.toString(),
                imageUrl: r.product.images[0]?.url,
                variants: r.product.variants.map((v) => ({
                  id: v.id,
                  optionName: v.optionName,
                  optionValue: v.optionValue,
                  option2Name: v.option2Name,
                  option2Value: v.option2Value,
                  swatchHex: v.swatchHex,
                  imageUrl: v.imageUrl,
                })),
              },
            }))}
          />
        </Reveal>
      )}

      <Reveal className="container">
        <h2 className="section-heading">Top Selling</h2>
        <div className="product-grid">
          {topSelling.map((p) => (
            <ProductCard key={p.id} product={toCardProduct(p)} />
          ))}
        </div>
        <div className="section-cta">
          <Link href="/collections/top-selling" className="btn">View All</Link>
        </div>
      </Reveal>

      <Reveal className="container">
        <h2 className="section-heading">Shop by Category</h2>
        <div className="category-collage">
          {SHOP_BY_CATEGORY.map((c) => (
            <Link
              key={c.handle}
              href={`/collections/${c.handle}`}
              className={`category-tile ${c.large ? 'category-tile--large' : ''}`}
            >
              {collectionImages[c.handle as keyof typeof collectionImages] && (
                <img src={collectionImages[c.handle as keyof typeof collectionImages]} alt={c.label} loading="lazy" />
              )}
              <span className="label">{c.label} &rarr;</span>
            </Link>
          ))}
        </div>
      </Reveal>

      <Reveal className="container">
        <h2 className="section-heading">Celebrity Closet</h2>
        <ProductCarousel products={celebrityCloset.map(toCardProduct)} />
        <div className="section-cta">
          <Link href="/collections/frontpage" className="btn">View All</Link>
        </div>
      </Reveal>

      {topReviews.length > 0 && (
        <Reveal className="container">
          <h2 className="section-heading">Reviews</h2>
          <ReviewCarousel
            reviews={topReviews.map((r) => ({
              id: r.id,
              authorName: r.authorName,
              rating: r.rating,
              body: r.body,
              imageUrl: r.imageUrls[0] || null,
              productTitle: r.product.title,
            }))}
          />
        </Reveal>
      )}

      {blogPosts.length > 0 && (
        <Reveal className="container">
          <h2 className="section-heading">Blogs</h2>
          <BlogStrip
            posts={blogPosts.map((p) => ({
              handle: p.handle,
              title: p.title,
              summary: p.summary,
              imageUrl: p.imageUrl,
            }))}
          />
        </Reveal>
      )}

      <Reveal className="container blog-post-container">
        <h2 className="section-heading">About Us</h2>
        <div className="blog-post-body" style={{ textAlign: 'center' }}>
          <p>Thank you, Queen, for visiting Glam Galore.</p>
          <p>
            We&apos;ve started this brand for women to take back their divine feminine power on their own
            terms. We want to use this brand as an opportunity to build community, and use our medium to
            teach and take prowess on your own energy. This is dressing the modern goddess.
          </p>
          <p>
            Besides enjoying the beauty of fashion, our goal is to inspire women to find and cater to their
            higher selves and god complex. A woman&apos;s best accessory is confidence, and we are committed
            to making sure our clothing makes you feel it, and create your own powerful aura. So get dressed
            in Glam Galore, you deserve it!
          </p>
        </div>
      </Reveal>

      <Reveal className="container contact-section">
        <h2 className="section-heading">Contact Form</h2>
        <ContactForm />
      </Reveal>
    </main>
  );
}
