'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import ProductCard from '@/components/ProductCard';
import Reveal from '@/components/Reveal';

type ProductCardData = {
  handle: string;
  title: string;
  price: number | string;
  compareAtPrice?: number | string | null;
  images: string[];
  isOutOfStock?: boolean;
};

export default function WishlistPage() {
  const [loggedIn, setLoggedIn] = useState<boolean | null>(null);
  const [products, setProducts] = useState<ProductCardData[]>([]);

  useEffect(() => {
    fetch('/api/wishlist')
      .then((res) => res.json())
      .then((data) => {
        setLoggedIn(data.loggedIn);
        setProducts(data.products);
      });
  }, []);

  if (loggedIn === null) return <main className="container"><p>Loading your wishlist...</p></main>;

  if (!loggedIn) {
    return (
      <main className="container">
        <h1 className="section-heading">Log in to see your wishlist</h1>
        <p style={{ textAlign: 'center' }}>
          <Link href="/account?redirect=/wishlist" className="btn">Log in</Link>
        </p>
      </main>
    );
  }

  if (products.length === 0) {
    return (
      <main className="container">
        <h1 className="section-heading">Your wishlist is empty</h1>
        <p style={{ textAlign: 'center' }}><Link href="/" className="btn">Continue shopping</Link></p>
      </main>
    );
  }

  return (
    <main className="container">
      <Reveal>
        <h1 className="section-heading">Your Wishlist</h1>
        <div className="product-grid collection-grid">
          {products.map((product) => (
            <ProductCard key={product.handle} product={product} />
          ))}
        </div>
      </Reveal>
    </main>
  );
}
