'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import ProductCard from '@/components/ProductCard';
import Reveal from '@/components/Reveal';
import { getWishlistHandles, WISHLIST_UPDATED_EVENT } from '@/lib/wishlist';

type ProductCardData = {
  handle: string;
  title: string;
  price: number | string;
  compareAtPrice?: number | string | null;
  images: string[];
  isOutOfStock?: boolean;
};

export default function WishlistPage() {
  const [products, setProducts] = useState<ProductCardData[]>([]);
  const [loading, setLoading] = useState(true);

  function hydrate() {
    const handles = getWishlistHandles();
    if (handles.length === 0) {
      setProducts([]);
      setLoading(false);
      return;
    }
    fetch('/api/wishlist/hydrate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ handles }),
    })
      .then((res) => res.json())
      .then((data) => setProducts(data.products))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    hydrate();
    window.addEventListener(WISHLIST_UPDATED_EVENT, hydrate);
    window.addEventListener('storage', hydrate);
    return () => {
      window.removeEventListener(WISHLIST_UPDATED_EVENT, hydrate);
      window.removeEventListener('storage', hydrate);
    };
  }, []);

  if (loading) return <main className="container"><p>Loading your wishlist...</p></main>;

  if (products.length === 0) {
    return (
      <main className="container">
        <h1 className="section-heading">Your wishlist is empty</h1>
        <p style={{ textAlign: 'center' }}><Link href="/" className="btn">Continue shopping</Link></p>
      </main>
    );
  }

  return (
    <main className="container">
      <Reveal>
        <h1 className="section-heading">Your Wishlist</h1>
        <div className="product-grid collection-grid">
          {products.map((product) => (
            <ProductCard key={product.handle} product={product} />
          ))}
        </div>
      </Reveal>
    </main>
  );
}
