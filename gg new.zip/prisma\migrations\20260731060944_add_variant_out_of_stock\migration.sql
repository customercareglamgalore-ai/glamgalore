-- AlterTable
ALTER TABLE "ProductVariant" ADD COLUMN     "isOutOfStock" BOOLEAN NOT NULL DEFAULT false;
